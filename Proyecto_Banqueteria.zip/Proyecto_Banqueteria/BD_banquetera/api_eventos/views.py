from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_GET
from django.shortcuts import get_object_or_404

from gestion.models import Evento, Cliente


def serializar_evento(evento):
    cliente = evento.id_cliente

    if cliente.tipo_cliente == "persona_natural":
        nombre_cliente = " ".join(
            parte for parte in [cliente.nombre, cliente.apellido]
            if parte
        )
    else:
        nombre_cliente = cliente.nombre

    return {
        "id_evento": evento.id_evento,
        "nombre_evento": evento.nombre_evento,
        "fecha_evento": evento.fecha_evento.isoformat(),
        "hora_evento": (
            evento.hora_evento.isoformat()
            if evento.hora_evento else None
        ),
        "direccion": evento.direccion,
        "cantidad_personas": evento.cantidad_personas,
        "observaciones": evento.observaciones,
        "estado": evento.estado,
        "id_cliente": evento.id_cliente_id,
        "nombre_cliente": nombre_cliente,
        "nombre_fantasia": cliente.nombre_fantasia,
    }


@login_required
@require_GET
def eventos(request):
    registros = (
    Evento.objects
    .select_related("id_cliente")
    .order_by("fecha_evento", "id_evento")
)

    return JsonResponse({
        "total": registros.count(),
        "eventos": [
            serializar_evento(evento)
            for evento in registros
        ],
    })


@login_required
@require_GET
def evento_detalle(request, id_evento):
    evento = get_object_or_404(Evento, pk=id_evento)

    return JsonResponse(serializar_evento(evento))
