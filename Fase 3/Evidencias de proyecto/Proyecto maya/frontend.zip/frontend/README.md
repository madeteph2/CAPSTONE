# Frontend React Banquetería Maya + MICA

`npm ci` para instalar dependencias, `npm run build` para compilación, `npm run dev -- --host 127.0.0.1 --port 5173` para desarrollo. El proxy `/api` apunta a Django en 127.0.0.1:8000.

`src/MicaVista.jsx` y `src/MicaVista.css` implementan la interfaz del nuevo cotizador; no duplican los cálculos del backend. La autenticación se mantiene por sesiones y CSRF.

Manual completo en `../GUIA_EJECUCION_MICA.md`.
