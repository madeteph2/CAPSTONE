import logoMaya from './assets/logo_maya.png';
import { useEffect, useState } from 'react';
import './MicaCliente.css';

const hoy = () => new Date().toLocaleDateString('en-CA');
const CLP = valor => new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(Number(valor || 0));
// MICA_CATALOGO_V2_5_B1: la categoría elegida forma parte de la simulación y el pedido.
const tiposPorGrupo = {
  salados: [{id:'plato_fondo', nombre:'Platos principales'}, {id:'entrada', nombre:'Entradas'},
            {id:'acompanamiento', nombre:'Acompañamientos'}, {id:'canape', nombre:'Canapés'},
            {id:'bocado_salado', nombre:'Bocados salados'}],
  dulces: [{id:'postre', nombre:'Postres'}, {id:'bocado_dulce', nombre:'Bocados dulces'},
           {id:'reposteria', nombre:'Repostería'}],
  bebidas_frias: [{id:'bebida_fria', nombre:'Bebidas frías'}],
  bebidas_calientes: [{id:'bebida_caliente', nombre:'Bebidas calientes'}],
};
const inicial = { personas:'50', presupuesto:'500000', fecha:hoy(), ubicacion:'',
  tipo_evento:'Cumpleaños', grupo:'salados', tipo_preparacion:'plato_fondo', ficha_ids:[], restricciones:[] };
const contactoInicial = { nombre:'', apellido:'', email:'', telefono:'', comentario:'', acepta_condiciones:false };
const csrf = () => decodeURIComponent(document.cookie.split('; ').find(x => x.startsWith('csrftoken='))?.split('=')[1] || '');

async function api(ruta, metodo='GET', payload) {
  const res = await fetch(ruta, { method:metodo, credentials:'same-origin',
    headers: metodo === 'GET' ? {} : { 'Content-Type':'application/json', 'X-CSRFToken':csrf() },
    ...(payload ? { body:JSON.stringify(payload) } : {}),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const mensaje = typeof data.detail === 'string' ? data.detail : JSON.stringify(data, null, 2);
    throw new Error(mensaje || `Error ${res.status}`);
  }
  return data;
}

export default function MicaCliente() {
  const [evento, setEvento] = useState(inicial);
  const [contacto, setContacto] = useState(contactoInicial);
  const [preparaciones, setPreparaciones] = useState([]);
  const [resultado, setResultado] = useState(null);
  const [elegida, setElegida] = useState(null);
  const [finalizada, setFinalizada] = useState(null);
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState('');
  const [identificador, setIdentificador] = useState(() => globalThis.crypto?.randomUUID?.() || undefined);
  useEffect(() => { api('/api/mica/publico/preparaciones/').then(d => setPreparaciones(d.preparaciones || [])).catch(e => setError(e.message)); }, []);
  const cambiarEvento = (campo, valor) => {
    setEvento(e => {
      if (campo === 'grupo') return {...e, grupo:valor, tipo_preparacion:tiposPorGrupo[valor][0].id, ficha_ids:[]};
      if (campo === 'tipo_preparacion') return {...e, tipo_preparacion:valor, ficha_ids:[]};
      return {...e, [campo]:valor};
    });
    setResultado(null); setElegida(null); setFinalizada(null);
  };
  const simular = async (e) => {
    e.preventDefault(); setError(''); setEnviando(true); setElegida(null);
    try { setResultado(await api('/api/mica/publico/simular/', 'POST', { ...evento, personas:Number(evento.personas) })); }
    catch(e) { setError(e.message); }
    finally {setEnviando(false);}
  };
  const enviar = async (e) => {
    e.preventDefault();
    if (!elegida) return;
    setEnviando(true); setError('');
    try {
      const d = await api('/api/mica/publico/solicitar/', 'POST', {
        ...evento, personas:Number(evento.personas), ...contacto,
        ficha_id:elegida.id_ficha_tecnica, precio_mostrado:elegida.precio_total, identificador,
      });
      setFinalizada(d);
    } catch(e) { setError(e.message); }
    finally {setEnviando(false);}
  };
  return <main className="mica-cliente">
    <header className="mica-cliente-header"><div className="maya-marca"><span className="maya-logo-reserva" role="img" aria-label="Logotipo Banquetería Maya"><img src={logoMaya} alt="" className="maya-logo" /></span><div className="maya-marca-texto"><strong className="maya-marca-nombre">Banquetería Maya</strong><span className="maya-marca-subtitulo">Solicitud de evento · MICA</span></div></div><a href="/">Acceso al personal</a></header>
    <div className="mica-cliente-contenido">
      <div className="mica-cliente-hero"><span className="mica-cliente-eyebrow">COTIZACIÓN ASISTIDA · MICA</span><h1>Descubre una propuesta para tu evento</h1><p>Elige una preparación y envía tu solicitud. Un integrante de Banquetería Maya revisará disponibilidad, costos de servicio y aprobación final.</p></div>
      {error && <div className="mica-cliente-error" role="alert"><strong>No se pudo completar:</strong><pre>{error}</pre></div>}
      {finalizada ? <section className="mica-cliente-tarjeta mica-cliente-confirmacion" role="status">
        <h2>✓ Solicitud registrada</h2><p>{finalizada.mensaje}</p><p><strong>Número de pedido:</strong> {finalizada.numero_pedido}</p><p><strong>Precio estimado:</strong> {CLP(finalizada.precio_estimado)}</p><p><strong>Estado:</strong> CREADO · Pendiente de revisión del personal</p><p className="mica-cliente-aviso">Este comprobante no confirma la contratación. Guarda el número del pedido para tus consultas.</p>
        <button type="button" onClick={()=>{setResultado(null);setElegida(null);setFinalizada(null);setContacto(contactoInicial);setIdentificador(globalThis.crypto?.randomUUID?.() || undefined);}}>Realizar otra solicitud</button>
      </section> : <>
        <form className="mica-cliente-tarjeta" onSubmit={simular}>
          <h2>1. Cuéntanos sobre tu evento</h2>
          <div className="mica-cliente-campos">
            <label>Tipo de evento <input required maxLength="100" value={evento.tipo_evento} onChange={e=>cambiarEvento('tipo_evento',e.target.value)} /></label>
            <label>Fecha estimada <input type="date" min={hoy()} required value={evento.fecha} onChange={e=>cambiarEvento('fecha',e.target.value)} /></label>
            <label>Número de asistentes <input type="number" min="1" max="2000" required value={evento.personas} onChange={e=>cambiarEvento('personas',e.target.value)} /></label>
            <label>Presupuesto máximo (CLP) <input type="number" min="1" required value={evento.presupuesto} onChange={e=>cambiarEvento('presupuesto',e.target.value)} /></label>
            <label className="mica-cliente-ancho">Lugar o comuna del evento <input required maxLength="300" value={evento.ubicacion} onChange={e=>cambiarEvento('ubicacion',e.target.value)} placeholder="Ej. Quinta Normal, Santiago" /></label>
            <label>¿Qué necesitas para tu evento?
              <select value={evento.grupo} onChange={e=>cambiarEvento('grupo',e.target.value)}>
                <option value="salados">Preparaciones saladas</option>
                <option value="dulces">Preparaciones dulces</option>
                <option value="bebidas_frias">Bebidas frías</option>
                <option value="bebidas_calientes">Bebidas calientes</option>
              </select>
            </label>
            <label>Tipo de preparación
              <select value={evento.tipo_preparacion} onChange={e=>cambiarEvento('tipo_preparacion',e.target.value)}>
                {(tiposPorGrupo[evento.grupo] || []).map(t=><option key={t.id} value={t.id}>{t.nombre}</option>)}
              </select>
            </label>
            <label className="mica-cliente-ancho">Preparación específica (opcional)
              <select value={evento.ficha_ids[0] || ''} onChange={e=>cambiarEvento('ficha_ids',e.target.value ? [Number(e.target.value)] : [])}>
                <option value="">Comparar hasta tres alternativas de este tipo</option>
                {preparaciones.filter(p=>p.tipo_preparacion===evento.tipo_preparacion).map(p=><option key={p.id} value={p.id}>{p.nombre}</option>)}
              </select>
              {!preparaciones.some(p=>p.tipo_preparacion===evento.tipo_preparacion) &&
                <small className="mica-cliente-aviso">Aún no hay fichas activas de esta categoría. El personal debe incorporar sus recetas antes de cotizarlas.</small>}
            </label>
          </div>
          <p className="mica-cliente-aviso">Si tienes alergias o restricciones alimentarias, consulta directamente al personal. No ofrecemos una garantía automática sobre alérgenos.</p>
          <button type="submit" disabled={enviando}>{enviando?'Calculando propuestas…':'Consultar propuestas con MICA'}</button>
        </form>
        {resultado && <section className="mica-cliente-tarjeta"><h2>2. Alternativas para comparar</h2>
          <p className="mica-cliente-aviso">{resultado.explicacion?.mensaje} <small>({resultado.explicacion?.modo==='ia'?`IA activa: ${resultado.explicacion.proveedor === 'openai' ? 'GPT (OpenAI)' : 'Groq'} · ${resultado.explicacion.modelo || 'modelo configurado'}`:'Explicación por reglas · sin IA activa'})</small></p>
          <div className="mica-cliente-propuestas">{(resultado.propuestas||[]).map(p=><article className={`mica-cliente-propuesta ${elegida?.id_ficha_tecnica===p.id_ficha_tecnica?'elegida':''}`} key={p.id_ficha_tecnica}>
            <h3>{p.preparacion}</h3><small>{p.nombre}</small><strong>{CLP(p.precio_total)}</strong><span>{CLP(p.precio_persona)} por persona</span>
            {p.descripcion && <p>{p.descripcion}</p>}
            {p.comentario && <p>{p.comentario}</p>}
            <p>{p.dentro_presupuesto?'Dentro de tu presupuesto':'Supera tu presupuesto'} · {p.requiere_compra?'Insumos por reponer':'Disponibilidad estimada; sujeto a confirmación'}</p>
            <button type="button" disabled={!p.dentro_presupuesto} onClick={()=>setElegida(p)}>{elegida?.id_ficha_tecnica===p.id_ficha_tecnica?'✓ Seleccionada':'Seleccionar esta opción'}</button>
          </article>)}</div>
          {!(resultado.propuestas||[]).length && <p>No hay preparaciones válidas con estos datos. Revisa los parámetros o contacta al personal.</p>}
          {(resultado.avisos||[]).map((a,i)=><p className="mica-cliente-aviso" key={i}>• {a}</p>)}
        </section>}
        {elegida && <form className="mica-cliente-tarjeta" onSubmit={enviar}><h2>3. Enviar solicitud de {elegida.preparacion}</h2>
          <p>Estimación seleccionada: <strong>{CLP(elegida.precio_total)}</strong>. No se cobrará ni confirmará el evento automáticamente.</p>
          <div className="mica-cliente-campos">
            <label>Nombre <input required maxLength="150" value={contacto.nombre} onChange={e=>setContacto(c=>({...c,nombre:e.target.value}))}/></label>
            <label>Apellido <input required maxLength="100" value={contacto.apellido} onChange={e=>setContacto(c=>({...c,apellido:e.target.value}))}/></label>
            <label>Correo electrónico <input type="email" required value={contacto.email} maxLength="150" onChange={e=>setContacto(c=>({...c,email:e.target.value}))}/></label>
            <label>Teléfono <input type="tel" required maxLength="30" value={contacto.telefono} onChange={e=>setContacto(c=>({...c,telefono:e.target.value}))}/></label>
            <label className="mica-cliente-ancho">Comentarios para el equipo <textarea maxLength="1500" value={contacto.comentario} onChange={e=>setContacto(c=>({...c,comentario:e.target.value}))} placeholder="Ej. horario de inicio, montaje, necesidades especiales"/></label>
          </div>
          <label className="mica-cliente-aceptar"><input type="checkbox" required checked={contacto.acepta_condiciones} onChange={e=>setContacto(c=>({...c,acepta_condiciones:e.target.checked}))}/> Autorizo usar mis datos de contacto para gestionar esta solicitud y entiendo que el pedido queda pendiente de aprobación.</label>
          <button type="submit" disabled={enviando}>{enviando?'Enviando solicitud…':'Enviar solicitud y registrar pedido pendiente'}</button>
        </form>}
      </>}
    </div>
  </main>;
}
