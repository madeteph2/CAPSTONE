import logoMaya from './assets/logo_maya.png';
import { useCallback, useEffect, useState } from 'react';
import './MicaVista.css';
import PaquetesAdmin from './PaquetesAdmin.jsx'; // MICA_PAQUETES_V25B2_ADMIN

const normalizar = v => Array.isArray(v) ? v : Array.isArray(v?.results) ? v.results : v?.eventos || [];
const clp = v => new Intl.NumberFormat('es-CL', {style: 'currency', currency: 'CLP', maximumFractionDigits: 0}).format(Number(v || 0));
const formatoCantidad = valor =>
  new Intl.NumberFormat('es-CL', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 6
  }).format(Number(valor));
const hoy = new Date().toLocaleDateString('en-CA');
const inicial = { cliente_id: '', evento_id: '', personas: '80', presupuesto: '1200000',
  fecha: hoy, ubicacion: '', tipo_evento: 'Evento familiar',
  costo_personal: '0', costo_transporte: '0', otros_costos: '0', margen: '30', ficha_ids: '', restricciones: '' };

export default function MicaVista({ csrfToken }) {
  const [form, setForm] = useState(inicial);
  const [clientes, setClientes] = useState([]);
  const [eventos, setEventos] = useState([]);
  const [fichas, setFichas] = useState([]);
  const [historial, setHistorial] = useState([]);
  const [propuestas, setPropuestas] = useState([]);
  const [guardada, setGuardada] = useState(null);
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);
  const [confirmarCompra, setConfirmarCompra] = useState(false);
  const [explicacion, setExplicacion] = useState(null);
  const cambiar = (campo, valor) => setForm(f => ({...f, [campo]: valor}));

  const petición = useCallback(async (ruta, method = 'GET', body) => {
    const res = await fetch(ruta, {
      method, credentials: 'same-origin',
      headers: method === 'GET' ? {} : {'Content-Type': 'application/json', 'X-CSRFToken': csrfToken},
      ...(body ? {body: JSON.stringify(body)} : {})
    });
    const datos = await res.json().catch(() => ({}));
    if (!res.ok) throw Error(JSON.stringify(datos, null, 2) || `Error HTTP ${res.status}`);
    return datos;
  }, [csrfToken]);

  const recargar = useCallback(async () => {
    const lista = await petición('/api/mica/cotizaciones/');
    setHistorial(lista);
  }, [petición]);

  useEffect(() => {
    let activo = true;
    Promise.all(['/api/clientes/', '/api/eventos/', '/api/fichas-tecnicas/'].map(r => petición(r)))
      .then(([cs, es, fs]) => {
        if (!activo) return;
        setClientes(normalizar(cs)); setEventos(normalizar(es)); setFichas(normalizar(fs));
      })
      .catch(e => {if (activo) setError(`No se pudo cargar el catálogo: ${e.message}`);});
    recargar().catch(e => {if (activo) setError(e.message);});
    return () => {activo = false;};
  }, [petición, recargar]);

  const eventoElegido = eventos.find(e => String(e.id_evento) === String(form.evento_id));
  const eventosCliente = eventos.filter(e => String(e.id_cliente) === String(form.cliente_id));
  const payload = () => ({
    cliente_id: Number(form.cliente_id),
    ...(form.evento_id ? {evento_id: Number(form.evento_id)} : {fecha: form.fecha, ubicacion: form.ubicacion, tipo_evento: form.tipo_evento}),
    personas: Number(form.personas), presupuesto: form.presupuesto, margen: form.margen,
    costo_personal: form.costo_personal, costo_transporte: form.costo_transporte, otros_costos: form.otros_costos,
    restricciones: form.restricciones.split(',').map(s => s.trim()).filter(Boolean),
    ...(form.ficha_ids ? {ficha_ids: [Number(form.ficha_ids)]} : {})
  });
  const procesar = async guardar => {
    setCargando(true); setError(''); setMensaje(''); setExplicacion(null);
    try {
      const datos = await petición(guardar ? '/api/mica/cotizaciones/' : '/api/mica/simular/', 'POST', payload());
      setPropuestas(datos.propuestas || []);
      setGuardada(guardar ? datos : null);
      if (guardar) {setMensaje(`Cotización MICA #${datos.id} guardada con costos congelados.`); await recargar();}
      else setMensaje(datos.propuestas?.length ? 'Simulación calculada por Django. No se guardó todavía.' : datos.mensaje || 'No hay alternativas válidas.');
      if (datos.descartadas?.length) setMensaje(x => `${x} Preparaciones descartadas: ${datos.descartadas.length}. Revisa fichas, rendimientos y unidades.`);
    } catch (e) {setError(e.message);}
    finally {setCargando(false);}
  };
  const aceptar = async p => {
    if (!guardada?.id || !p.id || guardada.estado !== 'borrador') return;
    setCargando(true); setError(''); setMensaje('');
    try {
      const datos = await petición(`/api/mica/cotizaciones/${guardada.id}/aceptar/`, 'POST',
        {propuesta_id: p.id, compra_confirmada: confirmarCompra});
      setMensaje(`Propuesta aceptada. Pedido ${datos.numero_pedido} registrado correctamente.`);
      setGuardada({...guardada, estado: 'aceptada', pedido_id: datos.pedido_id});
      await recargar();
    } catch (e) {setError(e.message);}
    finally {setCargando(false);}
  };
  const explicar = async () => {
    if (!guardada?.id) return;
    setCargando(true); setError('');
    try {setExplicacion(await petición(`/api/mica/cotizaciones/${guardada.id}/explicar/`, 'POST', {}));}
    catch (e) {setError(e.message);}
    finally {setCargando(false);}
  };
  const revisarPublica = async (c, accion) => {
    if (c.origen !== 'publico' || c.estado !== 'pendiente_revision') return;
    const esAprobacion = accion === 'aprobar';
    const pregunta = esAprobacion
      ? `¿Confirmar el pedido ${c.numero_pedido}? Verifica el evento, los costos, el stock y edita el pedido antes si corresponde.`
      : `¿Rechazar la solicitud ${c.numero_pedido}?`;
    if (!window.confirm(pregunta)) return;
    const nota = window.prompt('Motivo u observaciones de revisión (opcional):', '');
    if (nota === null) return;
    // La aprobación ahora exige stock libre; una compra prometida no aumenta existencias.
    setCargando(true); setError(''); setMensaje('');
    try {
      const respuesta = await petición(`/api/mica/cotizaciones/${c.id}/revision/`, 'POST',
        {accion, nota});
      setMensaje(`Pedido ${respuesta.numero_pedido} actualizado a ${respuesta.estado}. Reservas creadas: ${respuesta.reservas_creadas}. Consulta el detalle en Pedidos.`);
      setGuardada(null); setPropuestas([]);
      await recargar();
    } catch(e) { setError(e.message); }
    finally { setCargando(false); }
  };
  // MICA_RESERVAS_V2_3: permite liberar reservas de pedidos aún no preparados.
  const cancelarConfirmado = async c => {
    if (!window.confirm(`¿Cancelar ${c.numero_pedido} y liberar las reservas de insumos?`)) return;
    const nota = window.prompt('Motivo de cancelación:', '');
    if (nota === null) return;
    setCargando(true); setError(''); setMensaje('');
    try {
      const respuesta = await petición(`/api/mica/cotizaciones/${c.id}/cancelar/`, 'POST', {nota});
      setMensaje(`Pedido ${respuesta.numero_pedido} cancelado; ${respuesta.reservas_liberadas} reservas liberadas.`);
      await recargar();
    } catch (e) { setError(e.message); }
    finally { setCargando(false); }
  };
  // MICA_CONSUMO_V2_4: solo se puede preparar un pedido público confirmado.
  const iniciarPreparacion = async c => {
    if (!window.confirm(`¿Iniciar preparación de ${c.numero_pedido}? Esta acción DESCUENTA los ingredientes reservados y no puede repetirse.`)) return;
    setCargando(true); setError(''); setMensaje('');
    try {
      const r = await petición(`/api/mica/cotizaciones/${c.id}/iniciar-preparacion/`, 'POST', {});
      setMensaje(`Pedido ${r.numero_pedido}: EN PREPARACION. Consumos registrados: ${r.movimientos_creados}. Stock físico actualizado.`);
      await recargar();
      window.scrollTo({top:0, behavior:'smooth'});
    } catch(e) {
      setError(e.message);
      window.scrollTo({top:0, behavior:'smooth'});
    } finally { setCargando(false); }
  };
  const verGuardada = c => {
    setGuardada(c); setPropuestas(c.propuestas);
    setMensaje(`Mostrando cotización MICA #${c.id} (${c.estado}).`);
    setError(''); setExplicacion(null);
  };
  const mostrarNuevamente = () => {setGuardada(null); setPropuestas([]); setExplicacion(null); setMensaje(''); setError('');};

  return <div className="mica">
    <div className="maya-marca maya-marca-admin"><span className="maya-logo-reserva" role="img" aria-label="Logotipo Banquetería Maya"><img src={logoMaya} alt="" className="maya-logo" /></span><div className="maya-marca-texto"><strong className="maya-marca-nombre">Banquetería Maya</strong><span className="maya-marca-subtitulo">Administración de cotizaciones · MICA</span></div></div>
    <div className="w03-heading"><div className="w02-intro"><div className="w02-breadcrumb">Inicio / Cotizador MICA</div>
      <h1>MICA · Cotizador inteligente</h1><p>Calcula propuestas desde fichas técnicas, ingredientes y costos reales. IA opcional (Groq con límite gratuito o GPT por API de pago).</p></div></div>
    {error && <div className="w02-message w02-error" role="alert"><strong>Revisa los datos:</strong><pre className="mica-error">{error}</pre></div>}
    {mensaje && <div className="w04-success" role="status">{mensaje}</div>}
    <section className="w02-card mica-card"><h2>1 · Datos de la solicitud</h2>
      <div className="mica-grid">
        <label className="w04-field"><span>Cliente *</span><select value={form.cliente_id} onChange={e => {cambiar('cliente_id', e.target.value); setForm(f=>({...f, cliente_id:e.target.value,evento_id:''}));}}>
          <option value="">Seleccionar cliente</option>{clientes.map(c => <option key={c.id_cliente} value={c.id_cliente}>{c.nombre} {c.apellido || ''}</option>)}
        </select></label>
        <label className="w04-field"><span>Evento existente (opcional)</span><select value={form.evento_id} onChange={e=>{const v=e.target.value; const eobj=eventos.find(x=>String(x.id_evento)===v);setForm(f=>({...f, evento_id:v, ...(eobj?.cantidad_personas ? {personas:String(eobj.cantidad_personas)} : {})}));}}>
          <option value="">Cotizar evento nuevo</option>{eventosCliente.map(e => <option key={e.id_evento} value={e.id_evento}>{e.nombre_evento} · {e.fecha_evento}</option>)}
        </select></label>
        <label className="w04-field"><span>Comensales *</span><input type="number" min="1" value={form.personas} disabled={Boolean(eventoElegido?.cantidad_personas)} onChange={e=>cambiar('personas',e.target.value)} /></label>
        <label className="w04-field"><span>Presupuesto máximo (CLP) *</span><input type="number" min="1" value={form.presupuesto} onChange={e=>cambiar('presupuesto',e.target.value)} /></label>
        {!form.evento_id && <>
          <label className="w04-field"><span>Fecha *</span><input type="date" value={form.fecha} onChange={e=>cambiar('fecha', e.target.value)} /></label>
          <label className="w04-field"><span>Ubicación *</span><input value={form.ubicacion} onChange={e=>cambiar('ubicacion', e.target.value)} placeholder="Comuna o dirección del evento" /></label>
          <label className="w04-field"><span>Tipo de evento</span><input value={form.tipo_evento} onChange={e=>cambiar('tipo_evento',e.target.value)} /></label>
        </>}
        <label className="w04-field"><span>Preparación específica (opcional)</span><select value={form.ficha_ids} onChange={e=>cambiar('ficha_ids',e.target.value)}>
          <option value="">Comparar fichas disponibles</option>{fichas.filter(f=>String(f.estado).toLowerCase()==='activo').map(f=><option key={f.id_ficha_tecnica} value={f.id_ficha_tecnica}>{f.nombre_ficha}</option>)}
        </select></label>
        <label className="w04-field"><span>Restricciones alimentarias</span><input value={form.restricciones} onChange={e=>cambiar('restricciones',e.target.value)} placeholder="Ej. sin gluten, vegetariano" /></label>
      </div>
      <p className="w02-note">Si se indican restricciones alimentarias, MICA exige revisión humana hasta contar con información validada de alérgenos. No las ignora ni afirma seguridad alimentaria.</p>
    </section>
    <section className="w02-card mica-card"><h2>2 · Costos de servicio (CLP)</h2>
      <div className="mica-grid">
      {['costo_personal','costo_transporte','otros_costos','margen'].map(k=><label key={k} className="w04-field"><span>{{costo_personal:'Personal',costo_transporte:'Transporte',otros_costos:'Otros costos',margen:'Margen % (mínimo configurado)'}[k]}</span>
      <input type="number" min="0" step="0.01" value={form[k]} onChange={e=>cambiar(k,e.target.value)}/></label>)}
      </div>
      <div className="w04-actions"><button type="button" className="w04-secondary" disabled={cargando || !form.cliente_id} onClick={()=>procesar(false)}>Simular sin guardar</button>
        <button type="button" className="w03-primary" disabled={cargando || !form.cliente_id} onClick={()=>procesar(true)}>Guardar cotización</button></div>
    </section>
    {propuestas.length > 0 && <section className="w02-card mica-card"><h2>3 · Propuestas calculadas</h2>
      <p className="w02-note">Cada propuesta corresponde a una preparación del catálogo; no representa un menú completo con varios tiempos. Precios e ingredientes salen exclusivamente de Django.</p>
      <div className="mica-propuestas">{propuestas.map((p,i)=><div key={p.id||i} className="mica-propuesta">
        <h3>{p.nombre} · {p.preparacion}</h3>
        <div className="mica-precio">{clp(p.precio_total)}</div><p>{clp(p.precio_persona)} por persona</p>
        <p><strong>{p.dentro_presupuesto ? 'Dentro del presupuesto' : `Supera presupuesto por ${clp(p.exceso_presupuesto)}`}</strong></p>
        <p>{p.requiere_compra ? '⚠ Existen faltantes de stock' : 'Stock consultado suficiente'}</p>
        <details><summary>Ingredientes, cantidades y costo interno (solo administración)</summary>
          <table className="mica-table"><tbody>{p.ingredientes.map(i=><tr key={i.id_insumo}>
<td>{formatoCantidad(i.cantidad)} {i.unidad}</td><td>{clp(i.subtotal)}</td></tr>)}</tbody></table><p>Costo total: {clp(p.costo_total)} · Margen: {p.margen}%</p></details>
        {guardada?.estado==='borrador' && p.id && p.dentro_presupuesto && <button type="button" className="w03-primary" disabled={cargando} onClick={()=>aceptar(p)}>Aceptar y generar pedido</button>}
      </div>)}</div>
      {guardada?.estado==='borrador' && <label className="mica-check"><input type="checkbox" checked={confirmarCompra} onChange={e=>setConfirmarCompra(e.target.checked)}/> Confirmo que se gestionará la compra de faltantes, si corresponde.</label>}
      {guardada?.id && <div className="w04-actions"><button type="button" className="w04-secondary" disabled={cargando} onClick={explicar}>Explicar propuestas (IA opcional)</button><button type="button" className="w04-secondary" onClick={mostrarNuevamente}>Nueva solicitud</button></div>}
      {explicacion && <p className="w04-success">{explicacion.mensaje} <small>({explicacion.modo==='ia'?`IA activa: ${explicacion.proveedor === 'openai' ? 'GPT (OpenAI)' : 'Groq'} · ${explicacion.modelo || ''}`:'Reglas sin IA'})</small></p>}
    </section>}
    <section className="w02-card mica-card"><h2>Solicitudes de consumidores pendientes de revisión</h2>
      <p className="w02-note">Cada solicitud externa ya registró un pedido CREADO. Al aprobar se reservan insumos; si faltan, primero registre la reposición en Inventario. La aprobación no descuenta existencias físicas.</p>
      <div className="w02-table-scroll"><table className="w05-table mica-table"><thead><tr>
        <th>Pedido</th><th>Cliente / contacto</th><th>Evento</th><th>Precio estimado</th><th>Acciones</th>
      </tr></thead><tbody>{historial.filter(c=>c.origen==='publico' && c.estado==='pendiente_revision').map(c=>{
        const seleccion = c.propuestas?.find(p=>Number(p.id)===Number(c.propuesta_aceptada));
        return <tr key={c.id}><td>{c.numero_pedido || `#${c.pedido_id}`}<br/><small>Cotización #{c.id}</small></td>
          <td>{c.cliente_nombre}<br/><small>{c.cliente_email} · {c.cliente_telefono}</small></td>
          <td>{c.requisitos?.tipo_evento}<br/><small>{c.requisitos?.fecha} · {c.requisitos?.ubicacion}</small></td>
          <td>{clp(c.precio_pedido_actual || seleccion?.precio_total)}<br/><small>{seleccion?.preparacion}</small></td>
          <td><div className="w04-actions"><button type="button" className="w04-secondary" onClick={()=>verGuardada(c)}>Ver</button>
          <button type="button" className="w03-primary" disabled={cargando} onClick={()=>revisarPublica(c,'aprobar')}>Aprobar</button>
          <button type="button" className="w04-secondary" disabled={cargando} onClick={()=>revisarPublica(c,'rechazar')}>Rechazar</button></div></td></tr>;
      })}{!historial.some(c=>c.origen==='publico' && c.estado==='pendiente_revision') && <tr><td colSpan="5">No hay solicitudes externas pendientes.</td></tr>}</tbody></table></div>
    </section>
    <section className="w02-card mica-card"><h2>Pedidos confirmados · reservas de ingredientes</h2>
      <p className="w02-note">Al aprobar un pedido público se reservan los insumos disponibles por bodega. El stock físico NO disminuye hasta registrar el consumo. Si se cancela antes de preparar, se liberan las reservas.</p>
      <div className="w02-table-scroll"><table className="w05-table mica-table"><thead><tr><th>Pedido</th><th>Estado</th><th>Reservas</th><th>Acciones</th></tr></thead>
        <tbody>{historial.filter(c=>c.origen==='publico' && c.estado==='aprobada' && c.pedido_estado==='CONFIRMADO').map(c=><tr key={c.id}>
          <td>{c.numero_pedido}</td><td>{c.pedido_estado}</td><td>{c.reservas_activas} registros</td>
          <td><div className="w04-actions"><button type="button" className="w03-primary" disabled={cargando} onClick={()=>iniciarPreparacion(c)}>Iniciar preparación y consumir</button><button type="button" className="w04-secondary" disabled={cargando} onClick={()=>cancelarConfirmado(c)}>Cancelar y liberar reservas</button></div></td>
        </tr>)}
        {!historial.some(c=>c.origen==='publico' && c.estado==='aprobada' && c.pedido_estado==='CONFIRMADO') && <tr><td colSpan="4">Sin pedidos públicos confirmados con reservas.</td></tr>}
        </tbody></table></div>
    </section>
    <section className="w02-card mica-card"><h2>Pedidos en preparación · consumo registrado</h2>
      <p className="w02-note">Estos pedidos ya descontaron sus reservas del inventario físico. No inicie la preparación por segunda vez.</p>
      <div className="w02-table-scroll"><table className="w05-table mica-table"><thead><tr><th>Pedido</th><th>Estado</th><th>Reservas pendientes</th></tr></thead><tbody>
        {historial.filter(c=>c.origen==='publico' && c.estado==='aprobada' && c.pedido_estado==='EN_PREPARACION').map(c=><tr key={c.id}><td>{c.numero_pedido}</td><td>{c.pedido_estado}</td><td>{c.reservas_activas}</td></tr>)}
        {!historial.some(c=>c.origen==='publico' && c.estado==='aprobada' && c.pedido_estado==='EN_PREPARACION') && <tr><td colSpan="3">Aún no hay pedidos públicos en preparación.</td></tr>}
      </tbody></table></div>
    </section>
    <PaquetesAdmin csrfToken={csrfToken} />
    <section className="w02-card mica-card"><h2>Cotizaciones guardadas</h2><div className="w02-table-scroll">
      <table className="w05-table mica-table"><thead><tr><th>ID</th><th>Cliente</th><th>Personas</th><th>Presupuesto</th><th>Origen</th><th>Estado</th><th>Ver</th></tr></thead>
      <tbody>{historial.map(c=><tr key={c.id}><td>#{c.id}</td><td>#{c.cliente_id}</td><td>{c.personas}</td><td>{clp(c.presupuesto)}</td><td>{c.origen}</td><td>{c.estado}</td>
        <td><button type="button" className="w04-secondary" onClick={()=>verGuardada(c)}>Ver</button></td></tr>)}
      {!historial.length && <tr><td colSpan="7">Sin cotizaciones MICA todavía.</td></tr>}</tbody></table></div>
    </section>
    <p className="w02-note">MICA opera con sesiones Django y API REST. La futura app Android podrá utilizar los mismos contratos con un esquema de autenticación móvil dedicado.</p>
  </div>;
}
