import { useCallback, useEffect, useState } from 'react';

// MICA_PAQUETES_V25B2_ADMIN: catálogo administrativo, sin reservar ni cotizar.
const TIPOS = [
  ['coffee_break', 'Coffee break'], ['coctel', 'Cóctel'],
  ['almuerzo', 'Almuerzo'], ['cena', 'Cena'],
  ['banquete', 'Banquete'], ['personalizado', 'Personalizado'],
];
const vacio = () => ({ nombre: '', tipo_servicio: 'coffee_break', descripcion: '', componentes: [{ id_ficha_tecnica: '', cantidad_por_persona: '1' }] });
const comoLista = d => Array.isArray(d) ? d : Array.isArray(d?.results) ? d.results : Array.isArray(d?.fichas) ? d.fichas : [];

export default function PaquetesAdmin({ csrfToken }) {
  const [paquetes, setPaquetes] = useState([]);
  const [fichas, setFichas] = useState([]);
  const [form, setForm] = useState(vacio);
  const [edicion, setEdicion] = useState(null);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState('');
  const [mensaje, setMensaje] = useState('');

  const api = useCallback(async (ruta, metodo = 'GET', datos) => {
    const r = await fetch(ruta, {
      method: metodo, credentials: 'same-origin',
      headers: metodo === 'GET' ? {} : { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken },
      ...(datos !== undefined ? { body: JSON.stringify(datos) } : {}),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw Error(typeof d.detail === 'string' ? d.detail : JSON.stringify(d));
    return d;
  }, [csrfToken]);
  const cargar = useCallback(async () => {
    const p = await api('/api/mica/paquetes/');
    setPaquetes(p.paquetes || []);
  }, [api]);
  useEffect(() => {
    let activo = true;
    Promise.all([api('/api/mica/paquetes/'), api('/api/fichas-tecnicas/')])
      .then(([p, f]) => {
        if (!activo) return;
        setPaquetes(p.paquetes || []);
        setFichas(comoLista(f).filter(x => String(x.estado || '').toLowerCase() === 'activo'));
      })
      .catch(e => { if (activo) setError(`No se pudo cargar el catálogo: ${e.message}`); });
    return () => { activo = false; };
  }, [api]);

  const modificarComponente = (indice, campo, valor) => setForm(v => ({
    ...v, componentes: v.componentes.map((c, i) => i === indice ? { ...c, [campo]: valor } : c),
  }));
  const editar = p => {
    setEdicion(p.id);
    setForm({ nombre: p.nombre, tipo_servicio: p.tipo_servicio, descripcion: p.descripcion,
      componentes: p.componentes.map(c => ({ id_ficha_tecnica: String(c.id_ficha_tecnica), cantidad_por_persona: String(c.cantidad_por_persona) })),
    });
    setMensaje(''); setError('');
  };
  const limpiar = () => { setForm(vacio()); setEdicion(null); setError(''); };
  const guardar = async e => {
    e.preventDefault(); setCargando(true); setError(''); setMensaje('');
    try {
      const componentes = form.componentes.map(c => ({
        id_ficha_tecnica: Number(c.id_ficha_tecnica), cantidad_por_persona: c.cantidad_por_persona,
      }));
      if (componentes.some(c => !Number.isInteger(c.id_ficha_tecnica) || c.id_ficha_tecnica < 1 || !(Number(c.cantidad_por_persona) > 0))) {
        throw Error('Cada componente requiere una ficha y cantidad positiva por persona.');
      }
      const ruta = edicion ? `/api/mica/paquetes/${edicion}/` : '/api/mica/paquetes/';
      const respuesta = await api(ruta, edicion ? 'PUT' : 'POST', { ...form, componentes });
      await cargar(); limpiar();
      setMensaje(`Paquete «${respuesta.nombre}» ${edicion ? 'actualizado' : 'creado'} correctamente.`);
    } catch (e) { setError(e.message); }
    finally { setCargando(false); }
  };
  const alternar = async p => {
    if (!window.confirm(`${p.activo ? 'Desactivar' : 'Activar'} el paquete «${p.nombre}»?`)) return;
    setCargando(true); setError(''); setMensaje('');
    try {
      await api(`/api/mica/paquetes/${p.id}/`, 'PATCH', { activo: !p.activo });
      await cargar(); setMensaje(`Estado de «${p.nombre}» actualizado.`);
    } catch (e) { setError(e.message); }
    finally { setCargando(false); }
  };

  return <section className="w02-card mica-card" id="mica-paquetes-admin">
    <h2>Catálogo comercial · Paquetes de banquetería</h2>
    <p className="w02-note">Crea paquetes con varias fichas y sus unidades terminadas por persona. Por ahora se almacenan en el catálogo: NO generan cotizaciones, pedidos ni reservas.</p>
    {error && <div className="w02-message w02-error" role="alert">{error}</div>}
    {mensaje && <div className="w04-success" role="status">{mensaje}</div>}
    <div className="w02-table-scroll"><table className="w05-table mica-table"><thead><tr>
      <th>Paquete</th><th>Servicio</th><th>Preparaciones</th><th>Estado</th><th>Acciones</th>
    </tr></thead><tbody>
      {paquetes.map(p => <tr key={p.id}>
        <td>{p.nombre}</td><td>{TIPOS.find(t => t[0] === p.tipo_servicio)?.[1] || p.tipo_servicio}</td>
        <td>{p.componentes.map(c => `${c.nombre_ficha} (${c.cantidad_por_persona}/persona)`).join('; ')}</td>
        <td>{p.activo ? 'Activo' : 'Inactivo'}</td>
        <td><div className="w04-actions">
          <button type="button" className="w04-secondary" disabled={cargando} onClick={() => editar(p)}>Editar</button>
          <button type="button" className="w04-secondary" disabled={cargando} onClick={() => alternar(p)}>{p.activo ? 'Desactivar' : 'Activar'}</button>
        </div></td>
      </tr>)}
      {!paquetes.length && <tr><td colSpan="5">Todavía no se han creado paquetes.</td></tr>}
    </tbody></table></div>
    <form onSubmit={guardar}>
      <h3>{edicion ? `Editar paquete #${edicion}` : 'Crear paquete'}</h3>
      <div className="mica-grid">
        <label className="w04-field"><span>Nombre del paquete *</span><input required maxLength="150" value={form.nombre} onChange={e => setForm(v => ({ ...v, nombre: e.target.value }))}/></label>
        <label className="w04-field"><span>Tipo de servicio *</span><select value={form.tipo_servicio} onChange={e => setForm(v => ({ ...v, tipo_servicio: e.target.value }))}>
          {TIPOS.map(([v, nombre]) => <option key={v} value={v}>{nombre}</option>)}
        </select></label>
        <label className="w04-field"><span>Descripción</span><textarea maxLength="2000" value={form.descripcion} onChange={e => setForm(v => ({ ...v, descripcion: e.target.value }))}/></label>
      </div>
      <h3>Preparaciones del paquete</h3>
      {form.componentes.map((c, i) => <div className="mica-grid" key={i}>
        <label className="w04-field"><span>Preparación #{i + 1}</span><select required value={c.id_ficha_tecnica} onChange={e => modificarComponente(i, 'id_ficha_tecnica', e.target.value)}>
          <option value="">Selecciona una ficha</option>
          {fichas.map(f => <option key={f.id_ficha_tecnica} value={f.id_ficha_tecnica}>{f.nombre_ficha} · {f.tipo_preparacion || 'Sin tipo'}</option>)}
        </select></label>
        <label className="w04-field"><span>Unidades terminadas por persona</span><input type="number" required min="0.001" step="0.001" value={c.cantidad_por_persona} onChange={e => modificarComponente(i, 'cantidad_por_persona', e.target.value)}/></label>
        <div className="w04-actions"><button type="button" className="w04-secondary" disabled={form.componentes.length === 1} onClick={() => setForm(v => ({ ...v, componentes: v.componentes.filter((_, j) => j !== i) }))}>Quitar</button></div>
      </div>)}
      <div className="w04-actions">
        <button type="button" className="w04-secondary" disabled={form.componentes.length >= 30} onClick={() => setForm(v => ({ ...v, componentes: [...v.componentes, { id_ficha_tecnica: '', cantidad_por_persona: '1' }] }))}>+ Añadir preparación</button>
        <button type="submit" className="w03-primary" disabled={cargando}>{cargando ? 'Guardando…' : edicion ? 'Guardar cambios' : 'Crear paquete'}</button>
        {edicion && <button type="button" className="w04-secondary" onClick={limpiar}>Cancelar edición</button>}
      </div>
    </form>
  </section>;
}
