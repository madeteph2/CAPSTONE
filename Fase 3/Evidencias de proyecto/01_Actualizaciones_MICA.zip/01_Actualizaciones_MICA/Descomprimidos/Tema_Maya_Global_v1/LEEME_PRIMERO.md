# Banquetería Maya — Tema borgoña GLOBAL v1

Aplica identidad visual global a login, dashboard, menú lateral y los módulos que comparten los estilos `App.css`, además de mantener coherencia con MICA y la página pública `/cotizar`.

## Archivos

- `archivos/TemaMayaGlobal.css` (nuevo): colores, tipografía y componentes globales.
- `archivos/aplicar_tema_maya_global.py`: inserta el import global y reemplaza las dos tazas del login/sidebar por espacio **BM**. **No sobrescribe `App.css` ni `index.css`**.

**Compatible con** el tema MICA Borgoña v1, esté instalado o no. No afecta API, migraciones ni PostgreSQL.

## Simulación (no modifica)

```powershell
$Proyecto = 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Banqueteria_Proyecto'
$Parche = 'C:\Users\madel\OneDrive\Escritorio\Capstone\01_Actualizaciones_MICA\Descomprimidos\Tema_Maya_Global_v1\archivos\aplicar_tema_maya_global.py'
python $Parche --proyecto $Proyecto
```

## Instalación (solo tras revisar simulación)

```powershell
python $Parche --proyecto $Proyecto --aplicar
cd "$Proyecto\frontend"
npm.cmd run build
```

Guarda copia previa de `frontend/src/App.jsx` bajo `02_Respaldos/Codigo/maya_tema_global_.../`. Si la estructura real de App.jsx es distinta, el instalador aborta **antes de escribir**; en ese caso enviar App.jsx para preparar una versión adaptada.

## Verificación QA

- Pantalla login y espacio de logo BM.
- Sidebar/dashboard con borgoña, crema y botones.
- Un formulario en Clientes y uno de Pedidos.
- Cotizador MICA administrativo y público.
- Comprobar que estados de error/exitoso conservan sus colores propios.

## Personalización posterior del logo

Las dos marcas están identificadas con `maya-logo-slot` dentro de `App.jsx`. Posteriormente se reemplaza ese monograma por una imagen del logotipo en el componente, sin modificar rutas de API ni tablas.
