#!/usr/bin/env python3
"""Instalador visual sin dependencia de Django. Simula por defecto y respalda al aplicar."""
import argparse
from datetime import datetime
from pathlib import Path
from shutil import copy2
import re
import sys

MARCADOR = "MAYA_TEMA_GLOBAL_V1"
ARCHIVOS = Path(__file__).resolve().parent


def lectura(ruta):
    with ruta.open('r', encoding='utf-8', newline='') as f:
        return f.read()


def preparar(app):
    anterior = lectura(app)
    if MARCADOR in anterior:
        raise RuntimeError("El tema global ya figura instalado en App.jsx; no se repetirá.")
    if "TemaMayaGlobal.css" in anterior:
        raise RuntimeError("Ya existe una referencia a TemaMayaGlobal.css; revisar manualmente.")

    # Se usa un punto de importación posterior a App.css para mantener prioridades CSS.
    busqueda = re.compile(r'(?m)^(\s*import\s+[\'\"]\./App\.css[\'\"]\s*;?[ \t]*)(\r?\n)')
    if len(busqueda.findall(anterior)) != 1:
        raise RuntimeError("No se encontró un único import de App.css; no se modificará App.jsx.")
    nuevo = busqueda.sub(lambda m: m.group(1) + m.group(2) + "import './TemaMayaGlobal.css'; // " + MARCADOR + m.group(2), anterior, count=1)
    # Los dos monogramas son la única edición de JSX aparte del import.
    marcas = [
        ('<span className="w01-logo" aria-hidden="true">☕</span>',
         '<span className="w01-logo maya-logo-slot" aria-label="Espacio reservado para el logotipo de Banquetería Maya">BM</span>'),
        ('<span className="w02-brand-icon" aria-hidden="true">☕</span>',
         '<span className="w02-brand-icon maya-logo-slot" aria-label="Espacio reservado para el logotipo de Banquetería Maya">BM</span>')
    ]
    for antes, despues in marcas:
        if nuevo.count(antes) != 1:
            raise RuntimeError(f"La marca existente ya no coincide ({antes[:40]}...). Sin cambios.")
        nuevo = nuevo.replace(antes, despues, 1)
    return anterior, nuevo


def guardar(path, data):
    temp = path.with_name(path.name + '.maya-temporal')
    try:
        with temp.open('w', encoding='utf-8', newline='') as f:
            f.write(data)
        temp.replace(path)
    finally:
        if temp.exists():
            temp.unlink()


def main():
    parser = argparse.ArgumentParser(description='Tema global Banquetería Maya, simulación por defecto')
    parser.add_argument('--proyecto', required=True, help='Ruta MICA_Banqueteria_Proyecto')
    parser.add_argument('--aplicar', action='store_true', help='Instala el cambio')
    args = parser.parse_args()
    p = Path(args.proyecto).expanduser().resolve()
    src = p / 'frontend' / 'src'
    app = src / 'App.jsx'
    app_css = src / 'App.css'
    css_origen = ARCHIVOS / 'TemaMayaGlobal.css'
    css_destino = src / 'TemaMayaGlobal.css'
    for fichero in [app, app_css, css_origen]:
        if not fichero.is_file():
            raise FileNotFoundError(f"Falta {fichero}")
    if css_destino.exists():
        raise RuntimeError("TemaMayaGlobal.css ya existe. No se sobrescribe.")
    original, actualizado = preparar(app)
    print('=== TEMA GLOBAL BANQUETERIA MAYA v1 ===')
    print('Proyecto:', p)
    print('Modifica:', app.relative_to(p))
    print('Crea:', css_destino.relative_to(p))
    print('Alcance: Login, dashboard, navegacion, modulos y cotizadores.')
    print('Sin cambios en BD, Python, APIs ni migraciones.')
    if not args.aplicar:
        print('PLAN CORRECTO. NO SE CAMBIO NINGUN ARCHIVO.')
        return
    bk = p.parent / '02_Respaldos' / 'Codigo' / ('maya_tema_global_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    bk.mkdir(parents=True, exist_ok=False)
    back_app = bk / 'frontend' / 'src' / 'App.jsx'
    back_app.parent.mkdir(parents=True, exist_ok=True)
    copy2(app, back_app)
    try:
        guardar(app, actualizado)
        copy2(css_origen, css_destino)
    except Exception:
        copy2(back_app, app)
        if css_destino.exists():
            css_destino.unlink()
        raise
    print('INSTALACION COMPLETADA. Respaldo:', bk)
    print('Revisar login, dashboard, clientes, pedidos, inventario, MICA y /cotizar.')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('ERROR:', exc, file=sys.stderr)
        sys.exit(1)
