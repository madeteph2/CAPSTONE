# -*- coding: utf-8 -*-
"""MICA v2.5B2: Administración de paquetes (sin cotizar o reservar).

Por defecto solo PLAN; --aplicar copia tras respaldar archivos.
"""
import argparse
from datetime import datetime
from pathlib import Path
import shutil
import sys

MARCA = 'MICA_PAQUETES_V25B2_ADMIN'


def cambiar_uno(texto, antes, despues, ruta):
    n = texto.count(antes)
    if n != 1:
        raise ValueError(f'{ruta}: ancla encontrada {n} veces; se esperaba 1. No se aplica.')
    return texto.replace(antes, despues, 1)


def transformar(nombre, texto):
    if MARCA in texto:
        raise ValueError(f'{nombre}: actualización ya presente.')
    if nombre == 'mica/urls.py':
        if "path('cotizaciones/<int:pk>/iniciar-preparacion/'" not in texto:
            raise ValueError('No se encontró la ruta de consumo v2.4.')
        return cambiar_uno(texto,
            '\nurlpatterns = [\n',
            '\n# MICA_PAQUETES_V25B2_ADMIN\nfrom .paquetes_api import PaquetesListaCrearView, PaquetesDetalleView\n\nurlpatterns = [\n'
            "    path('paquetes/', PaquetesListaCrearView.as_view(), name='mica-paquetes-lista'),\n"
            "    path('paquetes/<int:pk>/', PaquetesDetalleView.as_view(), name='mica-paquetes-detalle'),\n",
            nombre)
    if nombre == 'frontend/src/MicaVista.jsx':
        texto = cambiar_uno(texto,
            "import './MicaVista.css';",
            "import './MicaVista.css';\nimport PaquetesAdmin from './PaquetesAdmin.jsx'; // MICA_PAQUETES_V25B2_ADMIN",
            nombre)
        return cambiar_uno(texto,
            '    <section className="w02-card mica-card"><h2>Cotizaciones guardadas</h2>',
            '    <PaquetesAdmin csrfToken={csrfToken} />\n'
            '    <section className="w02-card mica-card"><h2>Cotizaciones guardadas</h2>',
            nombre)
    raise ValueError('Archivo no admitido: ' + nombre)


def main():
    p = argparse.ArgumentParser(description='MICA v2.5B2 administración (sin migraciones)')
    p.add_argument('--proyecto', required=True)
    p.add_argument('--aplicar', action='store_true')
    args = p.parse_args()
    root = Path(args.proyecto).resolve()
    src = Path(__file__).resolve().parent
    editar = ['mica/urls.py', 'frontend/src/MicaVista.jsx']
    nuevos = ['mica/paquetes_api.py', 'frontend/src/PaquetesAdmin.jsx',
              'mica/tests/test_paquetes_admin_v25b2.py']
    print('=== MICA v2.5B2 — ADMINISTRACIÓN DE PAQUETES ===')
    print('Proyecto:', root)
    try:
        if not (root / 'manage.py').is_file():
            raise ValueError('El proyecto no tiene manage.py en la raíz.')
        if not (root / 'mica/migrations/0004_paquetes_mica.py').is_file():
            raise ValueError('Falta 0004_paquetes_mica. Instale primero la estructura v2.5B2.')
        salidas = {}
        for n in editar:
            f = root / n
            if not f.is_file():
                raise ValueError('Falta ' + n)
            salidas[n] = transformar(n, f.read_text(encoding='utf-8-sig'))
            if n.endswith('.py'):
                compile(salidas[n], n, 'exec')
        for n in nuevos:
            f = src / n
            if not f.is_file():
                raise ValueError('Falta archivo fuente: ' + n)
            if (root / n).exists():
                raise ValueError('Ya existe archivo destino: ' + n)
            if n.endswith('.py'):
                compile(f.read_text(encoding='utf-8-sig'), n, 'exec')
    except (ValueError, OSError, SyntaxError) as e:
        print('PLAN DETENIDO. No se realizaron cambios:', e)
        sys.exit(2)
    print('Modifica:', ', '.join(editar))
    print('Crea:', ', '.join(nuevos))
    print('Sin migraciones ni escrituras en la BD durante instalación.')
    print('No habilita aún cotización ni reserva de paquetes combinados.')
    if not args.aplicar:
        print('PLAN CORRECTO. NO SE CAMBIO NINGUN ARCHIVO.')
        return
    respaldo = root.parent / '02_Respaldos' / 'Codigo' / ('mica_paquetes_admin_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
    respaldo.mkdir(parents=True, exist_ok=False)
    for n in editar:
        destino = respaldo / n
        destino.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / n, destino)
    escritos = []
    try:
        for n in editar:
            f = root / n
            temporal = f.with_suffix(f.suffix + '.tmp_mica_paquetes')
            temporal.write_text(salidas[n], encoding='utf-8')
            temporal.replace(f)
            escritos.append(n)
        for n in nuevos:
            destino = root / n
            destino.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src / n, destino)
            escritos.append(n)
    except Exception:
        for n in editar:
            shutil.copy2(respaldo / n, root / n)
        for n in nuevos:
            if n in escritos:
                (root / n).unlink(missing_ok=True)
        print('ERROR DE INSTALACIÓN: archivos editados restaurados desde respaldo.')
        raise
    print('INSTALACION COMPLETADA. Respaldo:', respaldo)
    print('Siguiente: python manage.py check y pruebas.')


if __name__ == '__main__':
    main()
