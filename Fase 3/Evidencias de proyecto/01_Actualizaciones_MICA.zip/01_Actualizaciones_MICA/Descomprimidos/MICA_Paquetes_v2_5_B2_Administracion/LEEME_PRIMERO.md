# Banquetería Maya / MICA — v2.5B2 Administración de paquetes

Este parche es **incremental** sobre MICA v2.5B2 Estructura (migración 0004 aplicada). **No sustituye** v2.3, v2.4, v2.5A ni v2.5B1.

## Qué incorpora
- API administrativa protegida por `IsAdminUser` de Django REST: `GET` y `POST /api/mica/paquetes/`, `PUT` y `PATCH /api/mica/paquetes/{id}/`.
- Gestión de nombre, tipo de servicio, descripción, lista de fichas y cantidades de **unidades terminadas por comensal**.
- Interfaz de administración integrada en Cotizador MICA: crear, editar, activar y desactivar paquetes.
- Validaciones: fichas activas existentes, cantidades mayores que cero, sin fichas duplicadas, 1–30 componentes y nombre sin duplicados por servicio.
- 8 pruebas de validación del contrato de entrada.

**No genera cotizaciones, pedidos, reservas ni consumos a partir de paquetes**. Esta etapa prepara y permite poblar el catálogo. La fase siguiente incorporará motor de cálculo, snapshot de componentes y compatibilidad en reservas por pedido.

## Instalación
1. Guarda el ZIP en `Capstone/01_Actualizaciones_MICA/ZIP_Originales` y extráelo en `Capstone/01_Actualizaciones_MICA/Descomprimidos`.
2. Desde `MICA_Banqueteria_Proyecto`, activa `.venv`.
3. Simula:

```powershell
$Proyecto = "C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Banqueteria_Proyecto"
$Parche = "C:\Users\madel\OneDrive\Escritorio\Capstone\01_Actualizaciones_MICA\Descomprimidos\MICA_Paquetes_v2_5_B2_Administracion\archivos\aplicar_parche_paquetes_admin.py"
python $Parche --proyecto $Proyecto
```

4. **Solo tras revisar el resultado** usa `python $Parche --proyecto $Proyecto --aplicar`.
5. Desde la raíz del proyecto comprueba:

```powershell
python manage.py check
python manage.py test mica.tests.test_motor mica.tests.test_publico mica.tests.test_reservas mica.tests.test_consumo mica.tests.test_seleccion_v25 mica.tests.test_catalogo_v25b1 mica.tests.test_paquetes_estructura_v25b2 mica.tests.test_paquetes_admin_v25b2
```

Esperamos 45 pruebas (37 anteriores + 8 nuevas) si no se han añadido pruebas externas.

## Seguridad y compatibilidad
- La API exige `is_staff`; las solicitudes de modificación usan el CSRF y la sesión Django ya configurados.
- No se aplican nuevas migraciones.
- El instalador no conecta a la base ni cambia inventario.
- Se crea un respaldo de los dos archivos editados antes de escribir, dentro de `Capstone/02_Respaldos/Codigo`.
- No crear paquetes con el fin de aprobar pedidos hasta implementar la cotización y las reservas combinadas.

## Limitación de validación
Se validó sintaxis Python, simulación del instalador y copia de los archivos sobre una reconstrucción del código de referencia. No se ejecutó el servidor Django, las consultas PostgreSQL ni la interfaz React de la instalación Windows del usuario.
