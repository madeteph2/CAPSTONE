# Banquetería Maya + MICA — Importación segura de fichas, insumos y stock

**Versión del material:** revisión de `fichas_maya_20.json` entregado por la usuaria, para la base local `sig_banqueteria_mica`.

## Resultado de la revisión

- JSON válido: **20 fichas técnicas**, **40 insumos únicos**, **120 líneas de receta**, **60 pasos de preparación**.
- Tipos: 8 platos de fondo, 3 acompañamientos, 4 entradas, 5 postres.
- Todas las sumas de costo, importes por línea y costos por porción son matemáticamente consistentes (redondeo a 2 decimales).
- Las cantidades corresponden a **30 comensales** por ficha, NO a existencias físicas.
- Costos de ejemplo; no incluyen personal, transporte, gastos operativos ni IVA. Margen y precio sugerido en el JSON son 0.
- La base original trae `Arroz` (kg) a CLP 1.200/kg, que también aparece en el JSON. Se reutiliza si coincide el nombre y la unidad; **nunca se duplicará**.
- El código `FT-001` etc. es referencia del JSON. La tabla `ficha_tecnica` existente no tiene columna de código; este importador lo guarda al comienzo de la **descripción**.

## ¿Qué hace el importador?

`importar_fichas_maya.py` realiza, con comprobación previa y dentro de transacción:

1. Identifica y reutiliza insumos que ya existen con mismo nombre y unidad. NO cambia sus costos, stock, QR ni proveedor.
2. Crea los insumos faltantes con los costos del JSON y `stock_minimo = 0` a falta de datos verificados.
3. Crea las fichas nuevas, sus 120 relaciones de ingredientes en `receta` y los 60 pasos de `detalle_preparacion` (y un texto de procedimiento).
4. Para cada insumo que aún no tenga inventario en `Bodega Central`, crea un registro con `stock_actual = 0`.
5. Si la ficha ya existe por nombre, la omite íntegramente: no la duplica ni reemplaza datos. Si existe un nombre duplicado en BD o una unidad incompatible, detiene la importación.
6. Recalcula el costo de cada receta nueva usando **el costo vigente del catálogo de PostgreSQL**, para preservar coherencia si algún precio de BD cambió.

**No modifica stock existente. No registra pedidos ni cotizaciones. No toca otras bases. No crea códigos QR.**

## Carpeta donde ejecutar todos los comandos

En VS Code, PowerShell, abrir el proyecto real:

```powershell
Set-Location -LiteralPath 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Banqueteria_Proyecto'
.\.venv\Scripts\Activate.ps1
Remove-Item Env:\MAYA_DB_PASSWORD -ErrorAction SilentlyContinue
```

## 1. Preparar los archivos (con servidores Django y React detenidos)

Descargar `MICA_Carga_Masiva_20_Fichas_Insumos.zip`, copiarlo a `C:\Users\madel\OneDrive\Escritorio\Capstone` y descomprimir:

```powershell
Expand-Archive -LiteralPath 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Carga_Masiva_20_Fichas_Insumos.zip' -DestinationPath 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Carga_Extraida' -Force
$Origen = 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Carga_Extraida\CARGA_MASIVA_MICA_20\archivos'
$Proyecto = 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Banqueteria_Proyecto'
Test-Path "$Origen\scripts\importar_fichas_maya.py"
```

Debe aparecer `True`. **Antes de reemplazar archivos, hacer backup de PostgreSQL** con `pg_dump`:

```powershell
& 'C:\Program Files\PostgreSQL\18\bin\pg_dump.exe' -h 127.0.0.1 -p 5432 -U postgres -W -d sig_banqueteria_mica -Fc -f 'C:\Users\madel\OneDrive\Escritorio\Capstone\mica_antes_carga_20.backup'
```

Pide la contraseña de PostgreSQL. Confirmar que el archivo `.backup` exista y tenga tamaño mayor que 0.

Copiar scripts y JSON a sus destinos (sin reemplazar los demás módulos del proyecto):

```powershell
Copy-Item "$Origen\scripts\importar_fichas_maya.py" "$Proyecto\scripts\importar_fichas_maya.py"
Copy-Item "$Origen\scripts\registrar_entradas_stock.py" "$Proyecto\scripts\registrar_entradas_stock.py"
Copy-Item "$Origen\fichas_maya_20.json" "$Proyecto\fichas_maya_20.json"
Copy-Item "$Origen\plantilla_carga_stock.csv" "$Proyecto\plantilla_carga_stock.csv"
```

### 2. Ejecutar validación del archivo y previsualización (no escribe)

```powershell
Set-Location -LiteralPath $Proyecto
.\.venv\Scripts\Activate.ps1
Remove-Item Env:\MAYA_DB_PASSWORD -ErrorAction SilentlyContinue
python -m scripts.importar_fichas_maya --validar
python -m scripts.importar_fichas_maya
```

El segundo comando calcula un **plan sobre tu BD actual** sin escribir. **Enviar los resultados y revisarlos antes de importar.**

### 3. Aplicar importación (SOLO si el plan fue correcto y hay respaldo)

```powershell
python -m scripts.importar_fichas_maya --aplicar
python -m scripts.diagnosticar
```

Revisar en Django que las fichas aparezcan y probar cotizaciones. Las cantidades nuevas de stock parten en cero.

### 4. Cargar existencias verdaderas de bodega

Abrir `plantilla_carga_stock.csv` en Excel o Bloc de notas. Contiene 40 nombres de insumo con la bodega precargada. **En la columna `cantidad_entrada` escribir únicamente las cantidades realmente recibidas**; dejar las demás en blanco. Si un insumo ya tiene stock en la BD, esta cifra se **suma** como nueva entrada: NO es un ajuste al conteo final.

Unidad: kg, litros o unidades según el catálogo. Usar punto decimal (`2.5`) sin separador de miles. Guardar como CSV con **punto y coma** (`;`) de delimitador y codificación UTF-8.

Revisar plan:

```powershell
python -m scripts.registrar_entradas_stock
```

Si el plan es correcto, elegir un identificador de lote único, por ejemplo `compra-noviembre-001`, y ejecutar:

```powershell
python -m scripts.registrar_entradas_stock --aplicar --lote compra-noviembre-001
```

La importación de stock registra **movimientos de entrada** y aumenta el inventario dentro de una sola transacción. Volver a ejecutar el mismo lote está bloqueado para evitar sumas duplicadas. Usar otro identificador solo para **una compra distinta**, no para repetir una importación fallida o ya completada.

## ¿Qué falta para descuento automático al preparar?

Actualmente `mica/services.py` **ya calcula el consumo por insumo** desde `receta` y consulta inventario. La cotización *no reserva ni descuenta* material. Para completar la operación real:

1. Guardar en `detalle_pedido` las fichas elegidas y número de porciones, considerando varias preparaciones del menú.
2. Al confirmar el pedido, calcular faltantes y generar una **solicitud/reserva** de insumos, sin descontar aún stock físico.
3. Al registrar preparación/salida, sumar consumos por insumo para todas las fichas del pedido, bloquear stock con `select_for_update`, verificar que no quede negativo, descontar una sola vez y crear `movimiento_inventario` tipo `consumo` con `id_pedido` y auditoría.
4. Prever reversión, mermas, porciones modificadas, lotes y caducidad. El `RegistrarMovimientoInventarioView` actual solo permite `entrada` y `salida`; además, no distingue adecuadamente `consumo` desde una solicitud de cliente. Necesita ampliarse.

**No delegar a la IA la escritura de cantidades ni la modificación de stock.** GPT-OSS puede redactar recomendaciones, proponer sustituciones y explicar faltantes; Python/PostgreSQL deben validar la receta, costo, disponibilidad, fechas, permisos y transacciones.

## Advertencias

- Los precios del JSON no son costos comprobados; la carga es adecuada para demostración y pruebas.
- La validación alimentaria requiere datos adicionales de ingredientes, alérgenos y contaminación cruzada.
- El costo comercial debe incorporar IVA si corresponde, mano de obra, transporte, equipamiento y márgenes.
- El importador no modifica fichas existentes: revisarlas por separado si necesitan cambios.
- No ejecutar el archivo SQL de instalación inicial (`01_INSTALACION_SOLO_BD_NUEVA.sql`) sobre la base ya instalada.
- No poner `.env`, el respaldo `.backup`, datos personales ni claves de Groq en un repositorio público.
