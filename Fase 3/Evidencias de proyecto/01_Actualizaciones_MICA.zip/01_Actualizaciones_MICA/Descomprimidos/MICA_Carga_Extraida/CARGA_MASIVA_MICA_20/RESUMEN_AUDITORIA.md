# Informe de revisión del archivo fichas_maya_20.json

**Datos del archivo:** `version=1`, proyecto Banquetería Maya, moneda CLP, 30 porciones por ficha, costos de ejemplo sin operación ni impuestos.

## Comprobaciones realizadas

| Comprobación | Resultado |
|---|---|
| Sintaxis JSON | Válida |
| Insumos distintos | 40 |
| Fichas distintas por código y nombre | 20 |
| Líneas de receta | 120 |
| Pasos de preparación | 60 |
| Tipos de ficha | 8 fondos, 3 acompañamientos, 4 entradas, 5 postres |
| Unidades de receta respecto al catálogo | Coherentes |
| Costos por línea respecto a cantidad × precio | 120/120 correctos |
| Totales de ficha respecto a suma de ingredientes | 20/20 correctos |
| Totales por porción respecto a rendimiento | 20/20 correctos |
| Ingredientes faltantes del catálogo | 0 |
| Ingredientes repetidos dentro de una misma receta | 0 |

## Riesgos de importación y operación

1. El campo `codigo` de las fichas no existe en la tabla SQL `ficha_tecnica`. El importador lo conserva al principio de la descripción, no como identificador físico.
2. **Arroz** ya figura como insumo en el seed SQL actual; se reutiliza en lugar de duplicarlo. No debe confundirse `Pollo` (genérico del seed) con `Filete de pechuga de pollo` o `Presa de pollo con hueso`.
3. No hay existencias de stock inicial ni stock mínimo por producto en el JSON. No interpretar las cantidades de recetas como cantidades disponibles en bodega.
4. Margen y precio sugerido permanecen cero en el catálogo. MICA aplica su política de margen en la simulación y se deben configurar los costos operativos.
5. Alérgenos, proveedores, QR, caducidad y rendimientos bajo distintas técnicas de cocción no están documentados por insumo en el JSON.
6. Si los costos vigentes en PostgreSQL no coinciden con el JSON, el importador conserva los de PostgreSQL y calcula las nuevas fichas desde ese costo real configurado.
7. No se realizó una importación a la base privada Windows; requiere ejecución local del plan y confirmación previa del usuario.

## Componentes actuales de MICA relacionados

- `gestion.FichaTecnica`: plato/entrada/postre y rendimiento.
- `gestion.Receta`: cantidad de cada `Insumo` necesaria para el rendimiento.
- `gestion.Inventario`: stock de `Insumo` por `Bodega`.
- `gestion.MovimientoInventario`: entradas, salidas y consumo (la API actual solo permite entradas y salidas).
- `mica/services.py`: convierte unidades, suma costos, consulta faltantes por insumo, aplica margen y presupuesto. No reserva ni consume stock.
- `mica/ai.py`: usa GPT-OSS mediante Groq como asistente de explicación, no como autoridad sobre inventario o cálculo de precios.
