"""Instalador de MICA v2.4; solo código, no ejecuta SQL ni consume inventario.

Simulación: python aplicar_parche_consumo.py --proyecto C:\\ruta\\MICA_Banqueteria_Proyecto
Aplicación: python aplicar_parche_consumo.py --proyecto C:\\ruta\\MICA_Banqueteria_Proyecto --aplicar
"""
import argparse
from datetime import datetime
from pathlib import Path
import shutil

MARCA = 'MICA_CONSUMO_V2_4'


def reemplazar_una_vez(texto, antes, despues, archivo):
    n = texto.count(antes)
    if n != 1:
        raise RuntimeError(f'{archivo}: patrón esperado {n} veces, se requiere 1; sin aplicar cambios.')
    return texto.replace(antes, despues, 1)


def transformar(archivo, contenido):
    if MARCA in contenido:
        raise RuntimeError(f'{archivo}: v2.4 ya instalado, no repetir.')
    if archivo == 'mica/views.py':
        if 'MICA_RESERVAS_V2_3' not in contenido:
            raise RuntimeError('Primero instalar v2.3. No se encontró la marca de reservas en mica/views.py.')
        contenido += '''\n\n# MICA_CONSUMO_V2_4: iniciar preparación con consumo atómico del pedido público.\nfrom .consumo import iniciar_preparacion, ConsumoError\n\n\nclass MicaIniciarPreparacionView(APIView):\n    permission_classes = [IsAdminUser]\n\n    def post(self, request, pk):\n        try:\n            resultado = iniciar_preparacion(pk, request.user)\n        except ConsumoError as exc:\n            return Response({'detail': str(exc)}, status=409)\n        return Response(resultado, status=200)\n'''
        return contenido
    if archivo == 'mica/urls.py':
        if 'MicaCancelarConfirmadoView' not in contenido:
            raise RuntimeError('No existe el endpoint de cancelación de MICA v2.3.')
        contenido = reemplazar_una_vez(
            contenido, '\nurlpatterns = [\n',
            '\n# MICA_CONSUMO_V2_4\nfrom .views import MicaIniciarPreparacionView\n\nurlpatterns = [\n', archivo)
        return reemplazar_una_vez(
            contenido,
            "    path('cotizaciones/<int:pk>/cancelar/', MicaCancelarConfirmadoView.as_view(), name='mica-publico-cancelar'),\n",
            "    path('cotizaciones/<int:pk>/cancelar/', MicaCancelarConfirmadoView.as_view(), name='mica-publico-cancelar'),\n"
            "    path('cotizaciones/<int:pk>/iniciar-preparacion/', MicaIniciarPreparacionView.as_view(), name='mica-iniciar-preparacion'),\n",
            archivo)
    if archivo == 'frontend/src/MicaVista.jsx':
        if 'MICA_RESERVAS_V2_3' not in contenido:
            raise RuntimeError('No aparece interfaz de reservas v2.3 en MicaVista.jsx.')
        handler = '''  // MICA_CONSUMO_V2_4: solo se puede preparar un pedido público confirmado.\n  const iniciarPreparacion = async c => {\n    if (!window.confirm(`¿Iniciar preparación de ${c.numero_pedido}? Esta acción DESCUENTA los ingredientes reservados y no puede repetirse.`)) return;\n    setCargando(true); setError(''); setMensaje('');\n    try {\n      const r = await petición(`/api/mica/cotizaciones/${c.id}/iniciar-preparacion/`, 'POST', {});\n      setMensaje(`Pedido ${r.numero_pedido}: EN PREPARACION. Consumos registrados: ${r.movimientos_creados}. Stock físico actualizado.`);\n      await recargar();\n      window.scrollTo({top:0, behavior:'smooth'});\n    } catch(e) {\n      setError(e.message);\n      window.scrollTo({top:0, behavior:'smooth'});\n    } finally { setCargando(false); }\n  };\n'''
        contenido = reemplazar_una_vez(
            contenido, '  const verGuardada = c => {\n', handler + '  const verGuardada = c => {\n', archivo)
        contenido = reemplazar_una_vez(
            contenido,
            '<td><button type="button" className="w04-secondary" disabled={cargando} onClick={()=>cancelarConfirmado(c)}>Cancelar y liberar reservas</button></td>',
            '<td><div className="w04-actions"><button type="button" className="w03-primary" disabled={cargando} onClick={()=>iniciarPreparacion(c)}>Iniciar preparación y consumir</button><button type="button" className="w04-secondary" disabled={cargando} onClick={()=>cancelarConfirmado(c)}>Cancelar y liberar reservas</button></div></td>',
            archivo)
        seccion = '''    <section className="w02-card mica-card"><h2>Pedidos en preparación · consumo registrado</h2>\n      <p className="w02-note">Estos pedidos ya descontaron sus reservas del inventario físico. No inicie la preparación por segunda vez.</p>\n      <div className="w02-table-scroll"><table className="w05-table mica-table"><thead><tr><th>Pedido</th><th>Estado</th><th>Reservas pendientes</th></tr></thead><tbody>\n        {historial.filter(c=>c.origen==='publico' && c.estado==='aprobada' && c.pedido_estado==='EN_PREPARACION').map(c=><tr key={c.id}><td>{c.numero_pedido}</td><td>{c.pedido_estado}</td><td>{c.reservas_activas}</td></tr>)}\n        {!historial.some(c=>c.origen==='publico' && c.estado==='aprobada' && c.pedido_estado==='EN_PREPARACION') && <tr><td colSpan="3">Aún no hay pedidos públicos en preparación.</td></tr>}\n      </tbody></table></div>\n    </section>\n'''
        return reemplazar_una_vez(
            contenido,
            '    <section className="w02-card mica-card"><h2>Cotizaciones guardadas</h2>',
            seccion + '    <section className="w02-card mica-card"><h2>Cotizaciones guardadas</h2>',
            archivo)
    raise RuntimeError('Archivo no admitido: ' + archivo)


def main():
    parser = argparse.ArgumentParser(description='MICA v2.4, parche de consumo y flujo de preparación')
    parser.add_argument('--proyecto', required=True)
    parser.add_argument('--aplicar', action='store_true')
    args = parser.parse_args()
    proyecto = Path(args.proyecto).resolve()
    fuente = Path(__file__).resolve().parent
    originales = ['mica/views.py', 'mica/urls.py', 'frontend/src/MicaVista.jsx']
    nuevos = ['mica/consumo.py', 'mica/tests/test_consumo.py']
    if not (proyecto / 'manage.py').is_file():
        raise RuntimeError('La ruta del proyecto no contiene manage.py.')
    preparados = {}
    for nombre in originales:
        destino = proyecto / nombre
        if not destino.is_file():
            raise RuntimeError(f'Falta {nombre}. No se ha modificado nada.')
        base = destino.read_text(encoding='utf-8')
        preparado = transformar(nombre, base)
        if nombre.endswith('.py'):
            compile(preparado, nombre, 'exec')
        preparados[nombre] = preparado
    for nombre in nuevos:
        destino = proyecto / nombre
        if destino.exists():
            raise RuntimeError(f'{nombre} ya existe; no se sobrescribe.')
        origen = fuente / nombre
        if not origen.is_file():
            raise RuntimeError(f'Falta archivo de distribución: {nombre}.')
        texto = origen.read_text(encoding='utf-8')
        compile(texto, nombre, 'exec')
        preparados[nombre] = texto
    print('=== MICA_CONSUMO_V2_4 ===')
    print('Proyecto:', proyecto)
    print('Archivos que se modificarán:', ', '.join(originales))
    print('Archivos nuevos:', ', '.join(nuevos))
    print('No se ejecutan migraciones ni cambios de base de datos.')
    if not args.aplicar:
        print('PLAN CORRECTO. NO SE CAMBIO NINGUN ARCHIVO.')
        print('Para instalar, repetir con --aplicar DESPUES de revisar los respaldos y la BD.')
        return
    respaldo = proyecto.parent / ('respaldo_codigo_mica_consumo_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
    for nombre in originales:
        destino = respaldo / nombre
        destino.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(proyecto / nombre, destino)
    for nombre, contenido in preparados.items():
        destino = proyecto / nombre
        destino.parent.mkdir(parents=True, exist_ok=True)
        temporal = destino.with_name(destino.name + '.tmp_v24')
        temporal.write_text(contenido, encoding='utf-8', newline='')
        temporal.replace(destino)
    print('INSTALACION COMPLETADA. Respaldos en:', respaldo)
    print('No se han modificado registros de PostgreSQL. Ejecute las pruebas antes de usar el botón.')


if __name__ == '__main__':
    main()
