# MICA v2.4 — Iniciar preparación y registrar consumo de inventario

## Alcance

Continúa MICA v2.3. Añade **solo para pedidos públicos MICA aprobados** el paso `CONFIRMADO → EN_PREPARACION` mediante un nuevo botón en el cotizador administrativo. Utiliza la tabla existente `movimiento_inventario` con el tipo `consumo`, disponible en el SQL original del proyecto. **No crea ni modifica tablas**, no aplica migraciones y no modifica `.env` ni claves Groq.

La transición realiza en **una transacción**: bloqueo de cotización y pedido; verificación de reservas y existencias físicas por insumo/bodega; comprobación de que otros pedidos con reservas mantengan cobertura; descuento del `inventario.stock_actual`; creación de un `movimiento_inventario` por reserva; actualización de las reservas a `consumida`; cambio a `EN_PREPARACION`; alta en `historial_pedido` con usuario, fecha y observación.

Si hay conflicto o stock insuficiente, no se debe confirmar ningún cambio. Un segundo intento sobre un pedido ya en preparación devuelve conflicto en lugar de consumir otra vez. El backend requiere usuario de administración (`IsAdminUser`), autentica con la sesión existente y aplica CSRF de la aplicación web.

**Limitaciones importantes:** aún no incorpora producción de pedidos internos MICA, despacho, finalización, devolución de ingredientes consumidos, escaneo QR ni auditoría integral de seguridad. El script se probó sintácticamente y con simulación contra el código de referencia v2.1 + parche v2.3. Las pruebas reales en tu PostgreSQL Windows siguen pendientes. Las cinco pruebas nuevas verifican reglas matemáticas, NO sustituyen integración end-to-end ni concurrencia.

## A. Comprobar antes de instalar (en VS Code, PowerShell)

Desde `MICA_Banqueteria_Proyecto` y con `.venv` activado, extraer este ZIP en la carpeta `Capstone`, **junto a** `MICA_Banqueteria_Proyecto`.

```powershell
$Parche = 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Consumo_v2_4\archivos\aplicar_parche_consumo.py'
python $Parche --proyecto (Get-Location).Path
```

Se espera **`PLAN CORRECTO. NO SE CAMBIO NINGUN ARCHIVO`**. Si un archivo difiere del código esperado, el instalador se detiene. Envíame ese resultado primero, antes de aplicar el parche.

## B. Respaldo y aplicación (solo después de validar el plan)

1. Realizar respaldo de base `sig_banqueteria_mica` con `pg_dump` (sin tocar `sig_banqueteria` ni `sig_banqueteria_seba`), y comprobar que el `.backup` sea mayor que 0 bytes.
2. Cerrar o evitar solicitudes de cambios de estado mientras se instala.
3. Ejecutar el mismo instalador con `--aplicar`. Creará respaldo de cada archivo de código modificado en la carpeta hermana `respaldo_codigo_mica_consumo_<fecha>`.
4. Ejecutar `python manage.py check` y `python manage.py test mica.tests.test_motor mica.tests.test_publico mica.tests.test_reservas mica.tests.test_consumo`.
5. Verificar manualmente que está disponible el botón **Iniciar preparación y consumir** para un pedido ficticio de prueba ya confirmado. Antes de pulsarlo confirmar stock y reservas vigentes.

## C. Resultado funcional esperado para PED-010004 (si NO cambió el stock)

| Ingrediente | Antes | Reservado | Después |
| --- | ---: | ---: | ---: |
| Arroz | 535.000 | 7.500 | 527.500 |
| Pollo | 58.000 | 25.000 | 33.000 |

El pedido debe quedar `EN_PREPARACION`, las **2 reservas** en `consumida`, los **2 movimientos** con `tipo_movimiento='consumo'` e `id_pedido` correspondiente. No debe permitir repetir la transición. Es una operación real de escritura; usar únicamente datos de prueba y respaldar primero.

## D. Seguridad

- No ejecutar `01_INSTALACION_SOLO_BD_NUEVA.sql` ni crear tablas manualmente.
- No colocar claves API, contraseñas ni cookies en capturas.
- El nuevo endpoint está en `/api/mica/cotizaciones/<id>/iniciar-preparacion/` y exige administración. La pantalla no es una barrera de seguridad; Django comprueba la transición.
- Los pedidos públicos están temporalmente bloqueados para cambio de estado directo desde el editor general Pedidos (protección instalada en `gestion/views.py` durante la revisión anterior). Mantenerla hasta centralizar todos los estados.
- Solo se prueban las operaciones de consumo para cotizaciones públicas aprobadas; los pedidos internos y otros flujos requieren su propio diseño.
