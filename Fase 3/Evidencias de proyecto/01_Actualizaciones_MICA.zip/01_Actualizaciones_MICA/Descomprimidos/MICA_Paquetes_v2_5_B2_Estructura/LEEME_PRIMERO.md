# MICA v2.5B2 — Fase 1: esquema de paquetes (SIN activación funcional)

Este parche agrega un **catálogo de paquetes** y permite que `PropuestaMica` apunte a una ficha **o** a un paquete (excluyentes). Todas las propuestas actuales mantienen su ficha y no se alteran. Cada paquete contiene varias fichas y una cantidad de **porciones terminadas por asistente**, decimal y mayor que cero.

**No habilita aún** cotización, solicitud, reserva ni consumo de paquetes. Esa fase posterior requiere cambios coordinados de `services.py`, `publico.py`, `reservas.py`, la creación de `DetallePedido` múltiple y pruebas de integración contra PostgreSQL. Hasta entonces el flujo público continúa cotizando fichas individuales.

## Árbol de archivos

- `archivos/aplicar_parche_paquetes.py` (simulador/instalador)
- `archivos/mica/migrations/0004_paquetes_mica.py` (migración declarativa; no se ejecuta automáticamente)
- `archivos/mica/tests/test_paquetes_estructura_v25b2.py` (3 pruebas del esquema)

## Instalación con precaución

1. Guardar ZIP en `Capstone/01_Actualizaciones_MICA/ZIP_Originales` y descomprimir en `Descomprimidos`.
2. Desde la carpeta raíz `MICA_Banqueteria_Proyecto` y con `.venv` activo, realizar **primero la simulación** `python <ruta_instalador> --proyecto <ruta_proyecto>`.
3. Verificar respaldo reciente de `sig_banqueteria_mica` antes de ejecutar la migración. Mantener `PED-010004` y sus consumos intactos.
4. Ejecutar `--aplicar` únicamente cuando la simulación coincida. El instalador respalda `mica/models.py` en `Capstone/02_Respaldos/Codigo`.
5. Verificar `python manage.py check`, `python manage.py makemigrations --check --dry-run` y `python manage.py migrate mica --plan` **antes** de ejecutar la migración; revisar salida con el asistente.
6. Tras aprobar el plan, ejecutar migración y pruebas, incluyendo `mica.tests.test_paquetes_estructura_v25b2`.

## Modelo de datos

- `PaqueteMica`: nombre, tipo de servicio, descripción, activo, auditoría temporal.
- `ComponentePaqueteMica`: paquete, ficha, cantidad por invitado, orden; no permite cantidades nulas o negativas ni duplicar la misma ficha dentro de un paquete.
- `PropuestaMica`: `ficha` opcional y `paquete` opcional con CHECK exactamente uno informado. La oferta histórica mantiene su referencia `ficha`.

## Limitaciones importantes

- No se añaden recetas de café, mini sándwiches, postres de cóctel ni bebestibles.
- No se configura precio por comuna, demanda estacional ni traslado.
- No se exponen nuevas acciones ni endpoints para crear paquetes desde el navegador.
- El instalador se detiene si ya existe una migración 0004 o si no reconoce la forma del modelo original.
- El propio archivo de migración crea tablas y restricciones en PostgreSQL **solo cuando se ejecuta `migrate`**.
