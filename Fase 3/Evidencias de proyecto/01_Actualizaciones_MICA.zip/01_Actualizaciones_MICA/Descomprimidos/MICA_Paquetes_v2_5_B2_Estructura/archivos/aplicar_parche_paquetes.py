# -*- coding: utf-8 -*-
"""Instalador seguro: primero simulación; --aplicar solo modifica archivos locales.
No ejecuta migraciones, SQL, manage.py ni llamadas de red.
"""
import argparse
import shutil
import sys
from datetime import datetime
from pathlib import Path

MARCA = '# MICA_PAQUETES_V2_5_B2_ESQUEMA'


def reemplazar_una_vez(texto, antiguo, nuevo, nombre):
    cantidad = texto.count(antiguo)
    if cantidad != 1:
        raise ValueError(f'{nombre}: patrón esperado encontrado {cantidad} veces (debe ser 1). Sin cambios.')
    return texto.replace(antiguo, nuevo, 1)


def transformar(texto):
    if MARCA in texto:
        raise ValueError('La estructura v2.5B2 ya parece instalada. No volver a ejecutar.')
    ancla_ficha = "    ficha = models.ForeignKey('gestion.FichaTecnica', on_delete=models.PROTECT)\n"
    nuevo_ficha = (
        "    ficha = models.ForeignKey('gestion.FichaTecnica', on_delete=models.PROTECT, null=True, blank=True)\n"
        "    paquete = models.ForeignKey('PaqueteMica', on_delete=models.PROTECT,\n"
        "                                null=True, blank=True, related_name='propuestas_mica')\n"
    )
    texto = reemplazar_una_vez(texto, ancla_ficha, nuevo_ficha, 'PropuestaMica.ficha')
    # PropuestaMica es la última clase del módulo original, seguida por ReservaInsumoMica v2.3.
    # Su Meta se identifica con una ancla exacta, sin tocar Meta de otras clases.
    meta_propuesta = "    class Meta:\n        ordering = ['precio_total', 'id']\n"
    meta_nueva = (
        "    class Meta:\n"
        "        ordering = ['precio_total', 'id']\n"
        "        constraints = [\n"
        "            models.CheckConstraint(\n"
        "                condition=(models.Q(ficha__isnull=False, paquete__isnull=True)\n"
        "                           | models.Q(ficha__isnull=True, paquete__isnull=False)),\n"
        "                name='mica_propuesta_ficha_xor_paquete',\n"
        "            ),\n"
        "        ]\n"
    )
    texto = reemplazar_una_vez(texto, meta_propuesta, meta_nueva, 'Meta PropuestaMica')
    texto += '''

# MICA_PAQUETES_V2_5_B2_ESQUEMA
# Catálogo de paquetes; aún NO crea propuestas combinadas ni modifica reservas.
class PaqueteMica(models.Model):
    TIPOS = [
        ('coffee_break', 'Coffee break'),
        ('coctel', 'Cóctel'),
        ('almuerzo', 'Almuerzo'),
        ('cena', 'Cena'),
        ('banquete', 'Banquete'),
        ('personalizado', 'Personalizado'),
    ]
    nombre = models.CharField(max_length=150)
    tipo_servicio = models.CharField(max_length=24, choices=TIPOS)
    descripcion = models.TextField(default='', blank=True)
    activo = models.BooleanField(default=True)
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['nombre', 'pk']
        constraints = [
            models.UniqueConstraint(fields=['tipo_servicio', 'nombre'], name='mica_paquete_tipo_nombre_unico'),
        ]


class ComponentePaqueteMica(models.Model):
    paquete = models.ForeignKey(PaqueteMica, on_delete=models.CASCADE, related_name='componentes')
    ficha = models.ForeignKey('gestion.FichaTecnica', on_delete=models.PROTECT, related_name='componentes_mica')
    # Número de unidades terminadas de la ficha por invitado (no kg de insumo).
    cantidad_por_persona = models.DecimalField(max_digits=9, decimal_places=3)
    orden = models.PositiveSmallIntegerField(default=1)

    class Meta:
        ordering = ['orden', 'pk']
        constraints = [
            models.UniqueConstraint(fields=['paquete', 'ficha'], name='mica_componente_paquete_ficha_unica'),
            models.CheckConstraint(condition=models.Q(cantidad_por_persona__gt=0), name='mica_componente_cantidad_positiva'),
        ]
'''
    compile(texto, 'mica/models.py', 'exec')
    return texto


def main():
    parser = argparse.ArgumentParser(description='MICA v2.5B2: solo catálogo y modelos, sin cotizaciones combinadas')
    parser.add_argument('--proyecto', required=True)
    parser.add_argument('--aplicar', action='store_true')
    args = parser.parse_args()
    proyecto = Path(args.proyecto).resolve()
    archivos = Path(__file__).resolve().parent
    modelos = proyecto / 'mica/models.py'
    fuente_nuevos = {
        'mica/migrations/0004_paquetes_mica.py': archivos / 'mica/migrations/0004_paquetes_mica.py',
        'mica/tests/test_paquetes_estructura_v25b2.py': archivos / 'mica/tests/test_paquetes_estructura_v25b2.py',
    }
    print('=== MICA PAQUETES v2.5B2 — SOLO ESTRUCTURA ===')
    print('Proyecto:', proyecto)
    try:
        if not (proyecto / 'manage.py').is_file() or not modelos.is_file():
            raise ValueError('Faltan manage.py o mica/models.py en el proyecto indicado.')
        if not (proyecto / 'mica/migrations/0003_reservainsumomica.py').is_file():
            raise ValueError('Falta la migración v2.3. No se puede instalar v2.5B2.')
        existentes = sorted(p.name for p in (proyecto / 'mica/migrations').glob('0004_*.py'))
        if existentes:
            raise ValueError('Ya existe migración 0004: ' + ', '.join(existentes))
        for relativo, fuente in fuente_nuevos.items():
            if (proyecto / relativo).exists():
                raise ValueError(f'Ya existe {relativo}. No sobreescribir.')
            if not fuente.is_file():
                raise ValueError(f'Falta archivo del parche: {relativo}')
            compile(fuente.read_text(encoding='utf-8'), relativo, 'exec')
        contenido = transformar(modelos.read_text(encoding='utf-8-sig'))
    except (ValueError, OSError) as exc:
        print('INSTALACION DETENIDA. No se realizaron cambios:', exc)
        sys.exit(2)
    print('Actualiza: mica/models.py')
    print('Crea: ' + ', '.join(fuente_nuevos))
    print('NO cambia PostgreSQL; la migración debe revisarse y ejecutarse por separado.')
    print('NO incorpora todavía UI, motor de cotización por paquete ni reservas combinadas.')
    if not args.aplicar:
        print('PLAN CORRECTO. NO SE CAMBIO NINGUN ARCHIVO.')
        return
    respaldo = proyecto.parent / '02_Respaldos/Codigo' / ('mica_paquetes_esquema_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
    respaldo.mkdir(parents=True, exist_ok=False)
    shutil.copy2(modelos, respaldo / 'models.py')
    escritos = []
    try:
        temporal = modelos.with_name('models.py.tmp_paquetes')
        temporal.write_text(contenido, encoding='utf-8')
        temporal.replace(modelos)
        for relativo, fuente in fuente_nuevos.items():
            destino = proyecto / relativo
            destino.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(fuente, destino)
            escritos.append(destino)
    except Exception as exc:
        shutil.copy2(respaldo / 'models.py', modelos)
        for destino in escritos:
            destino.unlink(missing_ok=True)
        print('ERROR AL COPIAR. Restaurado models.py:', exc)
        sys.exit(3)
    print('ARCHIVOS INSTALADOS. Código respaldado en:', respaldo)
    print('SIGUIENTE: python manage.py check; python manage.py makemigrations --check --dry-run; python manage.py migrate mica --plan')
    print('NO EJECUTAR AUN: python manage.py migrate mica')


if __name__ == '__main__':
    main()
