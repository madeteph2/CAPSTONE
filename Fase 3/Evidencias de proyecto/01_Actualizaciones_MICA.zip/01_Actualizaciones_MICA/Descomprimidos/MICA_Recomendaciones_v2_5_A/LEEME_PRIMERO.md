# MICA v2.5A — Recomendaciones dentro del presupuesto y contexto Groq

**Alcance acotado:** mejora del motor actual sin tocar tablas, reservas ni flujos de aprobación/consumo. No instala chat ni paquetes completos: estos son desarrollos posteriores.

## Mejoras

- Corrige el defecto real `ficha_ids=[]`: antes evitaba el límite de tres y mostraba todas las fichas.
- Muestra **hasta tres alternativas**, priorizando las que cumplen presupuesto y tienen stock estimado. Si solo faltan insumos, las alternativas se indican como pendientes de reposición; si ninguna cabe en el presupuesto, muestra opciones superiores solo como comparativas no seleccionables.
- Conserva el comportamiento de selección explícita de una ficha técnica.
- IA Groq/OpenAI recibe **tipo de evento y número de asistentes**, además de nombres, precios y descripciones públicas. No recibe datos personales ni costos internos.
- Las tarjetas del consumidor muestran la descripción de la ficha y un comentario de disponibilidad/presupuesto calculado por Django.
- Incorpora seis pruebas específicas de selección y privacidad de la respuesta pública.

## Límites y controles

- Sigue siendo **una ficha técnica por alternativa**, no menú combinado.
- La existencia es estimada, no una reserva; la aprobación de un pedido sigue controlada en backend.
- La descripción de cada ficha proviene del catálogo: **no** se inventan popularidad, tiempos ni cualidades culinarias.
- Los valores de `.env` y claves de Groq no se modifican.
- La API de envío recalcula precio y propuesta en el servidor: conserva ese control.
- Los 20 tests existentes de v2.4 deben seguir pasando. No interpretar los nuevos tests unitarios como prueba de integración con Groq o de concurrencia PostgreSQL.

## Instalación

Desde PowerShell en `C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Banqueteria_Proyecto` con `.venv` activo, guarda este paquete descomprimido en `Capstone\01_Actualizaciones_MICA\Descomprimidos`.

Simulación (NO modifica archivos):

```powershell
$Proyecto = 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Banqueteria_Proyecto'
$Parche = 'C:\Users\madel\OneDrive\Escritorio\Capstone\01_Actualizaciones_MICA\Descomprimidos\MICA_Recomendaciones_v2_5_A\archivos\aplicar_parche_recomendaciones.py'
python $Parche --proyecto $Proyecto
```

**Detente y revisa que indique `PLAN CORRECTO. NO SE CAMBIO NINGUN ARCHIVO.`**

Después de confirmar respaldo de código/base y el plan, instalar con `--aplicar`, luego ejecutar:

```powershell
python manage.py check
python manage.py test mica.tests.test_motor mica.tests.test_publico mica.tests.test_reservas mica.tests.test_consumo mica.tests.test_seleccion_v25
```

Deben encontrarse **26 tests** si se conserva la suite de 20 anterior. Luego validar en navegador `/cotizar` con `ficha_ids=[]` y presupuestos altos/bajos, sin guardar pedidos nuevos durante la primera prueba.
