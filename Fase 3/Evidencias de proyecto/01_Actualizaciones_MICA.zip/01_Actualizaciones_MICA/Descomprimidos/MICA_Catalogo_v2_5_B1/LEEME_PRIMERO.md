# MICA v2.5B1 — Catálogo por categorías

**Prerequisitos:** MICA v2.5A instalada, Django `check` y 26 pruebas previas aprobadas (incluida la corrección del dato `nombre` en test_seleccion_v25.py). Compatible con el flujo probado v2.4.

## Qué cambia

- Permite filtrar por grupo **Salados / Dulces / Bebidas frías / Bebidas calientes** y subtipo.
- Evita mezclar platos de fondo con entradas o postres en una misma comparación, desde la interfaz y el backend.
- Reutiliza `FichaTecnica.tipo_preparacion`, sin agregar columnas ni migraciones.
- El administrador registra la categoría con una lista controlada; el backend rechaza códigos desconocidos en escrituras.
- No contiene recetas nuevas: **bebidas, canapés, repostería** aparecerán cuando se incorporen fichas reales.
- Conserva solicitudes antiguas: si una API previa no envía grupo/tipo, aún puede funcionar sin filtros.
- Ajusta el mensaje pedido a Groq para solicitar texto plano breve (el formato de IA deberá validarse en el navegador).
- Añade 8 pruebas automatizadas de validación de categorías.

**No incluye todavía paquetes combinados.** Se necesitan modelos de paquetes/detalles y ampliar reserva y consumo a múltiples fichas para evitar inconsistencias. No se modifican reservas ni inventario.

## Instalar de forma segura

1. Guardar ZIP en `01_Actualizaciones_MICA/ZIP_Originales` y extraer en `01_Actualizaciones_MICA/Descomprimidos`.
2. Ejecutar desde la raíz del proyecto con `.venv`:

```powershell
python $Parche --proyecto $Proyecto
```

3. Validar que diga `PLAN CORRECTO. NO SE CAMBIO NINGUN ARCHIVO.`. Solo después del visto bueno:

```powershell
python $Parche --proyecto $Proyecto --aplicar
python manage.py check
python manage.py test mica.tests.test_motor mica.tests.test_publico mica.tests.test_reservas mica.tests.test_consumo mica.tests.test_seleccion_v25 mica.tests.test_catalogo_v25b1
```

**Revisión funcional:** seleccionar Salados > Plato principal, Dulces > Postre, y Bebidas frías; la última categoría debe mostrar que aún no hay fichas si no se han cargado.

**Respaldo:** el instalador guarda copias de los archivos editados en `Capstone/02_Respaldos/Codigo/mica_v25b1_<fecha>/`.

**Advertencia:** no pulsar `--aplicar` si el modo simulación indica incompatibilidad. No eliminar ni editar migraciones existentes. Los archivos de este paquete no incluyen claves ni credenciales.
