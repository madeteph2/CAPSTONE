# -*- coding: utf-8 -*-
"""Parche incremental MICA v2.5B1: por defecto, SIMULACION sin cambios."""
from __future__ import annotations
import argparse
from datetime import datetime
from pathlib import Path
import shutil

MARCA = 'MICA_CATALOGO_V2_5_B1'


def unico(texto, antes, despues, ruta):
    veces = texto.count(antes)
    if veces != 1:
        raise RuntimeError(f'{ruta}: se esperaba 1 coincidencia, hay {veces}. Sin cambios.')
    return texto.replace(antes, despues, 1)


def transformar(ruta, texto):
    if MARCA in texto:
        raise RuntimeError(f'{ruta}: parche B1 ya aplicado, no repetir.')
    if ruta == 'mica/services.py':
        if 'MICA_RECOMENDACIONES_V2_5_A' not in texto:
            raise RuntimeError('Instale primero v2.5A.')
        texto = unico(texto,
            'from .models import ReservaInsumoMica  # MICA_RESERVAS_V2_3\n',
            'from .models import ReservaInsumoMica  # MICA_RESERVAS_V2_3\nfrom .catalogo import TIPOS_POR_GRUPO  # ' + MARCA + '\n', ruta)
        texto = unico(texto,
            "        'preparacion': ficha.nombre_ficha,\n",
            "        'preparacion': ficha.nombre_ficha,\n        'tipo_preparacion': ficha.tipo_preparacion or '',\n", ruta)
        texto = unico(texto,
            'def generar_propuestas(*, personas, presupuesto, margen, costos, ids=None):\n',
            'def generar_propuestas(*, personas, presupuesto, margen, costos, ids=None, grupo="", tipo_preparacion=""):\n', ruta)
        texto = unico(texto,
            "    fichas = FichaTecnica.objects.select_related('id_unidad_rendimiento').filter(estado__iexact='activo')\n    if ids:\n",
            "    fichas = FichaTecnica.objects.select_related('id_unidad_rendimiento').filter(estado__iexact='activo')\n"
            "    # MICA_CATALOGO_V2_5_B1: filtro autoritativo también para POST solicitar.\n"
            "    if grupo:\n        fichas = fichas.filter(tipo_preparacion__in=TIPOS_POR_GRUPO.get(grupo, ()))\n"
            "    if tipo_preparacion:\n        fichas = fichas.filter(tipo_preparacion=tipo_preparacion)\n"
            "    if ids:\n", ruta)
        return texto
    if ruta == 'mica/publico.py':
        texto = unico(texto,
            'from .services import decimal_positivo, dinero, generar_propuestas, margen_minimo\n',
            'from .services import decimal_positivo, dinero, generar_propuestas, margen_minimo\n'
            'from .catalogo import TIPOS_POR_GRUPO, TODOS_TIPOS, grupo_de, filtros_compatibles  # ' + MARCA + '\n', ruta)
        texto = unico(texto,
            '    ficha_ids = serializers.ListField(child=serializers.IntegerField(min_value=1), required=False)\n',
            "    ficha_ids = serializers.ListField(child=serializers.IntegerField(min_value=1), required=False)\n"
            "    grupo = serializers.ChoiceField(choices=list(TIPOS_POR_GRUPO), required=False, allow_blank=True, default='')\n"
            "    tipo_preparacion = serializers.ChoiceField(choices=list(TODOS_TIPOS), required=False, allow_blank=True, default='')\n", ruta)
        texto = unico(texto,
            "        if attrs.get('restricciones'):\n            raise serializers.ValidationError({'restricciones': 'Se requiere evaluación humana de alergias o restricciones alimentarias antes de cotizar. Contacte al personal.'})\n        return attrs\n",
            "        if attrs.get('restricciones'):\n            raise serializers.ValidationError({'restricciones': 'Se requiere evaluación humana de alergias o restricciones alimentarias antes de cotizar. Contacte al personal.'})\n"
            "        if not filtros_compatibles(attrs.get('grupo', ''), attrs.get('tipo_preparacion', '')):\n"
            "            raise serializers.ValidationError({'tipo_preparacion': 'El tipo de preparación no corresponde al grupo seleccionado.'})\n"
            "        return attrs\n", ruta)
        texto = unico(texto,
            "        costos=costos, ids=datos.get('ficha_ids'),\n",
            "        costos=costos, ids=datos.get('ficha_ids'),\n"
            "        grupo=datos.get('grupo', ''), tipo_preparacion=datos.get('tipo_preparacion', ''),\n", ruta)
        texto = unico(texto,
            "        'dentro_presupuesto': p['dentro_presupuesto'],\n        'requiere_compra': p['requiere_compra'],\n    }\n",
            "        'dentro_presupuesto': p['dentro_presupuesto'],\n        'requiere_compra': p['requiere_compra'],\n"
            "        'tipo_preparacion': p.get('tipo_preparacion', ''),\n    }\n", ruta)
        texto = unico(texto,
            "            'preparaciones': [{'id': x.pk, 'nombre': x.nombre_ficha, 'descripcion': (x.descripcion or '')[:250]} for x in fichas],\n",
            "            'preparaciones': [{'id': x.pk, 'nombre': x.nombre_ficha,\n"
            "                               'descripcion': (x.descripcion or '')[:250],\n"
            "                               'tipo_preparacion': x.tipo_preparacion or '',\n"
            "                               'grupo': grupo_de(x.tipo_preparacion)} for x in fichas],\n", ruta)
        texto = unico(texto,
            "                        'tipo_evento': datos['tipo_evento'], 'comentario': datos.get('comentario', ''),\n",
            "                        'tipo_evento': datos['tipo_evento'],\n"
            "                        'grupo': datos.get('grupo', ''),\n"
            "                        'tipo_preparacion': datos.get('tipo_preparacion', ''),\n"
            "                        'comentario': datos.get('comentario', ''),\n", ruta)
        return texto
    if ruta == 'gestion/serializers.py':
        texto = unico(texto,
            'class FichaTecnicaSerializer(serializers.ModelSerializer):\n',
            '''# MICA_CATALOGO_V2_5_B1: el backend valida códigos comerciales al guardar fichas.
from mica.catalogo import ETIQUETAS_TIPO


class FichaTecnicaSerializer(serializers.ModelSerializer):
    def validate_tipo_preparacion(self, valor):
        if valor not in (None, '') and valor not in ETIQUETAS_TIPO:
            raise serializers.ValidationError('Seleccione una categoría válida del catálogo.')
        return valor

    def validate(self, attrs):
        attrs = super().validate(attrs)
        if self.instance is None and not attrs.get('tipo_preparacion'):
            raise serializers.ValidationError({'tipo_preparacion': 'Seleccione un tipo de preparación.'})
        return attrs

''', ruta)
        return texto
    if ruta == 'frontend/src/App.jsx':
        texto = unico(texto,
            '          {campo("tipo_preparacion", "Tipo de preparación")}\n',
            '''          {/* MICA_CATALOGO_V2_5_B1: evitar tipos escritos libremente */}
          <label className="w04-field"><span>Tipo de preparación *</span>
            <select name="tipo_preparacion" value={form.tipo_preparacion || ""} onChange={cambiar} required
              aria-invalid={Boolean(errores.tipo_preparacion)}>
              <option value="">Seleccione una categoría</option>
              <optgroup label="Salados">
                <option value="plato_fondo">Plato principal</option>
                <option value="entrada">Entrada</option>
                <option value="acompanamiento">Acompañamiento</option>
                <option value="canape">Canapés</option>
                <option value="bocado_salado">Bocados salados</option>
              </optgroup>
              <optgroup label="Dulces">
                <option value="postre">Postre</option>
                <option value="bocado_dulce">Bocados dulces</option>
                <option value="reposteria">Repostería</option>
              </optgroup>
              <optgroup label="Bebidas">
                <option value="bebida_fria">Bebida fría</option>
                <option value="bebida_caliente">Bebida caliente</option>
              </optgroup>
            </select>
            {errores.tipo_preparacion && <small className="w04-error">{errores.tipo_preparacion}</small>}
          </label>
''', ruta)
        return texto
    if ruta == 'frontend/src/MicaCliente.jsx':
        texto = unico(texto,
            "const inicial = { personas:'50', presupuesto:'500000', fecha:hoy(), ubicacion:'', tipo_evento:'Cumpleaños', ficha_ids:[], restricciones:[] };\n",
            '''// MICA_CATALOGO_V2_5_B1: la categoría elegida forma parte de la simulación y el pedido.
const tiposPorGrupo = {
  salados: [{id:'plato_fondo', nombre:'Platos principales'}, {id:'entrada', nombre:'Entradas'},
            {id:'acompanamiento', nombre:'Acompañamientos'}, {id:'canape', nombre:'Canapés'},
            {id:'bocado_salado', nombre:'Bocados salados'}],
  dulces: [{id:'postre', nombre:'Postres'}, {id:'bocado_dulce', nombre:'Bocados dulces'},
           {id:'reposteria', nombre:'Repostería'}],
  bebidas_frias: [{id:'bebida_fria', nombre:'Bebidas frías'}],
  bebidas_calientes: [{id:'bebida_caliente', nombre:'Bebidas calientes'}],
};
const inicial = { personas:'50', presupuesto:'500000', fecha:hoy(), ubicacion:'',
  tipo_evento:'Cumpleaños', grupo:'salados', tipo_preparacion:'plato_fondo', ficha_ids:[], restricciones:[] };
''', ruta)
        texto = unico(texto,
            "  const cambiarEvento = (campo, valor) => { setEvento(e => ({...e,[campo]:valor})); setResultado(null); setElegida(null); setFinalizada(null); };\n",
            """  const cambiarEvento = (campo, valor) => {
    setEvento(e => {
      if (campo === 'grupo') return {...e, grupo:valor, tipo_preparacion:tiposPorGrupo[valor][0].id, ficha_ids:[]};
      if (campo === 'tipo_preparacion') return {...e, tipo_preparacion:valor, ficha_ids:[]};
      return {...e, [campo]:valor};
    });
    setResultado(null); setElegida(null); setFinalizada(null);
  };
""", ruta)
        texto = unico(texto,
            '            <label className="mica-cliente-ancho">Preparación que te interesa (opcional) <select value={evento.ficha_ids[0] || \'\'} onChange={e=>cambiarEvento(\'ficha_ids\',e.target.value ? [Number(e.target.value)] : [])}><option value="">Mostrar opciones disponibles</option>{preparaciones.map(p=><option key={p.id} value={p.id}>{p.nombre}</option>)}</select></label>\n',
            '''            <label>¿Qué necesitas para tu evento?
              <select value={evento.grupo} onChange={e=>cambiarEvento('grupo',e.target.value)}>
                <option value="salados">Preparaciones saladas</option>
                <option value="dulces">Preparaciones dulces</option>
                <option value="bebidas_frias">Bebidas frías</option>
                <option value="bebidas_calientes">Bebidas calientes</option>
              </select>
            </label>
            <label>Tipo de preparación
              <select value={evento.tipo_preparacion} onChange={e=>cambiarEvento('tipo_preparacion',e.target.value)}>
                {(tiposPorGrupo[evento.grupo] || []).map(t=><option key={t.id} value={t.id}>{t.nombre}</option>)}
              </select>
            </label>
            <label className="mica-cliente-ancho">Preparación específica (opcional)
              <select value={evento.ficha_ids[0] || ''} onChange={e=>cambiarEvento('ficha_ids',e.target.value ? [Number(e.target.value)] : [])}>
                <option value="">Comparar hasta tres alternativas de este tipo</option>
                {preparaciones.filter(p=>p.tipo_preparacion===evento.tipo_preparacion).map(p=><option key={p.id} value={p.id}>{p.nombre}</option>)}
              </select>
              {!preparaciones.some(p=>p.tipo_preparacion===evento.tipo_preparacion) &&
                <small className="mica-cliente-aviso">Aún no hay fichas activas de esta categoría. El personal debe incorporar sus recetas antes de cotizarlas.</small>}
            </label>
''', ruta)
        return texto
    if ruta == 'mica/ai.py':
        texto = unico(texto,
            "    'y requiere validación humana. Responde en máximo 220 palabras.'\n",
            "    'y requiere validación humana. Responde en texto plano, sin tablas, '\n"
            "    'listas ni Markdown. No repitas todos los precios porque ya están en las tarjetas. '\n"
            "    'Escribe entre dos y cuatro frases y no excedas 100 palabras.'\n", ruta)
        texto = unico(texto,
            """    respaldo = _reglas(resumen)
""",
            """    respaldo = _reglas(resumen)
""", ruta) if False else texto
        return texto
    raise RuntimeError('Archivo fuera del parche: ' + ruta)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--proyecto', required=True)
    parser.add_argument('--aplicar', action='store_true')
    args = parser.parse_args()
    proyecto = Path(args.proyecto).resolve()
    fuente = Path(__file__).resolve().parent
    actualizables = ['mica/services.py', 'mica/publico.py', 'mica/ai.py',
                    'gestion/serializers.py', 'frontend/src/App.jsx', 'frontend/src/MicaCliente.jsx']
    nuevos = ['mica/catalogo.py', 'mica/tests/test_catalogo_v25b1.py']
    print('=== MICA CATÁLOGO v2.5B1 ===')
    print('Proyecto:', proyecto)
    try:
        if not (proyecto / 'manage.py').is_file():
            raise RuntimeError('La carpeta no contiene manage.py.')
        cambios = {}
        for ruta in actualizables:
            archivo = proyecto / ruta
            if not archivo.is_file():
                raise RuntimeError('No existe ' + ruta)
            texto = transformar(ruta, archivo.read_text(encoding='utf-8-sig'))
            if ruta.endswith('.py'):
                compile(texto, ruta, 'exec')
            cambios[ruta] = texto
        for ruta in nuevos:
            if (proyecto / ruta).exists():
                raise RuntimeError('Archivo nuevo ya existente: ' + ruta)
            if not (fuente / ruta).is_file():
                raise RuntimeError('Falta archivo incluido en el ZIP: ' + ruta)
            compile((fuente / ruta).read_text(encoding='utf-8'), ruta, 'exec')
        print('Archivos por actualizar:', ', '.join(actualizables))
        print('Archivos nuevos:', ', '.join(nuevos))
        print('Sin migraciones, cambios de BD ni modificaciones al inventario.')
        if not args.aplicar:
            print('PLAN CORRECTO. NO SE CAMBIO NINGUN ARCHIVO.')
            return
        respaldo = proyecto.parent / '02_Respaldos' / 'Codigo' / ('mica_v25b1_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
        copiados = []
        escritos = []
        try:
            for ruta in actualizables:
                destino = respaldo / ruta
                destino.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(proyecto / ruta, destino)
                copiados.append(ruta)
            for ruta, contenido in cambios.items():
                destino = proyecto / ruta
                temporal = destino.with_name(destino.name + '.tmp_v25b1')
                temporal.write_text(contenido, encoding='utf-8')
                temporal.replace(destino)
                escritos.append(ruta)
            for ruta in nuevos:
                destino = proyecto / ruta
                destino.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(fuente / ruta, destino)
                escritos.append(ruta)
        except Exception:
            for ruta in actualizables:
                if ruta in copiados:
                    shutil.copy2(respaldo / ruta, proyecto / ruta)
            for ruta in nuevos:
                if ruta in escritos:
                    (proyecto / ruta).unlink(missing_ok=True)
            raise
        print('INSTALACION COMPLETADA. Respaldo:', respaldo)
        print('Ejecutar python manage.py check y las pruebas antes de usar.')
    except Exception as exc:
        print('DETENIDO:', exc)
        raise SystemExit(2)


if __name__ == '__main__':
    main()
