# MICA v2.2: instala SDK de Groq y expone nombre/modelo en la simulacion publica.
# NO cambia PostgreSQL, .env, pedidos, cotizaciones ni migraciones.
param(
    [Parameter(Mandatory=$true)]
    [string]$Proyecto
)
$ErrorActionPreference = 'Stop'
$Proyecto = (Resolve-Path -LiteralPath $Proyecto).Path
$Origen = Join-Path $PSScriptRoot 'archivos'

if (-not (Test-Path -LiteralPath (Join-Path $Proyecto 'manage.py'))) {
    throw 'La ruta indicada no es la carpeta raiz del proyecto: falta manage.py.'
}
if (-not (Test-Path -LiteralPath (Join-Path $Proyecto '.env'))) {
    throw 'Falta .env en la carpeta raiz del proyecto.'
}

$relativos = @(
    'mica/ai.py',
    'mica/tests/test_ai_proveedores.py',
    'scripts/diagnosticar_ia.py',
    'requirements-ia.txt'
)
foreach ($rel in $relativos) {
    if (-not (Test-Path -LiteralPath (Join-Path $Origen $rel))) {
        throw "Falta el archivo de instalacion: $rel"
    }
}

$publico = Join-Path $Proyecto 'mica/publico.py'
if (-not (Test-Path -LiteralPath $publico)) {
    throw 'Falta mica/publico.py. Instale MICA Consumidor v2.1 antes del parche.'
}
$texto = [System.IO.File]::ReadAllText($publico)
$marcador = "'explicacion': {'modo': explicacion['modo'], 'mensaje': explicacion['mensaje']},"
if (-not $texto.Contains($marcador)) {
    throw 'mica/publico.py no coincide con MICA v2.1. No se modifico nada para evitar sobrescribir cambios.'
}

$marcaTiempo = Get-Date -Format 'yyyyMMdd_HHmmss'
$respaldo = Join-Path (Split-Path $Proyecto -Parent) "Respaldo_MICA_antes_Groq_SDK_$marcaTiempo"
New-Item -ItemType Directory -Path $respaldo | Out-Null

# Antes de modificar, respaldar todos los archivos que ya existan.
$respaldados = @()
foreach ($rel in ($relativos + @('mica/publico.py'))) {
    $destino = Join-Path $Proyecto $rel
    if (Test-Path -LiteralPath $destino) {
        $back = Join-Path $respaldo $rel
        New-Item -ItemType Directory -Path (Split-Path $back -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $destino -Destination $back -Force
        $respaldados += $rel
    }
}

try {
    foreach ($rel in $relativos) {
        $destino = Join-Path $Proyecto $rel
        New-Item -ItemType Directory -Path (Split-Path $destino -Parent) -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $Origen $rel) -Destination $destino -Force
        Write-Host "Instalado: $rel"
    }
    $extra = "'explicacion': {'modo': explicacion['modo'], 'mensaje': explicacion['mensaje'],`n                         'proveedor': explicacion.get('proveedor', 'reglas'),`n                         'modelo': explicacion.get('modelo'),`n                         'proveedor_activo': explicacion.get('proveedor_activo', False)},"
    $nuevo = $texto.Replace($marcador, $extra)
    [System.IO.File]::WriteAllText($publico, $nuevo, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host 'Actualizado: mica/publico.py (solo informacion del proveedor/modelo).'
}
catch {
    # Dejar la copia anterior si ocurre una excepcion durante la instalacion.
    foreach ($rel in $respaldados) {
        Copy-Item -LiteralPath (Join-Path $respaldo $rel) -Destination (Join-Path $Proyecto $rel) -Force
    }
    throw
}

Write-Host ''
Write-Host 'PARCHE INSTALADO. No se cambio .env, PostgreSQL ni frontend.' -ForegroundColor Green
Write-Host "Respaldo: $respaldo"
Write-Host 'Verificacion: python manage.py check; python -m scripts.diagnosticar_ia'
