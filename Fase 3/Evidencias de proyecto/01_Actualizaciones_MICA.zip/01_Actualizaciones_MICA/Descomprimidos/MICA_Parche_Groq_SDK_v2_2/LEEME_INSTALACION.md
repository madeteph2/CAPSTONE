# Parche MICA v2.2 — Conexión real con Groq SDK

## Alcance

- Sustituye la comunicación Groq de `mica/ai.py` por el cliente oficial `groq`, que ya respondió correctamente a la prueba de la usuaria.
- Conserva el cálculo de precios en Django y PostgreSQL, y el modo de respaldo por reglas cuando la IA no responde.
- La respuesta de `/api/mica/publico/simular/` incorpora `explicacion.proveedor`, `explicacion.modelo` y `explicacion.proveedor_activo`, para que la interfaz del consumidor pueda identificar la IA realmente utilizada.
- Agrega `scripts/diagnosticar_ia.py` para probar sin modificar la base.
- Incluye `requirements-ia.txt` solo para equipos que activen IA.
- **No** altera `settings.py`, `.env`, migraciones, tablas, registros, pedido ni cliente.

## Pasos en Windows (terminal PowerShell integrada de VS Code)

**1.** Detener Django con Ctrl+C. Descomprimir `MICA_Parche_Groq_SDK_v2_2.zip` en `C:\Users\madel\OneDrive\Escritorio\Capstone`, junto al proyecto original (sin copiar archivos manualmente).

**2.** Desde PowerShell:

```powershell
$Proyecto = 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Banqueteria_Proyecto'
$Parche = 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Parche_Groq_SDK_v2_2'
& (Join-Path $Parche 'INSTALAR_PARCHE_MICA_GROQ.ps1') -Proyecto $Proyecto
```

Si aparece `PARCHE INSTALADO`, la actualización se copió y el proyecto anterior quedó respaldado.

**3.** En la carpeta principal del proyecto y con `.venv` activo:

```powershell
Set-Location -LiteralPath $Proyecto
.\.venv\Scripts\Activate.ps1
python -m pip show groq
python manage.py check
python -m scripts.diagnosticar_ia
```

**Esperado para una llamada real exitosa:** `Modo: ia`, `Proveedor: groq`, `Modelo: openai/gpt-oss-20b`, `IA activa: True`.

Si funciona, reiniciar Django y generar una nueva simulación en la página `/cotizar`. El texto mostrará la IA y el nombre del modelo que respondió. **No envíe la clave API a otra persona.**

## Control de errores

- `No module named groq`: en el `.venv` correcto, ejecutar `python -m pip install -r requirements-ia.txt`.
- `Modo: reglas`: el proveedor no respondió o no generó contenido válido; el backend no ha modificado precios ni datos.
- Mensaje `MICA: fallo del proveedor groq (tipo=..., HTTP=...)`: revisar el código y estado HTTP; no compartir credenciales.
- Si el instalador dice que `mica/publico.py` no coincide con v2.1, **no** forzar la sustitución; revisar el código vigente primero.

## Limitaciones funcionales

La IA **explica** cotizaciones construidas con fichas y reglas. Todavía no crea libremente nuevos menús, no fija precios, no valida alergias, ni aprueba pedidos. La aprobación continúa siendo responsabilidad humana.
