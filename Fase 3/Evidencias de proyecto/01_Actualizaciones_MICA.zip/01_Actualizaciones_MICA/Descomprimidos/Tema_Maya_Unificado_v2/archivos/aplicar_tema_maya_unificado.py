#!/usr/bin/env python3
"""MAYA Tema Unificado v2 — simulación por defecto, aplicación con respaldo.
Sin modificaciones de Django ni de base de datos.
"""
import argparse, datetime, hashlib, json, shutil, sys
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser(description="Aplicar Tema Maya Unificado v2 con respaldos")
    ap.add_argument('--proyecto',required=True,help='Ruta a MICA_Banqueteria_Proyecto')
    ap.add_argument('--aplicar',action='store_true',help='Aplicar tras revisión')
    args=ap.parse_args()
    raiz=Path(args.proyecto).expanduser().resolve()
    payload=Path(__file__).resolve().parent
    manifest=json.loads((payload/'manifest.json').read_text(encoding='utf-8'))
    print('=== TEMA MAYA UNIFICADO v2 — LOGOTIPO OFICIAL ===')
    print('Proyecto:',raiz)
    print('Alcance: login, menu lateral, barra de usuario, MICA publico y MICA admin')
    print('Se conserva App.css, MicaCliente.css, MicaVista.css y MarcaMayaTema.css (esta ultima sin imports).')
    print('No modifica Python, APIs, PostgreSQL ni migraciones.')
    if not raiz.is_dir():
        sys.exit('ERROR: no existe la carpeta del proyecto.')
    if not (raiz/'frontend'/'src'/'App.jsx').is_file():
        sys.exit('ERROR: estructura frontend/src no encontrada.')
    errores=[]; cambios=[]
    for rel,hashes in manifest.items():
        actual=raiz.joinpath(*Path(rel).parts)
        destino=payload.joinpath(*Path(rel).parts)
        if not destino.is_file():
            errores.append(f'{rel}: falta archivo en el parche')
            continue
        if digest(destino)!=hashes['destino']:
            errores.append(f'{rel}: checksum del parche no coincide')
            continue
        if not actual.is_file():
            errores.append(f'{rel}: no existe archivo actual')
            continue
        actual_sha=digest(actual)
        if actual_sha==hashes['destino']:
            print('YA INSTALADO:',rel)
        elif actual_sha==hashes['original']:
            print('ACTUALIZAR:',rel)
            cambios.append((rel,actual,destino))
        else:
            errores.append(f'{rel}: difiere de los archivos compartidos; detener para no sobreescribir cambios locales')
    if errores:
        print('NO SE MODIFICO NINGUN ARCHIVO.')
        for e in errores:print('ERROR:',e)
        sys.exit(2)
    if not cambios:
        print('TODO ACTUALIZADO. NO SE REALIZARON CAMBIOS.')
        return
    if not args.aplicar:
        print('PLAN CORRECTO. NO SE CAMBIO NINGUN ARCHIVO.')
        print('Para instalar: repetir el mismo comando con --aplicar.')
        return
    carpeta=raiz.parent/'02_Respaldos'/'Codigo'
    respaldo=carpeta/('tema_maya_unificado_v2_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    try:
        for rel,actual,_ in cambios:
            copia=respaldo.joinpath(*Path(rel).parts)
            copia.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(actual,copia)
        # All validations and backup completed before replacing any file.
        hechos=[]
        try:
            for rel,actual,nuevo in cambios:
                tmp=actual.with_name(actual.name+'.maya_v2_tmp')
                shutil.copyfile(nuevo,tmp)
                tmp.replace(actual)
                hechos.append((rel,actual))
        except BaseException:
            for rel,actual in reversed(hechos):
                shutil.copy2(respaldo.joinpath(*Path(rel).parts),actual)
            raise
        print('INSTALACION COMPLETADA.')
        print('Respaldo:',respaldo)
        print('Siguiente validacion: cd frontend; npm.cmd run build')
    except Exception as exc:
        print('ERROR DURANTE INSTALACION:',exc)
        print('Revise respaldo:',respaldo)
        sys.exit(3)

if __name__=='__main__': main()
