# Banquetería Maya — Tema Unificado v2

## Alcance
- Paleta vino, malva, crema y dorado centralizada en `frontend/src/TemaMayaGlobal.css`.
- Logo burgundy/dorado, sin fondo, optimizado a 512 × 512 PNG; se guarda en `frontend/src/assets/logo_maya.png`.
- Logo en login, menú lateral, avatar del administrador, cabecera de MICA interno y cotizador público.
- Reutiliza `App.css`, `MicaCliente.css` y `MicaVista.css` como estilos de estructura; no son archivos redundantes.
- Desactiva la importación de `MarcaMayaTema.css` en los dos JSX, pero no borra el archivo del proyecto por seguridad. Puede retirarse en otro commit tras la prueba visual.
- No modifica módulos de backend, APIs, migraciones, datos ni modelos.

## Instalación — Windows PowerShell
Coloque el ZIP en `Capstone\01_Actualizaciones_MICA\ZIP_Originales`.

```powershell
$Base = "C:\Users\madel\OneDrive\Escritorio\Capstone\01_Actualizaciones_MICA"
$Proyecto = "C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Banqueteria_Proyecto"
Expand-Archive -LiteralPath "$Base\ZIP_Originales\Tema_Maya_Unificado_v2.zip" -DestinationPath "$Base\Descomprimidos" -Force
$Parche = "$Base\Descomprimidos\Tema_Maya_Unificado_v2\archivos\aplicar_tema_maya_unificado.py"
python $Parche --proyecto $Proyecto
```

Si muestra `PLAN CORRECTO`, entonces instalar:
```powershell
python $Parche --proyecto $Proyecto --aplicar
cd "$Proyecto\frontend"
npm.cmd run build
```

## Seguridad
- Instalador en modo simulación por defecto.
- Compara SHA-256 original y nuevo de cada archivo contra el ZIP de fuentes que envió el usuario.
- Si algún archivo local difiere, se detiene SIN sobrescribirlo; solicitar revisión puntual.
- Hace respaldo de todos los archivos actualizados en `Capstone\02_Respaldos\Codigo\tema_maya_unificado_v2_...`.
- Si se ejecuta dos veces no vuelve a cambiar archivos ya actualizados.

## Pruebas manuales sugeridas
1. Login: logo visible y contraste del título/botón.
2. Acceder: logo menú lateral y avatar, navegación funcional.
3. Cotizador administrativo: logo y paquetes visibles.
4. Cotizador público `/cotizar`: logo y simulación sin cambios de comportamiento.
5. Pantallas de clientes, eventos, pedidos, fichas, inventario y ventas sin roturas de diseño.
6. Capturas de evidencia antes/después y compilación `npm.cmd run build` aprobada.

**Nota:** No borre `App.css`, `MicaCliente.css` ni `MicaVista.css`. `MarcaMayaTema.css` está sin imports desde este parche, pero se conserva en disco hasta después de verificar.
