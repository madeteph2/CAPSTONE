# Identidad visual MICA · Borgoña y crema (v1)

Este parche modifica únicamente el encabezado de `MicaCliente.jsx` y el de `MicaVista.jsx`, añadiendo `MarcaMayaTema.css`. No modifica bases de datos, inventario, endpoints ni lógica de cotización. El logo temporal «BM» reserva un cuadro de 52x52 píxeles. Tipografía: Georgia en títulos y Segoe UI para formularios, sin dependencias externas.

## En Windows PowerShell

1. Descomprime el ZIP en `Capstone\01_Actualizaciones_MICA\Descomprimidos`.
2. Ejecuta `python aplicar_marca_maya.py --proyecto "RUTA\MICA_Banqueteria_Proyecto"` desde la carpeta `archivos` para simular.
3. Si la simulación es correcta, repite agregando `--aplicar`. Se crea respaldo en `Capstone\02_Respaldos\Codigo`.
4. Con Vite ejecutándose, abre `/cotizar` y el Cotizador MICA interno. Si es necesario usa `Ctrl + F5`.

**Alcance:** solo las dos vistas de MICA. Para aplicar la marca a todo el sistema (menú global, login, dashboard), harán falta `App.jsx` y los archivos CSS de esa interfaz.
