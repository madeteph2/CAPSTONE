#!/usr/bin/env python3
"""Parche visual no destructivo MICA: simular por defecto, --aplicar guarda respaldos."""
import argparse
from pathlib import Path
from datetime import datetime
from shutil import copy2
import sys

MARCADOR = 'MAYA_MARCA_BORGONA_V1'
BASE = Path(__file__).resolve().parent
CSS_ORIGEN = BASE / 'MarcaMayaTema.css'

HEADER_ANTES = '<header className="mica-cliente-header"><div><strong>Banquetería Maya</strong><span>Solicitud de evento · MICA</span></div><a href="/">Acceso al personal</a></header>'
HEADER_DESPUES = '<header className="mica-cliente-header"><div className="maya-marca"><span className="maya-logo-reserva" aria-label="Espacio reservado para el logotipo">BM</span><div className="maya-marca-texto"><strong className="maya-marca-nombre">Banquetería Maya</strong><span className="maya-marca-subtitulo">Solicitud de evento · MICA</span></div></div><a href="/">Acceso al personal</a></header>'
ADMIN_ANTES = '  return <div className="mica">\n    <div className="w03-heading">'
ADMIN_DESPUES = '  return <div className="mica">\n    <div className="maya-marca maya-marca-admin"><span className="maya-logo-reserva" aria-label="Espacio reservado para el logotipo">BM</span><div className="maya-marca-texto"><strong className="maya-marca-nombre">Banquetería Maya</strong><span className="maya-marca-subtitulo">Administración de cotizaciones · MICA</span></div></div>\n    <div className="w03-heading">'

def preparar(ruta, clase, antes, despues):
    texto = ruta.read_text(encoding='utf-8')
    if MARCADOR in texto:
        raise RuntimeError(f'Parche ya instalado: {ruta}. No se repite.')
    if texto.count(antes) != 1:
        raise RuntimeError(f'No coincide estructura esperada en {ruta.name}. No se modificará.')
    if texto.count(clase) != 1:
        raise RuntimeError(f'Import CSS no encontrado o ambiguo en {ruta.name}.')
    return texto.replace(clase, clase + "\nimport './MarcaMayaTema.css'; // " + MARCADOR, 1).replace(antes, despues, 1)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--proyecto', required=True)
    parser.add_argument('--aplicar', action='store_true')
    args=parser.parse_args()
    p=Path(args.proyecto).expanduser().resolve()
    src=p/'frontend'/'src'
    c=src/'MicaCliente.jsx'
    a=src/'MicaVista.jsx'
    css_destino=src/'MarcaMayaTema.css'
    for ruta in [c,a]:
        if not ruta.is_file(): raise FileNotFoundError(f'No existe {ruta}')
    if css_destino.exists():
        raise RuntimeError('Ya existe MarcaMayaTema.css. No se sobrescribe un archivo desconocido.')
    public=preparar(c, "import './MicaCliente.css';", HEADER_ANTES, HEADER_DESPUES)
    admin=preparar(a, "import './MicaVista.css';", ADMIN_ANTES, ADMIN_DESPUES)
    print('=== MARCA BANQUETERIA MAYA · TEMA BORGONA v1 ===')
    print('Proyecto:',p)
    print('Cambia:',c.relative_to(p),',',a.relative_to(p))
    print('Crea:',css_destino.relative_to(p))
    print('No cambia API, Python, datos ni migraciones.')
    if not args.aplicar:
        print('PLAN CORRECTO. NO SE CAMBIO NINGUN ARCHIVO.')
        return
    # Respaldo antes de escribir, fuera del proyecto frontend.
    bk=p.parent/'02_Respaldos'/'Codigo'/('maya_marca_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    bk.mkdir(parents=True, exist_ok=False)
    for ruta in [c,a]:
        copyto=bk/ruta.relative_to(p)
        copyto.parent.mkdir(parents=True,exist_ok=True)
        copy2(ruta,copyto)
    # Conservar saltos CRLF de origen si existen.
    def guardar(ruta, texto):
        with open(ruta, 'w', encoding='utf-8', newline='') as f:
            f.write(texto)
    def preservar(ruta, nuevo):
        with open(ruta, 'r', encoding='utf-8', newline='') as f:
            original=f.read()
        if '\r\n' in original: nuevo=nuevo.replace('\n', '\r\n')
        guardar(ruta,nuevo)
    preservar(c,public)
    preservar(a,admin)
    copy2(CSS_ORIGEN,css_destino)
    print('INSTALACION VISUAL COMPLETADA. Respaldo:',bk)
    print('Comprueba las vistas MICA y /cotizar en el navegador.')

if __name__ == '__main__':
    try: main()
    except Exception as ex:
        print('ERROR:',ex,file=sys.stderr)
        sys.exit(1)
