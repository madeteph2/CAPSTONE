r"""Parche conservador MICA v2.3. No toca .env ni PostgreSQL directamente.

Ejemplos:
  python aplicar_parche_reservas.py --proyecto C:\ruta\MICA_Banqueteria_Proyecto
  python aplicar_parche_reservas.py --proyecto C:\ruta\MICA_Banqueteria_Proyecto --aplicar
"""
import argparse
import shutil
from pathlib import Path
from datetime import datetime

VERSION = 'MICA_RESERVAS_V2_3'


def cambiar(texto, antes, despues, nombre):
    veces = texto.count(antes)
    if veces != 1:
        raise RuntimeError(f'Archivo {nombre}: patrón esperado no aparece exactamente 1 vez (encontrado {veces}). No se aplicó el parche.')
    return texto.replace(antes, despues, 1)


def transformar(ruta, texto):
    if VERSION in texto:
        raise RuntimeError(f'{ruta}: el parche ya está aplicado. No repetir.')
    if ruta == 'mica/models.py':
        texto = cambiar(texto, "('rechazada', 'Rechazada'),", "('rechazada', 'Rechazada'), ('cancelada', 'Cancelada'),", ruta)
        texto += '''\n\n# MICA_RESERVAS_V2_3: compromisos de ingredientes sin descontar stock físico.\nclass ReservaInsumoMica(models.Model):\n    ESTADOS = [('reservada', 'Reservada'), ('consumida', 'Consumida'), ('liberada', 'Liberada')]\n    pedido = models.ForeignKey('gestion.Pedido', on_delete=models.PROTECT, related_name='reservas_mica')\n    id_insumo = models.ForeignKey('gestion.Insumo', on_delete=models.PROTECT)\n    id_bodega = models.ForeignKey('gestion.Bodega', on_delete=models.PROTECT)\n    cantidad = models.DecimalField(max_digits=12, decimal_places=3)\n    estado = models.CharField(max_length=12, choices=ESTADOS, default='reservada')\n    creada_en = models.DateTimeField(default=__import__('django.utils.timezone', fromlist=['now']).now)\n\n    class Meta:\n        constraints = [\n            models.UniqueConstraint(fields=['pedido', 'id_insumo', 'id_bodega'], name='mica_reserva_pedido_insumo_bodega_unica'),\n            models.CheckConstraint(condition=models.Q(cantidad__gt=0), name='mica_reserva_cantidad_positiva'),\n        ]\n'''
        # La clase usa timezone.now sin importarlo nuevamente, porque el módulo original
        # ya importa from django.utils import timezone (comprobado).
        texto = cambiar(texto, "default=__import__('django.utils.timezone', fromlist=['now']).now", "default=timezone.now", ruta)
        return texto
    if ruta == 'mica/publico.py':
        texto = cambiar(texto, 'from .ai import explicar\n',
                        'from .ai import explicar\nfrom .reservas import reservar_pedido, liberar_reservas, ReservaError  # MICA_RESERVAS_V2_3\n', ruta)
        inicio = "        if datos['accion'] == 'aprobar':\n            faltantes_actuales = False\n"
        fin = "        else:\n            nombre_estado, nuevo = 'RECHAZADO', 'rechazada'\n"
        pos_a = texto.find(inicio)
        pos_b = texto.find(fin, pos_a)
        if pos_a < 0 or pos_b < 0 or texto.find(inicio, pos_a+1) >= 0:
            raise RuntimeError(f'{ruta}: no coincide el bloque de revisión de stock; instalación cancelada.')
        texto = texto[:pos_a] + "        if datos['accion'] == 'aprobar':\n            nombre_estado, nuevo = 'CONFIRMADO', 'aprobada'\n" + texto[pos_b:]
        texto = cambiar(texto, "        pedido.id_estado_pedido = estado\n        pedido.save(update_fields=['id_estado_pedido', 'updated_at'])\n",
                        "        if datos['accion'] == 'aprobar':\n            try:\n                reservas_creadas = reservar_pedido(cot, propuesta, pedido)\n            except ReservaError as exc:\n                return Response({'detail': str(exc)}, status=409)\n        else:\n            reservas_creadas = 0\n        pedido.id_estado_pedido = estado\n        pedido.save(update_fields=['id_estado_pedido', 'updated_at'])\n", ruta)
        texto = cambiar(texto,
                        "        return Response({'pedido_id': pedido.pk, 'numero_pedido': pedido.numero_pedido, 'estado': nuevo})\n",
                        "        return Response({'pedido_id': pedido.pk, 'numero_pedido': pedido.numero_pedido, 'estado': nuevo, 'reservas_creadas': reservas_creadas})\n", ruta)
        texto += '''\n\n# MICA_RESERVAS_V2_3: cancelación de pedido confirmado, libera la reserva sin descontar inventario.\nclass MicaCancelarConfirmadoView(APIView):\n    permission_classes = [IsAdminUser]\n\n    @transaction.atomic\n    def post(self, request, pk):\n        cot = get_object_or_404(CotizacionMica.objects.select_for_update(), pk=pk, origen='publico')\n        if cot.estado != 'aprobada' or not cot.pedido_id:\n            return Response({'detail': 'Solo se cancelan pedidos públicos aprobados aún no preparados.'}, status=409)\n        pedido = Pedido.objects.select_for_update().select_related('id_estado_pedido').get(pk=cot.pedido_id)\n        if pedido.id_estado_pedido.nombre_estado.upper() != 'CONFIRMADO':\n            return Response({'detail': 'No se puede cancelar desde MICA un pedido en preparación u otro estado.'}, status=409)\n        reservas = ReservaInsumoMica.objects.select_for_update().filter(pedido=pedido, estado='reservada')\n        if not reservas.exists():\n            return Response({'detail': 'No existen reservas activas para liberar. Requiere revisión manual.'}, status=409)\n        estado = EstadoPedido.objects.filter(nombre_estado__iexact='CANCELADO').first()\n        if not estado:\n            return Response({'detail': 'No existe estado CANCELADO.'}, status=503)\n        anterior = pedido.id_estado_pedido\n        liberadas = liberar_reservas(pedido)\n        pedido.id_estado_pedido = estado\n        pedido.save(update_fields=['id_estado_pedido', 'updated_at'])\n        if cot.evento_id:\n            Evento.objects.filter(pk=cot.evento_id).update(estado='cancelado')\n        cot.estado = 'cancelada'\n        cot.nota_revision = ('Cancelado por personal. ' + str(request.data.get('nota') or ''))[:1000]\n        cot.revisada_en = timezone.now()\n        cot.revisada_por = request.user\n        cot.save(update_fields=['estado', 'nota_revision', 'revisada_en', 'revisada_por'])\n        usuario = Usuario.objects.filter(email=request.user.email).first() if request.user.email else None\n        HistorialPedido.objects.create(\n            id_pedido=pedido, id_estado_anterior=anterior, id_estado_nuevo=estado,\n            observacion=f'MICA: cancelación con {liberadas} reservas liberadas.',\n            id_usuario=usuario, fecha_cambio=timezone.now(),\n        )\n        return Response({'pedido_id': pedido.pk, 'numero_pedido': pedido.numero_pedido,\n                         'estado': 'cancelada', 'reservas_liberadas': liberadas})\n'''
        texto = cambiar(texto, 'from .models import CotizacionMica, PropuestaMica\n',
                        'from .models import CotizacionMica, PropuestaMica, ReservaInsumoMica\n', ruta)
        return texto
    if ruta == 'mica/views.py':
        texto = cambiar(texto, 'from .models import CotizacionMica, PropuestaMica\n',
                        'from .models import CotizacionMica, PropuestaMica, ReservaInsumoMica  # MICA_RESERVAS_V2_3\n', ruta)
        texto = cambiar(texto,
                        "        'numero_pedido': c.pedido.numero_pedido if c.pedido_id else None,\n",
                        "        'numero_pedido': c.pedido.numero_pedido if c.pedido_id else None,\n        'pedido_estado': c.pedido.id_estado_pedido.nombre_estado if c.pedido_id else None,\n        'reservas_activas': ReservaInsumoMica.objects.filter(pedido_id=c.pedido_id, estado='reservada').count() if c.pedido_id else 0,\n", ruta)
        texto = cambiar(texto,
                        '                      MicaPublicoSolicitarView, MicaRevisionPublicaView)\n',
                        '                      MicaPublicoSolicitarView, MicaRevisionPublicaView, MicaCancelarConfirmadoView)\n', ruta)
        return texto
    if ruta == 'mica/services.py':
        texto = cambiar(texto, 'from gestion.models import FichaTecnica, Receta, Inventario\n',
                        'from gestion.models import FichaTecnica, Receta, Inventario\nfrom django.db.models import Sum\nfrom .models import ReservaInsumoMica  # MICA_RESERVAS_V2_3\n', ruta)
        texto = cambiar(texto,
                        "        # La consulta solo se usa como indicación; cotizar no reserva inventario.\n        stock = sum((Decimal(i.stock_actual) for i in Inventario.objects.filter(id_insumo=insumo, estado='activo')), Decimal('0'))\n",
                        "        # Disponible = físico - reservas activas; la simulación nunca descuenta stock.\n        stock_fisico = sum((Decimal(i.stock_actual) for i in Inventario.objects.filter(id_insumo=insumo, estado='activo')), Decimal('0'))\n        comprometido = ReservaInsumoMica.objects.filter(id_insumo=insumo, estado='reservada').aggregate(total=Sum('cantidad'))['total'] or Decimal('0')\n        stock = max(Decimal('0'), stock_fisico - Decimal(comprometido))\n", ruta)
        return texto
    if ruta == 'mica/urls.py':
        texto = cambiar(texto, 'MicaRevisionPublicaView\n', 'MicaRevisionPublicaView, MicaCancelarConfirmadoView  # MICA_RESERVAS_V2_3\n', ruta)
        texto = cambiar(texto,
                        "    path('cotizaciones/<int:pk>/revision/', MicaRevisionPublicaView.as_view(), name='mica-publico-revisar'),\n",
                        "    path('cotizaciones/<int:pk>/revision/', MicaRevisionPublicaView.as_view(), name='mica-publico-revisar'),\n    path('cotizaciones/<int:pk>/cancelar/', MicaCancelarConfirmadoView.as_view(), name='mica-publico-cancelar'),\n", ruta)
        return texto
    if ruta == 'frontend/src/MicaVista.jsx':
        texto = cambiar(texto,
                        "  const verGuardada = c => {\n",
                        "  // MICA_RESERVAS_V2_3: permite liberar reservas de pedidos aún no preparados.\n  const cancelarConfirmado = async c => {\n    if (!window.confirm(`¿Cancelar ${c.numero_pedido} y liberar las reservas de insumos?`)) return;\n    const nota = window.prompt('Motivo de cancelación:', '');\n    if (nota === null) return;\n    setCargando(true); setError(''); setMensaje('');\n    try {\n      const respuesta = await petición(`/api/mica/cotizaciones/${c.id}/cancelar/`, 'POST', {nota});\n      setMensaje(`Pedido ${respuesta.numero_pedido} cancelado; ${respuesta.reservas_liberadas} reservas liberadas.`);\n      await recargar();\n    } catch (e) { setError(e.message); }\n    finally { setCargando(false); }\n  };\n  const verGuardada = c => {\n", ruta)
        texto = cambiar(texto,
                        "    const seleccion = c.propuestas?.find(p => Number(p.id) === Number(c.propuesta_aceptada));\n    const requiereCompra = esAprobacion && seleccion?.requiere_compra;\n    const compra_confirmada = requiereCompra\n      ? window.confirm('La propuesta presenta faltantes de inventario. ¿Confirmas que se gestionará su compra/reposición?')\n      : false;\n",
                        "    // La aprobación ahora exige stock libre; una compra prometida no aumenta existencias.\n", ruta)
        texto = cambiar(texto,
                        "        {accion, nota, compra_confirmada});\n",
                        "        {accion, nota});\n", ruta)
        texto = cambiar(texto,
                        "      setMensaje(`Pedido ${respuesta.numero_pedido} actualizado a ${respuesta.estado}. Puedes abrirlo desde Pedidos para consultar o editar su información.`);\n",
                        "      setMensaje(`Pedido ${respuesta.numero_pedido} actualizado a ${respuesta.estado}. Reservas creadas: ${respuesta.reservas_creadas}. Consulta el detalle en Pedidos.`);\n", ruta)
        ancla = '    <section className="w02-card mica-card"><h2>Cotizaciones guardadas</h2>'
        seccion = '''    <section className="w02-card mica-card"><h2>Pedidos confirmados · reservas de ingredientes</h2>
      <p className="w02-note">Al aprobar un pedido público se reservan los insumos disponibles por bodega. El stock físico NO disminuye hasta registrar el consumo. Si se cancela antes de preparar, se liberan las reservas.</p>
      <div className="w02-table-scroll"><table className="w05-table mica-table"><thead><tr><th>Pedido</th><th>Estado</th><th>Reservas</th><th>Acciones</th></tr></thead>
        <tbody>{historial.filter(c=>c.origen==='publico' && c.estado==='aprobada' && c.pedido_estado==='CONFIRMADO').map(c=><tr key={c.id}>
          <td>{c.numero_pedido}</td><td>{c.pedido_estado}</td><td>{c.reservas_activas} registros</td>
          <td><button type="button" className="w04-secondary" disabled={cargando} onClick={()=>cancelarConfirmado(c)}>Cancelar y liberar reservas</button></td>
        </tr>)}
        {!historial.some(c=>c.origen==='publico' && c.estado==='aprobada' && c.pedido_estado==='CONFIRMADO') && <tr><td colSpan="4">Sin pedidos públicos confirmados con reservas.</td></tr>}
        </tbody></table></div>
    </section>
'''
        texto = cambiar(texto, ancla, seccion + ancla, ruta)
        texto = cambiar(texto,
                        '      <p className="w02-note">Cada solicitud externa ya registró un pedido en estado CREADO. Consulta y edita ese pedido en el módulo Pedidos; aquí puedes aprobarlo (CONFIRMADO) o rechazarlo (RECHAZADO).</p>',
                        '      <p className="w02-note">Cada solicitud externa ya registró un pedido CREADO. Al aprobar se reservan insumos; si faltan, primero registre la reposición en Inventario. La aprobación no descuenta existencias físicas.</p>', ruta)
        return texto
    if ruta == 'mica/tests/test_motor.py':
        # Se añade un mock porque la simulación consulta las reservas activas.
        texto = cambiar(texto, 'from mica.ai import explicar\n',
                        'from mica.ai import explicar\n# MICA_RESERVAS_V2_3: en pruebas unitarias la tabla de reservas se simula con un mock.\n', ruta)
        texto = cambiar(texto,
                        "        with patch('mica.services.Receta.objects.filter', return_value=FiltroQuery([rec])), patch(\n            'mica.services.Inventario.objects.filter', return_value=[obj(stock_actual=Decimal('5'))]):\n",
                        "        with patch('mica.services.Receta.objects.filter', return_value=FiltroQuery([rec])), patch(\n            'mica.services.Inventario.objects.filter', return_value=[obj(stock_actual=Decimal('5'))]), patch(\n            'mica.services.ReservaInsumoMica.objects.filter') as reservas:\n            reservas.return_value.aggregate.return_value = {'total': Decimal('0')}\n", ruta)
        texto = cambiar(texto,
                        "        with patch('mica.services.Receta.objects.filter', return_value=FiltroQuery([rec])), patch(\n            'mica.services.Inventario.objects.filter', return_value=[obj(stock_actual=Decimal('0'))]):\n",
                        "        with patch('mica.services.Receta.objects.filter', return_value=FiltroQuery([rec])), patch(\n            'mica.services.Inventario.objects.filter', return_value=[obj(stock_actual=Decimal('0'))]), patch(\n            'mica.services.ReservaInsumoMica.objects.filter') as reservas:\n            reservas.return_value.aggregate.return_value = {'total': Decimal('0')}\n", ruta)
        return texto
    raise RuntimeError(f'Archivo inesperado: {ruta}')


def main():
    parser = argparse.ArgumentParser(description='MICA v2.3: parche de reservas seguro y con simulación')
    parser.add_argument('--proyecto', required=True, help='Carpeta MICA_Banqueteria_Proyecto')
    parser.add_argument('--aplicar', action='store_true', help='Copia archivos tras crear respaldo')
    args = parser.parse_args()
    proyecto = Path(args.proyecto).expanduser().resolve()
    fuente = Path(__file__).resolve().parent
    if not (proyecto / 'manage.py').is_file() or not (proyecto / 'mica' / 'migrations' / '0002_cotizacion_publica.py').exists():
        raise SystemExit('DETENIDO: carpeta de proyecto o migración MICA v2.1 no encontrada.')
    rutas = ['mica/models.py', 'mica/publico.py', 'mica/views.py', 'mica/services.py',
             'mica/urls.py', 'mica/tests/test_motor.py', 'frontend/src/MicaVista.jsx']
    pendientes = {}
    try:
        for ruta in rutas:
            archivo = proyecto / ruta
            if not archivo.is_file():
                raise RuntimeError(f'Falta archivo requerido: {ruta}')
            pendientes[ruta] = transformar(ruta, archivo.read_text(encoding='utf-8'))
        nuevos = {'mica/reservas.py': fuente / 'mica' / 'reservas.py',
                  'mica/migrations/0003_reservainsumomica.py': fuente / 'mica' / 'migrations' / '0003_reservainsumomica.py',
                  'mica/tests/test_reservas.py': fuente / 'mica' / 'tests' / 'test_reservas.py',
                  'scripts/prever_reservas_mica.py': fuente / 'scripts' / 'prever_reservas_mica.py'}
        for ruta, origen in nuevos.items():
            if (proyecto / ruta).exists():
                raise RuntimeError(f'Archivo nuevo ya existente: {ruta}. No sobreescribir.')
            if not origen.is_file():
                raise RuntimeError(f'No se incluyó en el ZIP el archivo {ruta}.')
    except RuntimeError as e:
        raise SystemExit(f'DETENIDO SIN MODIFICACIONES: {e}')
    print('=== MICA v2.3 · RESERVAS DE INSUMOS ===')
    print('Proyecto:', proyecto)
    print('Cambios previstos:')
    for ruta in list(pendientes)+list(nuevos):
        print(' -', ruta)
    print('Sin cambios en .env, PostgreSQL, migrations anteriores, proveedores IA ni cantidades físicas.')
    if not args.aplicar:
        print('PLAN CORRECTO. NO SE CAMBIO NINGUN ARCHIVO. Ejecute --aplicar para instalar.')
        return
    destino = proyecto.parent / ('respaldo_codigo_mica_reservas_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
    destino.mkdir(parents=True, exist_ok=False)
    for ruta in pendientes:
        carpeta = destino / ruta
        carpeta.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(proyecto / ruta, carpeta)
    print('Respaldo del código:', destino)
    try:
        for ruta, contenido in pendientes.items():
            archivo = proyecto / ruta
            temporal = archivo.with_suffix(archivo.suffix + '.tmp')
            temporal.write_text(contenido, encoding='utf-8')
            temporal.replace(archivo)
        for ruta, origen in nuevos.items():
            carpeta = proyecto / ruta
            carpeta.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(origen, carpeta)
    except Exception as e:
        # Restaurar los cambios de código si falló cualquier copia.
        for ruta in pendientes:
            shutil.copy2(destino / ruta, proyecto / ruta)
        for ruta in nuevos:
            (proyecto / ruta).unlink(missing_ok=True)
        raise SystemExit(f'DETENIDO: hubo un error de copia, archivos restaurados. {type(e).__name__}')
    print('ARCHIVOS INSTALADOS. No se ejecutaron migraciones ni se modificó inventario.')
    print('SIGUIENTE: activar .venv, python manage.py check y python manage.py migrate --plan')


if __name__ == '__main__':
    main()
