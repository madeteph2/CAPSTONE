# MICA v2.3: reservas de ingredientes en pedidos públicos

**Etapa 1: reservas, sin consumo físico.** Versión para proyecto `MICA_Banqueteria_Proyecto` ya integrado con MICA v2.2, Django y PostgreSQL `sig_banqueteria_mica`.

## Qué se incorpora

- Tabla nueva `mica_reservainsumomica`, reservando por `pedido + insumo + bodega`.
- Al aprobar una solicitud **pública** en Cotizador MICA, valida la receta actual y el pedido, bloquea inventarios concurrentes y reserva el stock libre, sin descontar `inventario.stock_actual`.
- Si faltan ingredientes, devuelve un error y **no aprueba ni crea reservas parciales**. Una promesa de compra no sustituye entradas de stock reales.
- La simulación resta las reservas activas del stock físico para mostrar disponibilidad frente a nuevos pedidos.
- Se puede cancelar el pedido aprobado ANTES de comenzar la preparación, liberando sus reservas y registrando `CANCELADO` en el historial.
- Diagnóstico de solo lectura de reservas pendientes: `python -m scripts.prever_reservas_mica`.
- No modifica proveedores de IA ni el comportamiento de GPT-OSS.

## Alcance y límites

**Esta etapa NO implementa el consumo.** No existen aún acciones para descontar ingredientes. No mover pedidos a `EN_PREPARACION` desde aquí hasta instalar la etapa de movimientos de consumo. Los pedidos internos de MICA que se crean con **Aceptar y generar pedido** no quedan reservados automáticamente: esta etapa protege la **aprobación de solicitudes públicas**.

Si el personal editó preparación, comensales, precio o costo de un pedido antes de aprobar, la reserva se bloquea hasta recalcular y conciliar la cotización. Es una medida deliberada para no reservar cantidades de una receta desactualizada. La edición completa/re-cotización es una fase pendiente.

## Instalación segura (PowerShell en VS Code)

### A. Crear respaldo de PostgreSQL

```powershell
& 'C:\Program Files\PostgreSQL\18\bin\pg_dump.exe' -h 127.0.0.1 -p 5432 -U postgres -W -d sig_banqueteria_mica -Fc -f 'C:\Users\madel\OneDrive\Escritorio\Capstone\mica_antes_reservas_v23.backup'
```

Comprobar que el archivo existe y es mayor que 0 bytes.

### B. Extraer el ZIP en la carpeta Capstone (junto al proyecto)

```powershell
Expand-Archive -LiteralPath 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Reserva_Pedido_v2_3.zip' -DestinationPath 'C:\Users\madel\OneDrive\Escritorio\Capstone' -Force
```

### C. Activar .venv y simular instalación (NO cambia archivos)

```powershell
Set-Location -LiteralPath 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Banqueteria_Proyecto'
.\.venv\Scripts\Activate.ps1
$Parche = 'C:\Users\madel\OneDrive\Escritorio\Capstone\MICA_Reserva_Pedido_v2_3\archivos\aplicar_parche_reservas.py'
python $Parche --proyecto (Get-Location).Path
```

Si indica `PLAN CORRECTO`, ejecutar la instalación:

```powershell
python $Parche --proyecto (Get-Location).Path --aplicar
```

El instalador guarda copias de los archivos originales en `respaldo_codigo_mica_reservas_YYYYMMDD_HHMMSS` junto al proyecto. Si no encuentra los patrones esperados, detiene la instalación sin sobrescribir cambios locales.

### D. Verificar cambios SIN escribir en base

```powershell
Remove-Item Env:\MAYA_DB_PASSWORD -ErrorAction SilentlyContinue
python manage.py check
python manage.py migrate --plan
```

Se espera `mica.0003_reservainsumomica`. Detenerse y enviar el plan antes de migrar si hay operaciones no previstas.

### E. Aplicar migración (solo tras revisar el plan)

```powershell
python manage.py migrate
python manage.py showmigrations mica
python -m scripts.prever_reservas_mica
```

### F. Pruebas locales

```powershell
python manage.py test mica.tests.test_motor mica.tests.test_publico mica.tests.test_reservas
```

El test requiere el entorno de dependencias instalado en `.venv`. Verificar en navegador el formulario MICA y las solicitudes públicas **sin aprobar un pedido real hasta verificar el plan**.

## Seguridad

- No compartir archivos `.env` ni claves API.
- No volver a ejecutar el SQL inicial `01_INSTALACION_SOLO_BD_NUEVA.sql`.
- No utilizar `--aplicar` para la carga de stock durante estas pruebas.
- La tabla de reservas es nueva. No tiene `DROP`, ni cambia tablas de inventario.
- Evita activar esta nueva lógica con pedidos reales antes de la revisión y pruebas end-to-end en la base de ensayo.

## Advertencias

- La reserva no equivale a un movimiento de inventario ni cambia la existencia física.
- Hasta la siguiente etapa, no descuenta ingredientes ni crea movimientos de consumo.
- La simulación refleja stock físico menos reservas, pero no sustituye un sistema completo de lotes, vencimientos y control de cadena de frío.
- La cotización sigue siendo de una preparación por alternativa, no un menú compuesto completo.
