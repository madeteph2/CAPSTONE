# Modelo relacional de Banquetería Maya
Esquema de negocio PostgreSQL de referencia. PK = clave primaria, FK = clave foránea. La nulabilidad y las reglas por columna se detallan en el diccionario.

## region
Atributos: id_region, nombre_region.
PK: id_region.

## pais
Atributos: id_pais, nombre_pais, codigo_iso3.
PK: id_pais.

## comuna
Atributos: id_comuna, nombre_comuna, id_region.
PK: id_comuna.
- FK id_region → region.id_region (obligatoria)
- UNIQUE (nombre_comuna, id_region)

## unidad
Atributos: id_unidad, nombre_unidad.
PK: id_unidad.

## parametro
Atributos: id_parametro, nombre_parametro, valor_numerico, valor_texto, descripcion, estado.
PK: id_parametro.

## estado_pedido
Atributos: id_estado_pedido, nombre_estado, descripcion, orden.
PK: id_estado_pedido.

## rol
Atributos: id_rol, nombre_rol, descripcion, estado, created_at, updated_at.
PK: id_rol.

## permiso
Atributos: id_permiso, nombre_permiso, modulo, descripcion, estado.
PK: id_permiso.

## rol_permiso
Atributos: id_rol, id_permiso.
PK: id_rol, id_permiso.
- FK id_rol → rol.id_rol (obligatoria)
- FK id_permiso → permiso.id_permiso (obligatoria)
- PRIMARY KEY (id_rol, id_permiso)

## usuario
Atributos: id_usuario, nombre, apellido, email, password_hash, telefono, estado, ultimo_acceso, id_rol, created_at, updated_at.
PK: id_usuario.
- FK id_rol → rol.id_rol (obligatoria)

## representante_legal
Atributos: id_representante_legal, rut, nombre, apellido, email, telefono, estado.
PK: id_representante_legal.

## cliente
Atributos: id_cliente, rut, tipo_cliente, nombre, apellido, nombre_fantasia, giro, email, telefono, direccion, id_comuna, id_pais, id_representante_legal, estado, created_at, updated_at.
PK: id_cliente.
- FK id_comuna → comuna.id_comuna (opcional)
- FK id_pais → pais.id_pais (opcional)
- FK id_representante_legal → representante_legal.id_representante_legal (opcional)

## evento
Atributos: id_evento, nombre_evento, fecha_evento, hora_evento, direccion, cantidad_personas, observaciones, estado, id_cliente, created_at, updated_at.
PK: id_evento.
- FK id_cliente → cliente.id_cliente (obligatoria)

## pedido
Atributos: id_pedido, numero_pedido, fecha_creacion, fecha_compromiso, fecha_entrega, observaciones, costo_estimado, margen_objetivo, precio_estimado, id_cliente, id_evento, id_estado_pedido, id_usuario_responsable, created_at, updated_at.
PK: id_pedido.
- FK id_cliente → cliente.id_cliente (obligatoria)
- FK id_evento → evento.id_evento (opcional)
- FK id_estado_pedido → estado_pedido.id_estado_pedido (obligatoria)
- FK id_usuario_responsable → usuario.id_usuario (opcional)

## historial_pedido
Atributos: id_historial_pedido, id_pedido, id_estado_anterior, id_estado_nuevo, observacion, id_usuario, fecha_cambio.
PK: id_historial_pedido.
- FK id_pedido → pedido.id_pedido (obligatoria)
- FK id_estado_anterior → estado_pedido.id_estado_pedido (opcional)
- FK id_estado_nuevo → estado_pedido.id_estado_pedido (obligatoria)
- FK id_usuario → usuario.id_usuario (opcional)

## proveedor
Atributos: id_proveedor, nombre_proveedor, rut, nombre_contacto, email, telefono, direccion, id_comuna, id_pais, estado, created_at, updated_at.
PK: id_proveedor.
- FK id_comuna → comuna.id_comuna (opcional)
- FK id_pais → pais.id_pais (opcional)

## insumo
Atributos: id_insumo, nombre_insumo, descripcion, categoria, id_unidad, costo_unitario, stock_minimo, codigo_qr, id_proveedor, estado, created_at, updated_at.
PK: id_insumo.
- FK id_unidad → unidad.id_unidad (obligatoria)
- FK id_proveedor → proveedor.id_proveedor (opcional)

## ficha_tecnica
Atributos: id_ficha_tecnica, nombre_ficha, descripcion, tipo_preparacion, rendimiento, id_unidad_rendimiento, costo_total, precio_sugerido, margen_objetivo, imagen_url, estado, created_at, updated_at.
PK: id_ficha_tecnica.
- FK id_unidad_rendimiento → unidad.id_unidad (opcional)

## receta
Atributos: id_receta, id_ficha_tecnica, id_insumo, cantidad, id_unidad, costo_unitario, costo_total, observacion.
PK: id_receta.
- FK id_ficha_tecnica → ficha_tecnica.id_ficha_tecnica (obligatoria)
- FK id_insumo → insumo.id_insumo (obligatoria)
- FK id_unidad → unidad.id_unidad (obligatoria)
- UNIQUE (id_ficha_tecnica, id_insumo)

## detalle_preparacion
Atributos: id_detalle_preparacion, id_ficha_tecnica, orden, instruccion.
PK: id_detalle_preparacion.
- FK id_ficha_tecnica → ficha_tecnica.id_ficha_tecnica (obligatoria)

## detalle_pedido
Atributos: id_detalle_pedido, id_pedido, tipo_detalle, id_ficha_tecnica, id_insumo, descripcion_manual, cantidad, costo_unitario, precio_unitario, subtotal.
PK: id_detalle_pedido.
- FK id_pedido → pedido.id_pedido (obligatoria)
- FK id_ficha_tecnica → ficha_tecnica.id_ficha_tecnica (opcional)
- FK id_insumo → insumo.id_insumo (opcional)
- CHECK ( id_ficha_tecnica IS NOT NULL OR id_insumo IS NOT NULL OR descripcion_manual IS NOT NULL )

## cotizacion
Atributos: id_cotizacion, id_pedido, fecha_cotizacion, costo_insumos, costo_personal, costo_transporte, otros_costos, costo_total, margen_objetivo, precio_sugerido, estado, observacion, id_usuario.
PK: id_cotizacion.
- FK id_pedido → pedido.id_pedido (obligatoria)
- FK id_usuario → usuario.id_usuario (opcional)

## bodega
Atributos: id_bodega, nombre_bodega, direccion, tipo_bodega, estado.
PK: id_bodega.

## inventario
Atributos: id_inventario, id_insumo, id_bodega, stock_actual, stock_minimo, ubicacion, estado.
PK: id_inventario.
- FK id_insumo → insumo.id_insumo (obligatoria)
- FK id_bodega → bodega.id_bodega (obligatoria)
- UNIQUE (id_insumo, id_bodega)

## movimiento_inventario
Atributos: id_movimiento, tipo_movimiento, fecha_movimiento, cantidad, costo_unitario, observacion, id_insumo, id_bodega, id_pedido, id_usuario.
PK: id_movimiento.
- FK id_insumo → insumo.id_insumo (obligatoria)
- FK id_bodega → bodega.id_bodega (obligatoria)
- FK id_pedido → pedido.id_pedido (opcional)
- FK id_usuario → usuario.id_usuario (opcional)

## venta
Atributos: id_venta, id_pedido, fecha_venta, total, estado, observacion.
PK: id_venta.
- FK id_pedido → pedido.id_pedido (obligatoria)

## factura
Atributos: id_factura, id_venta, numero_factura, fecha_emision, monto_total, estado, observacion.
PK: id_factura.
- FK id_venta → venta.id_venta (obligatoria)

## pago
Atributos: id_pago, id_factura, fecha_pago, monto, metodo_pago, estado, observacion.
PK: id_pago.
- FK id_factura → factura.id_factura (obligatoria)

## checklist_montaje
Atributos: id_checklist, id_pedido, item, estado, observaciones, id_usuario, fecha_actualizacion.
PK: id_checklist.
- FK id_pedido → pedido.id_pedido (obligatoria)
- FK id_usuario → usuario.id_usuario (opcional)

## incidencia
Atributos: id_incidencia, id_pedido, id_usuario, descripcion, foto_url, estado, fecha.
PK: id_incidencia.
- FK id_pedido → pedido.id_pedido (obligatoria)
- FK id_usuario → usuario.id_usuario (opcional)

## auditoria
Atributos: id_auditoria, id_usuario, modulo, accion, tabla_afectada, id_registro_afectado, descripcion, fecha_hora, ip_origen.
PK: id_auditoria.
- FK id_usuario → usuario.id_usuario (opcional)