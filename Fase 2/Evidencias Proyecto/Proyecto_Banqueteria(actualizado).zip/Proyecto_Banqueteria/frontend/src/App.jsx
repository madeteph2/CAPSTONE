import { useCallback, useEffect, useMemo, useState } from "react";
import "./App.css";

const MENU = [
  ["Dashboard", "▦"], ["Clientes", "♙"], ["Eventos", "▣"],
  ["Pedidos", "▤"], ["Fichas técnicas", "▧"], ["Inventario", "◫"],
  ["Cotizador", "▥"], ["Ventas / Facturación", "▥"],
  ["Usuarios / Roles", "♙"], ["Incidencias", "⚑"],
];

function normalizarLista(data) {
  if (Array.isArray(data)) return { items: data, total: data.length };
  if (data && Array.isArray(data.results))
    return { items: data.results, total: Number.isFinite(data.count) ? data.count : data.results.length };
  throw new Error("La API devolvió un formato inesperado.");
}

function fechaLegible(fecha) {
  if (!fecha) return "Sin fecha";
  const partes = fecha.slice(0, 10).split("-");
  return partes.length === 3 ? `${partes[2]}/${partes[1]}/${partes[0]}` : fecha;
}

const formularioVacio = {
  nombre: "", apellido: "", nombre_fantasia: "", rut: "", email: "",
  telefono: "", direccion: "", tipo_cliente: "persona_natural",
  giro: "", estado: "activo", observaciones: ""
};

function ClienteFormulario({ inicial, modo, onCancelar, onGuardado, csrfToken }) {
  const [guardando, setGuardando] = useState(false);
  const [mensaje, setMensaje] = useState("");
  const [form, setForm] = useState(() => inicial ? {
    ...formularioVacio,
    ...Object.fromEntries(Object.keys(formularioVacio).map(k => [k, inicial[k] ?? ""])),
    observaciones: ""
  } : formularioVacio);
  const [errores, setErrores] = useState({});
  const [validado, setValidado] = useState(false);
  const cambiar = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value, ...(name === "tipo_cliente" && value === "empresa" ? { apellido: "" } : {}) }));
    setValidado(false);
    setErrores(prev => ({ ...prev, [name]: "" }));
  };
  const validar = async (e) => {
    e.preventDefault();
    const err = {};
    if (!form.nombre.trim()) err.nombre = form.tipo_cliente === "empresa" ? "Ingrese la razón social." : "Ingrese el nombre.";
    if (form.tipo_cliente === "persona_natural" && !form.apellido.trim()) err.apellido = "Ingrese los apellidos.";
    if (!form.rut.trim()) err.rut = "Ingrese el RUT.";
    else if (!/^[0-9.]+-[0-9kK]$/.test(form.rut.trim())) err.rut = "Formato esperado: 12.345.678-9.";
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) err.email = "Ingrese un correo válido.";
    if (!form.telefono.trim()) err.telefono = "Ingrese un teléfono.";
    if (!form.direccion.trim()) err.direccion = "Ingrese una dirección.";
    setErrores(err);
    if (Object.keys(err).length) { setValidado(false); return; }
    const datos = Object.fromEntries(Object.entries(form).filter(([k]) => k !== "observaciones"));
    const url = modo === "editar" ? `/api/clientes/${inicial.id_cliente}/` : "/api/clientes/";
    try {
      setGuardando(true); setMensaje("");
      const res = await fetch(url, {
        method: modo === "editar" ? "PATCH" : "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json", "X-CSRFToken": csrfToken },
        body: JSON.stringify(datos),
      });
      const respuesta = await res.json();
      if (!res.ok) {
        setErrores(respuesta.errors || {});
        setMensaje(respuesta.detail || "No fue posible guardar el cliente.");
        return;
      }
      setValidado(true);
      await onGuardado();
    } catch {
      setMensaje("Error de conexión. Comprueba Django y vuelve a intentar.");
    } finally { setGuardando(false); }
  };
  const campo = (nombre, titulo, placeholder, requerido = false, tipo = "text") => (
    <label className="w04-field" key={nombre}>
      <span>{titulo} {requerido && <b className="w04-required">*</b>}</span>
      <input type={tipo} name={nombre} value={form[nombre]} onChange={cambiar}
        placeholder={placeholder} aria-invalid={Boolean(errores[nombre])}
        maxLength={nombre === "rut" ? 20 : nombre === "telefono" ? 30 : 150} />
      {errores[nombre] && <small className="w04-error">{errores[nombre]}</small>}
    </label>
  );
  return <>
    <div className="w04-header">
      <div className="w02-intro">
        <div className="w02-breadcrumb">Inicio / Clientes / {modo === "editar" ? "Editar cliente" : "Nuevo cliente"}</div>
        <h1>{modo === "editar" ? "Editar cliente" : "Nuevo cliente"}</h1>
        <p>W04 · Registro y actualización de la información de clientes.</p>
      </div>
      <span className="w04-badge">Guardado protegido · PostgreSQL</span>
    </div>
    <form onSubmit={validar} noValidate>
      <section className="w02-card w04-section">
        <h2>Información del cliente</h2>
        <div className="w04-grid">
          {campo("nombre", form.tipo_cliente === "empresa" ? "Razón social" : "Nombre", form.tipo_cliente === "empresa" ? "Ej. Eventos Maya SpA" : "Ej. María José", true)}
          {campo("rut", "RUT", "12.345.678-9", true)}
          {campo("email", "Correo electrónico", "cliente@correo.cl", true, "email")}
          {campo("telefono", "Teléfono", "+56 9 1234 5678", true, "tel")}
          {campo("direccion", "Dirección", "Calle, número, comuna, ciudad", true)}
          {form.tipo_cliente === "persona_natural" && campo("apellido", "Apellidos", "Ej. González Pérez", true)}
        </div>
      </section>
      <section className="w02-card w04-section">
        <h2>Información complementaria</h2>
        <div className="w04-grid">
          <label className="w04-field"><span>Tipo de cliente</span>
            <select name="tipo_cliente" value={form.tipo_cliente} onChange={cambiar}>
              <option value="persona_natural">Persona natural</option>
              <option value="empresa">Empresa</option>
            </select>
          </label>
          <label className="w04-field"><span>Estado</span>
            <select name="estado" value={form.estado} onChange={cambiar}>
              <option value="activo">Activo</option><option value="inactivo">Inactivo</option>
            </select>
            <small>Un cliente inactivo conserva su información histórica.</small>
          </label>
          {campo("nombre_fantasia", "Nombre de fantasía (opcional)", "Alias o nombre comercial")}
          {campo("giro", "Giro", "Actividad comercial")}
          <label className="w04-field w04-full"><span>Observaciones</span>
            <textarea name="observaciones" rows="4" value={form.observaciones}
              onChange={cambiar} placeholder="Información adicional relevante del cliente..." />
            <small>El esquema actual de cliente no contiene un campo observaciones. Este dato no se guardará.</small>
          </label>
        </div>
      </section>
      {mensaje && <div className="w02-message w02-error" role="alert">{mensaje}</div>}
      {validado && <div className="w04-success" role="status">Cliente guardado correctamente en PostgreSQL.</div>}
      <div className="w04-actions">
        <button type="button" className="w04-secondary" onClick={onCancelar}>Cancelar / Volver a clientes</button>
        <button type="submit" className="w03-primary" disabled={guardando}>{guardando ? "Guardando…" : modo === "editar" ? "Guardar cambios" : "Crear cliente"}</button>
      </div>
    </form>
  </>;
}



// W05: importes expresados en pesos chilenos, sin centavos.
// El punto es separador de miles; nunca se envía al backend.
const normalizarCLP = (valor) => {
  const texto = String(valor ?? "").trim().replace(/[$\s]/g, "");
  if (!texto || !/^[0-9.]+$/.test(texto)) return null;
  if (texto.includes(".") && !/^\d{1,3}(?:\.\d{3})+$/.test(texto)) return null;
  const entero = texto.replace(/\./g, "");
  return /^\d+$/.test(entero) ? entero.replace(/^0+(?=\d)/, "") : null;
};

const formatearCLP = (valor) => {
  const entero = normalizarCLP(valor);
  return entero === null ? String(valor ?? "") : `$${entero.replace(/\B(?=(\d{3})+(?!\d))/g, ".")}`;
};

// Django devuelve decimales como "120000.00"; se convierten para edición CLP.
const clpDesdeAPI = (valor) => {
  if (valor === null || valor === undefined || valor === "") return "";
  const texto = String(valor);
  const match = texto.match(/^(\d+)(?:\.(\d{1,2}))?$/);
  if (!match) return texto;
  if (match[2] && Number(match[2]) !== 0) return texto;
  return formatearCLP(match[1]);
};

const normalizarPorcentaje = (valor) => {
  const texto = String(valor ?? "").trim().replace(/,/g, ".");
  if (!/^\d+(?:\.\d{1,2})?$/.test(texto)) return null;
  const numero = Number(texto);
  return Number.isFinite(numero) ? numero.toFixed(2) : null;
};

const pedidoInicial = {
  numero_pedido: "", id_cliente: "", id_evento: "", id_estado_pedido: "",
  id_usuario_responsable: "", fecha_compromiso: "", fecha_entrega: "",
  costo_estimado: "", margen_objetivo: "", precio_estimado: "", observaciones: ""
};

function PedidoFormulario({ inicial, clientes, pedidos, csrfToken, onCancelar, onGuardado }) {
  const editando = Boolean(inicial);
  const [form, setForm] = useState(() => ({ ...pedidoInicial, ...(inicial || {}),
    fecha_compromiso: inicial?.fecha_compromiso?.slice(0, 10) || "",
    fecha_entrega: inicial?.fecha_entrega?.slice(0, 10) || "",
    id_cliente: String(inicial?.id_cliente ?? ""),
    id_evento: String(inicial?.id_evento ?? ""),
    id_estado_pedido: String(inicial?.id_estado_pedido ?? ""),
    id_usuario_responsable: String(inicial?.id_usuario_responsable ?? ""),
    costo_estimado: clpDesdeAPI(inicial?.costo_estimado),
    precio_estimado: clpDesdeAPI(inicial?.precio_estimado),
    margen_objetivo: inicial?.margen_objetivo == null ? "" : String(inicial.margen_objetivo).replace(".", ",")
  }));
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState("");
  const [errores, setErrores] = useState({});
  const [eventos, setEventos] = useState([]);
  const [nuevo, setNuevo] = useState(false);
  const [clientesEvento, setClientesEvento] = useState([]);
  const [guardandoEvento, setGuardandoEvento] = useState(false);
  const [errorFormulario, setErrorFormulario] = useState("");
  const [erroresFormulario, setErroresFormulario] = useState({});
  const [exitoEvento, setExitoEvento] = useState("");
  const [formEvento, setFormEvento] = useState({ id_cliente:"", nombre_evento:"", fecha_evento:"", hora_evento:"", direccion:"", cantidad_personas:"", estado:"planificado", observaciones:"" });
  const cambiarEvento = e => { const {name,value} = e.target; setFormEvento(prev => ({...prev,[name]:value})); setErroresFormulario(prev => ({...prev,[name]:""})); };
  const abrirNuevo = async () => {
    setErrorFormulario(""); setErroresFormulario({}); setExitoEvento("");
    try {
      const r = await fetch("/api/clientes/", { credentials:"same-origin" });
      if (!r.ok) throw new Error("No se pudo cargar la lista de clientes.");
      const d = await r.json();
      const lista = Array.isArray(d) ? d : (d.results || d.clientes || []);
      if (!Array.isArray(lista)) throw new Error("Formato de clientes inesperado.");
      setClientesEvento(lista); setNuevo(true); setDetalle(null);
    } catch(e) { setError(e.message); }
  };
  const guardarEvento = async e => {
    e.preventDefault(); setErrorFormulario(""); setErroresFormulario({});
    if (!formEvento.id_cliente || !formEvento.nombre_evento.trim() || !formEvento.fecha_evento || !formEvento.direccion.trim()) {
      setErrorFormulario("Complete cliente, nombre, fecha y dirección."); return;
    }
    setGuardandoEvento(true);
    try {
      const r = await fetch("/api/eventos/", { method:"POST", credentials:"same-origin", headers:{"Content-Type":"application/json","X-CSRFToken":csrfToken}, body:JSON.stringify({...formEvento, cantidad_personas: formEvento.cantidad_personas === "" ? null : Number(formEvento.cantidad_personas)}) });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) { setErroresFormulario(d.errors || {}); throw new Error(d.detail || `Error HTTP ${r.status}`); }
      setNuevo(false); setFormEvento({ id_cliente:"", nombre_evento:"", fecha_evento:"", hora_evento:"", direccion:"", cantidad_personas:"", estado:"planificado", observaciones:"" });
      setBusqueda(""); setEstado("todos"); setExitoEvento(`Evento ${d.nombre_evento} registrado correctamente.`);
      await cargar();
    } catch(e) { setErrorFormulario(e.message); }
    finally { setGuardandoEvento(false); }
  };

  const [responsables, setResponsables] = useState([]);
  const [avisoEventos, setAvisoEventos] = useState("");
  const [avisoResponsables, setAvisoResponsables] = useState("");

  useEffect(() => {
    let activo = true;
    const cargarOpciones = async (url, asignar, avisar) => {
      try {
        const res = await fetch(url, { credentials: "same-origin" });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const respuesta = await res.json();
        const datos = url === "/api/eventos/" && Array.isArray(respuesta?.eventos)
          ? { items: respuesta.eventos, total: respuesta.eventos.length }
          : normalizarLista(respuesta);
        if (activo) asignar(datos.items);
      } catch {
        if (activo) avisar("No se pudo cargar el catálogo desde Django.");
      }
    };
    cargarOpciones("/api/eventos/", setEventos, setAvisoEventos);
    cargarOpciones("/api/usuarios/", setResponsables, setAvisoResponsables);
    return () => { activo = false; };
  }, []);

  const eventosCliente = eventos.filter(e => String(e.id_cliente ?? e.id_cliente_id ?? "") === String(form.id_cliente));
  const opcionesEventos = [...eventosCliente];
  if (form.id_evento && !opcionesEventos.some(e => String(e.id_evento) === form.id_evento)) {
    opcionesEventos.unshift({ id_evento: form.id_evento, nombre_evento: inicial?.nombre_evento || `Evento #${form.id_evento} (no disponible en catálogo)` });
  }
  const opcionesResponsables = responsables.map(u => ({
    id: u.id_usuario,
    nombre: [u.nombre, u.apellido].filter(Boolean).join(" ") || u.email || `Usuario #${u.id_usuario}`,
  }));
  if (form.id_usuario_responsable && !opcionesResponsables.some(u => String(u.id) === form.id_usuario_responsable)) {
    opcionesResponsables.unshift({ id: form.id_usuario_responsable, nombre: inicial?.nombre_responsable || `Responsable #${form.id_usuario_responsable}` });
  }
  const estados = [...new Map(pedidos.filter(p => p.id_estado_pedido != null).map(p => [String(p.id_estado_pedido), p.nombre_estado || `Estado ${p.id_estado_pedido}`])).entries()];
  const cambiar = e => {
    const {name, value} = e.target;
    setForm(p => ({ ...p, [name]: value, ...(name === "id_cliente" ? { id_evento: "" } : {}) }));
    setErrores(p => ({ ...p, [name]: "" }));
  };
  const guardar = async e => {
    e.preventDefault(); setError(""); setErrores({});
    const err = {};
    if (!form.id_cliente) err.id_cliente = "Seleccione un cliente.";
    if (!form.id_estado_pedido) err.id_estado_pedido = "Seleccione un estado.";
    const costoCLP = normalizarCLP(form.costo_estimado);
    const precioCLP = normalizarCLP(form.precio_estimado);
    const margenNormalizado = normalizarPorcentaje(form.margen_objetivo);
    if (costoCLP === null) err.costo_estimado = "Ingrese pesos chilenos sin decimales (ej. 120.000).";
    if (precioCLP === null) err.precio_estimado = "Ingrese pesos chilenos sin decimales (ej. 150.000).";
    if (margenNormalizado === null) err.margen_objetivo = "Ingrese un porcentaje válido con hasta dos decimales (ej. 30,50).";
    if (form.fecha_compromiso && form.fecha_entrega && form.fecha_entrega < form.fecha_compromiso) err.fecha_entrega = "La entrega no puede ser anterior al compromiso.";
    if (Object.keys(err).length) { setErrores(err); return; }
    const datos = {
      id_cliente: Number(form.id_cliente),
      id_estado_pedido: Number(form.id_estado_pedido),
      id_evento: form.id_evento ? Number(form.id_evento) : null,
      id_usuario_responsable: form.id_usuario_responsable ? Number(form.id_usuario_responsable) : null,
      fecha_compromiso: form.fecha_compromiso || null,
      fecha_entrega: form.fecha_entrega || null,
      costo_estimado: costoCLP,
      margen_objetivo: margenNormalizado,
      precio_estimado: precioCLP,
      observaciones: form.observaciones || ""
    };
    try {
      setGuardando(true);
      const respuesta = await fetch(editando ? `/api/pedidos/${inicial.id_pedido}/` : "/api/pedidos/nuevo/", {
        method: editando ? "PATCH" : "POST", credentials: "same-origin",
        headers: {"Content-Type": "application/json", "X-CSRFToken": csrfToken},
        body: JSON.stringify(datos)
      });
      const resultado = await respuesta.json().catch(() => ({}));
      if (!respuesta.ok) {
        setError(resultado.detail || `No se pudo guardar (HTTP ${respuesta.status}).`);
        setErrores(resultado.errors || Object.fromEntries(Object.entries(resultado).filter(([k]) => k !== "detail")));
        return;
      }
      await onGuardado();
    } catch { setError("No fue posible contactar con Django. Revisa el servidor y el proxy de Vite."); }
    finally { setGuardando(false); }
  };
  const campo = (nombre, titulo, tipo = "text", obligatorio = false) => <label className="w04-field" key={nombre}>
    <span>{titulo}{obligatorio && <b className="w04-required"> *</b>}</span>
    <input name={nombre} type={tipo} value={form[nombre] ?? ""} onChange={cambiar} required={obligatorio} step={tipo === "number" ? "0.01" : undefined} min={tipo === "number" ? "0" : undefined} />
    {errores[nombre] && <small className="w04-error">{String(errores[nombre])}</small>}
  </label>;
  const campoCLP = (nombre, titulo) => <label className="w04-field" key={nombre}>
    <span>{titulo} (CLP)<b className="w04-required"> *</b></span>
    <input
      name={nombre} type="text" inputMode="numeric" autoComplete="off"
      value={form[nombre] ?? ""} placeholder="$120.000"
      onChange={e => {
        const valor = e.target.value;
        if (!/^[\d.$\s]*$/.test(valor)) return;
        setForm(p => ({ ...p, [nombre]: valor }));
        setErrores(p => ({ ...p, [nombre]: "" }));
      }}
      onBlur={() => setForm(p => ({ ...p, [nombre]: normalizarCLP(p[nombre]) === null ? p[nombre] : formatearCLP(p[nombre]) }))}
      required aria-invalid={Boolean(errores[nombre])}
    />
    {errores[nombre] && <small className="w04-error">{String(errores[nombre])}</small>}
  </label>;
  return <>
    <div className="w03-heading w05-heading"><div className="w02-intro"><div className="w02-breadcrumb">Inicio / Pedidos / {editando ? "Editar" : "Nuevo"}</div><h1>{editando ? `Editar ${inicial.numero_pedido}` : "Nuevo pedido"}</h1><p>W05 · Registro de pedidos.</p></div></div>
    <form onSubmit={guardar} className="w05-formulario">
      <section className="w02-card w04-section"><h2>Información del pedido</h2><div className="w04-grid">
        <label className="w04-field">
          <span>Número de pedido</span>
          <input
            type="text"
            value={editando ? (inicial?.numero_pedido || "") : "Se generará automáticamente al guardar"}
            readOnly
            aria-label="Número de pedido generado automáticamente"
          />
          <small>{editando ? "El número de pedido no puede modificarse." : "Django asignará un número correlativo al crear el pedido."}</small>
        </label>
        <label className="w04-field"><span>Cliente <b className="w04-required">*</b></span><select name="id_cliente" value={form.id_cliente} onChange={cambiar}><option value="">Seleccione un cliente</option>{clientes.map(c => <option key={c.id_cliente} value={c.id_cliente}>{c.nombre} {c.tipo_cliente === "empresa" ? "" : (c.apellido || "")}</option>)}</select>{errores.id_cliente && <small className="w04-error">{String(errores.id_cliente)}</small>}</label>
        <label className="w04-field"><span>Estado <b className="w04-required">*</b></span><select name="id_estado_pedido" value={form.id_estado_pedido} onChange={cambiar}><option value="">Seleccione un estado</option>{estados.map(([id, nombre]) => <option key={id} value={id}>{nombre}</option>)}</select>{errores.id_estado_pedido && <small className="w04-error">{String(errores.id_estado_pedido)}</small>}<small>Se muestran los estados presentes en los pedidos cargados.</small></label>
        <label className="w04-field">
          <span>Evento (opcional)</span>
          <select name="id_evento" value={form.id_evento} onChange={cambiar} disabled={!form.id_cliente}>
            <option value="">Sin evento asignado</option>
            {opcionesEventos.map(e => <option key={e.id_evento} value={e.id_evento}>{e.nombre_evento || `Evento #${e.id_evento}`}</option>)}
          </select>
          {avisoEventos && <small>{avisoEventos} Puedes guardar sin evento.</small>}
          {!avisoEventos && form.id_cliente && !opcionesEventos.length && <small>No hay eventos disponibles para este cliente.</small>}
          {errores.id_evento && <small className="w04-error">{String(errores.id_evento)}</small>}
        </label>
        <label className="w04-field">
          <span>Responsable (opcional)</span>
          <select name="id_usuario_responsable" value={form.id_usuario_responsable} onChange={cambiar}>
            <option value="">Sin responsable asignado</option>
            {opcionesResponsables.map(u => <option key={u.id} value={u.id}>{u.nombre}</option>)}
          </select>
          {avisoResponsables && <small>{avisoResponsables} Puedes guardar sin responsable.</small>}
          {errores.id_usuario_responsable && <small className="w04-error">{String(errores.id_usuario_responsable)}</small>}
        </label>
        {campo("fecha_compromiso", "Fecha compromiso", "date")}
        {campo("fecha_entrega", "Fecha entrega", "date")}
      </div></section>
      <section className="w02-card w04-section"><h2>Valores y observaciones</h2><div className="w04-grid">
        {campoCLP("costo_estimado", "Costo estimado")}
        {campoCLP("precio_estimado", "Precio estimado")}
        <label className="w04-field">
          <span>Margen objetivo (%)<b className="w04-required"> *</b></span>
          <input name="margen_objetivo" type="text" inputMode="decimal" placeholder="30,00"
            value={form.margen_objetivo ?? ""} onChange={cambiar} required
            aria-invalid={Boolean(errores.margen_objetivo)} />
          {errores.margen_objetivo && <small className="w04-error">{String(errores.margen_objetivo)}</small>}
        </label>
        <label className="w04-field w04-full"><span>Observaciones</span><textarea name="observaciones" rows="4" value={form.observaciones || ""} onChange={cambiar}/></label>
      </div></section>
      {error && <div className="w02-message w02-error" role="alert">{error}</div>}
      <div className="w04-actions"><button className="w04-secondary" type="button" onClick={onCancelar}>Cancelar</button><button className="w03-primary" type="submit" disabled={guardando}>{guardando ? "Guardando…" : editando ? "Guardar cambios" : "Crear pedido"}</button></div>
    </form>
  </>;
}

function PedidosVista({ registros, total, cargando, error, onNuevo, onEditar, onDetalle }) {
  const [consulta, setConsulta] = useState("");
  const [estado, setEstado] = useState("todos");
  const [responsable, setResponsable] = useState("todos");
  const estados = useMemo(() => [...new Set(registros.map(p => p.nombre_estado).filter(Boolean))].sort(), [registros]);
  const responsables = useMemo(() => [...new Set(registros.map(p => p.nombre_responsable).filter(Boolean))].sort(), [registros]);
  const filtrados = useMemo(() => registros.filter(p => {
    const texto = [p.numero_pedido, p.nombre_cliente, p.nombre_evento, p.nombre_responsable]
      .filter(Boolean).join(" ").toLocaleLowerCase("es");
    return texto.includes(consulta.trim().toLocaleLowerCase("es")) &&
      (estado === "todos" || p.nombre_estado === estado) &&
      (responsable === "todos" || p.nombre_responsable === responsable);
  }), [registros, consulta, estado, responsable]);
  const formatoDinero = v => v == null || v === "" ? "—" : new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(Number(v));
  const etiquetaEstado = v => (v || "Sin estado").replaceAll("_", " ");
  const estiloEstado = v => {
    const t = (v || "").toLocaleLowerCase("es");
    if (t.includes("cancel")) return "cancelado";
    if (t.includes("confirm")) return "confirmado";
    if (t.includes("complet") || t.includes("finaliz")) return "completado";
    if (t.includes("prepar")) return "preparacion";
    return "pendiente";
  };
  return <>
    <div className="w03-heading w05-heading">
      <div className="w02-intro"><div className="w02-breadcrumb">Inicio / Pedidos</div>
        <h1>W05 - Pedidos</h1><p>Listado, búsqueda y seguimiento de pedidos.</p></div>
      <button className="w03-primary" type="button" onClick={onNuevo}>+ Nuevo pedido</button>
    </div>
    {error && <div className="w02-message w02-error" role="alert">{error}</div>}
    <section className="w02-card w05-filtros" aria-label="Filtros de pedidos">
      <label><span>Buscar pedido</span><input value={consulta} onChange={e => setConsulta(e.target.value)} placeholder="Pedido, cliente, evento o responsable…" /></label>
      <label><span>Estado</span><select value={estado} onChange={e => setEstado(e.target.value)}><option value="todos">Todos los estados</option>{estados.map(v => <option key={v} value={v}>{etiquetaEstado(v)}</option>)}</select></label>
      <label><span>Responsable</span><select value={responsable} onChange={e => setResponsable(e.target.value)}><option value="todos">Todos los responsables</option>{responsables.map(v => <option key={v} value={v}>{v}</option>)}</select></label>
    </section>
    <section className="w02-card w05-listado">
      <div className="w05-listado-cabecera"><h2>Lista de pedidos ({filtrados.length})</h2><span>Datos reales · PostgreSQL</span></div>
      <div className="w02-table-scroll w05-table-scroll"><table className="w05-table"><colgroup><col className="w05-col-id"/><col className="w05-col-cliente"/><col className="w05-col-fecha"/><col className="w05-col-responsable"/><col className="w05-col-estado"/><col className="w05-col-acciones"/></colgroup><thead><tr><th scope="col">ID</th><th scope="col">Cliente / Evento</th><th scope="col">Fecha evento</th><th scope="col">Responsable</th><th scope="col">Estado</th><th scope="col">Acciones</th></tr></thead>
        <tbody>{filtrados.map(p => <tr key={p.id_pedido}>
          <td><strong>{p.numero_pedido || `#${p.id_pedido}`}</strong></td>
          <td><strong>{p.nombre_cliente || "Cliente no disponible"}</strong><small className="w05-evento">{p.nombre_evento || "Evento no disponible"}</small></td>
          <td>{fechaLegible(p.fecha_entrega || p.fecha_compromiso)}</td>
          <td>{p.nombre_responsable || "—"}</td>
          <td><span className={`w05-estado ${estiloEstado(p.nombre_estado)}`}>{etiquetaEstado(p.nombre_estado)}</span></td>
          <td><div className="w05-table-actions"><button className="w05-icon-button" type="button" onClick={() => onDetalle(p)} aria-label={`Consultar ${p.numero_pedido || p.id_pedido}`} title="Consultar pedido"><svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg></button><button className="w05-icon-button" type="button" onClick={() => onEditar(p)} aria-label={`Editar ${p.numero_pedido || p.id_pedido}`} title="Editar pedido"><svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="m16 4 4 4L9 19l-5 1 1-5L16 4Z"/></svg></button></div></td>
        </tr>)}
        {cargando && <tr><td colSpan="6">Cargando pedidos…</td></tr>}
        {!cargando && !error && filtrados.length === 0 && <tr><td colSpan="6">No se encontraron pedidos.</td></tr>}
        </tbody></table></div>
      {total != null && total > registros.length && <p className="w02-note">Mostrando {registros.length} de {total} pedidos. La búsqueda y los filtros abarcan solo los registros recibidos; falta paginación.</p>}
      <p className="w02-note">Creación y edición protegidas mediante sesión Django.</p>
    </section>
  </>;
}


// W06: detalle del pedido seleccionado. No presenta datos de demostración.
function PedidoDetalle({ pedidoInicial, onVolver, onEditar }) {
  const [pedido, setPedido] = useState(pedidoInicial);
  const [evento, setEvento] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");
  const [avisoEvento, setAvisoEvento] = useState("");
  const [historial, setHistorial] = useState([]);
  const [cargandoHistorial, setCargandoHistorial] = useState(true);
  const [errorHistorial, setErrorHistorial] = useState("");

  // W06: historial real del pedido, independiente de la consulta de detalle.
  useEffect(() => {
    const controller = new AbortController();
    async function cargarHistorial() {
      setHistorial([]);
      setCargandoHistorial(true);
      setErrorHistorial("");
      try {
        const respuesta = await fetch(`/api/pedidos/${pedidoInicial.id_pedido}/historial/`, {
          credentials: "same-origin",
          signal: controller.signal,
        });
        if (!respuesta.ok) throw new Error(`No se pudo consultar el historial (HTTP ${respuesta.status}).`);
        const datos = normalizarLista(await respuesta.json());
        if (!controller.signal.aborted) setHistorial(datos.items);
      } catch (e) {
        if (e.name !== "AbortError" && !controller.signal.aborted)
          setErrorHistorial(e.message || "No se pudo cargar el historial.");
      } finally {
        if (!controller.signal.aborted) setCargandoHistorial(false);
      }
    }
    cargarHistorial();
    return () => controller.abort();
  }, [pedidoInicial.id_pedido]);

  useEffect(() => {
    const controller = new AbortController();
    async function cargarDetalle() {
      setCargando(true);
      setError("");
      setAvisoEvento("");
      setEvento(null);
      try {
        const respuesta = await fetch(`/api/pedidos/${pedidoInicial.id_pedido}/`, {
          credentials: "same-origin", signal: controller.signal
        });
        if (!respuesta.ok) throw new Error(`No se pudo consultar el pedido (HTTP ${respuesta.status}).`);
        const datos = await respuesta.json();
        if (controller.signal.aborted) return;
        setPedido({
          ...pedidoInicial,
          ...datos,
        });
        if (datos.id_evento != null) {
          try {
            const resEvento = await fetch(`/api/eventos/${datos.id_evento}/`, {
              credentials: "same-origin", signal: controller.signal
            });
            if (!resEvento.ok) throw new Error(`HTTP ${resEvento.status}`);
            const detalleEvento = await resEvento.json();
            if (!controller.signal.aborted) setEvento(detalleEvento);
          } catch (e) {
            if (e.name !== "AbortError" && !controller.signal.aborted)
              setAvisoEvento("No fue posible cargar la información complementaria del evento.");
          }
        }
      } catch (e) {
        if (e.name !== "AbortError" && !controller.signal.aborted) setError(e.message);
      } finally {
        if (!controller.signal.aborted) setCargando(false);
      }
    }
    cargarDetalle();
    return () => controller.abort();
  }, [pedidoInicial.id_pedido]);

  const dinero = valor => valor === null || valor === undefined || valor === ""
    ? "—" : new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(Number(valor));
  const valor = dato => dato === null || dato === undefined || dato === "" ? "—" : dato;
  const fecha = dato => dato ? fechaLegible(dato) : "—";
  const nombreEstado = pedido.nombre_estado || "Estado no disponible";
  const nombreEvento = evento?.nombre_evento || pedido.nombre_evento || "Sin evento asociado";
  const fechaHoraHistorial = dato => {
    if (!dato) return "Fecha no disponible";
    const fechaObjeto = new Date(dato);
    return Number.isNaN(fechaObjeto.getTime()) ? String(dato) : new Intl.DateTimeFormat("es-CL", {
      day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit",
    }).format(fechaObjeto);
  };
  const detalle = (etiqueta, dato) => <div key={etiqueta} style={{ minWidth: 0 }}>
    <dt style={{ fontSize: 13, color: "#667085", marginBottom: 5 }}>{etiqueta}</dt>
    <dd style={{ margin: 0, overflowWrap: "anywhere" }}>{valor(dato)}</dd>
  </div>;
  const tarjeta = (titulo, contenido) => <section className="w02-card" style={{ padding: 22, marginBottom: 16 }}>
    <h2 style={{ fontSize: 17, color: "#542711", margin: "0 0 18px", paddingBottom: 12, borderBottom: "1px solid #eadfd5" }}>{titulo}</h2>
    {contenido}
  </section>;
  const cuadricula = { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: "20px 24px" };

  return <div className="w06-detalle">
    <div className="w03-heading w05-heading">
      <div className="w02-intro">
        <div className="w02-breadcrumb">Inicio / Pedidos / {valor(pedido.numero_pedido)}</div>
        <h1>W06 - Detalle de Pedido</h1>
        <p>Información y seguimiento del pedido seleccionado.</p>
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
        <button type="button" className="w04-secondary" onClick={onVolver}>← Volver a pedidos</button>
        <button type="button" className="w03-primary" onClick={() => onEditar(pedido)} disabled={cargando || Boolean(error)}>Editar pedido</button>
      </div>
    </div>
    {cargando && <p role="status">Consultando información del pedido…</p>}
    {error && <div className="w02-message w02-error" role="alert">{error} No se mostrarán datos como si estuvieran actualizados.</div>}
    {!error && !cargando && <>
      {tarjeta("Pedido", <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", alignItems: "center", gap: 12 }}>
        <strong style={{ fontSize: 21 }}>{valor(pedido.numero_pedido)} — {nombreEvento}</strong>
        <span className="w05-estado pendiente">{nombreEstado}</span>
      </div>)}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 380px), 1fr))", gap: 16, alignItems: "start" }}>
        <div>
          {tarjeta("Información general", <dl style={cuadricula}>
            {detalle("Cliente", pedido.nombre_cliente)}
            {detalle("Responsable", pedido.nombre_responsable)}
            {detalle("Evento", nombreEvento)}
            {detalle("Fecha del evento", fecha(evento?.fecha_evento))}
            {detalle("Hora del evento", evento?.hora_evento)}
            {detalle("Cantidad de personas", evento?.cantidad_personas)}
            {detalle("Lugar", evento?.direccion)}
            {detalle("Fecha compromiso", fecha(pedido.fecha_compromiso))}
            {detalle("Fecha entrega", fecha(pedido.fecha_entrega))}
            {detalle("Observaciones", pedido.observaciones)}
          </dl>)}
          {avisoEvento && <p className="w02-note" role="status">{avisoEvento}</p>}
          {tarjeta("Costos del pedido", <dl style={cuadricula}>
            {detalle("Costo estimado", dinero(pedido.costo_estimado))}
            {detalle("Precio estimado", dinero(pedido.precio_estimado))}
            {detalle("Margen objetivo (%)", pedido.margen_objetivo)}
          </dl>)}
          {tarjeta("Checklist de montaje", <p className="w02-note">Pendiente de integrar un endpoint de checklist. No se muestran actividades ficticias.</p>)}
          {tarjeta("Incidencias", <p className="w02-note">Pendiente de integrar las incidencias asociadas al pedido.</p>)}
        </div>
        <div>
          {tarjeta("Estado del pedido", <>
            <p>Estado actual: <strong>{nombreEstado}</strong></p>
            <p className="w02-note">La modificación de estado se realiza por ahora desde «Editar pedido» (W05). Las transiciones y su auditoría se implementarán en una siguiente etapa.</p>
            <button type="button" className="w03-primary" onClick={() => onEditar(pedido)}>Editar estado en W05</button>
          </>)}
          {tarjeta("Historial del pedido", <>
            {cargandoHistorial && <p className="w02-note" role="status">Cargando historial real…</p>}
            {errorHistorial && <div className="w02-message w02-error" role="alert">{errorHistorial}</div>}
            {!cargandoHistorial && !errorHistorial && historial.length === 0 &&
              <p className="w02-note">Este pedido aún no registra cambios.</p>}
            {!cargandoHistorial && !errorHistorial && historial.length > 0 &&
              <ol style={{ listStyle: "none", margin: 0, padding: 0 }}>
                {[...historial].sort((a, b) => {
                  const diferencia = new Date(b.fecha_cambio || 0).getTime() - new Date(a.fecha_cambio || 0).getTime();
                  return diferencia || Number(b.id_historial_pedido || 0) - Number(a.id_historial_pedido || 0);
                }).map((registro, indice) => <li key={registro.id_historial_pedido ?? indice}
                  style={{ borderBottom: indice < historial.length - 1 ? "1px solid #eadfd5" : "none", padding: "12px 0" }}>
                  <strong style={{ display: "block", marginBottom: 6 }}>
                    {registro.estado_anterior || "Sin estado anterior"} → {registro.estado_nuevo || "Estado no disponible"}
                  </strong>
                  <div style={{ color: "#667085", fontSize: 13, marginBottom: 6 }}>
                    {fechaHoraHistorial(registro.fecha_cambio)} · {registro.usuario || "Usuario no disponible"}
                  </div>
                  {registro.observacion && <p style={{ margin: 0, overflowWrap: "anywhere" }}>{registro.observacion}</p>}
                </li>)}
              </ol>}
          </>)}
        </div>
      </div>
    </>}
  </div>;
}

// W08: listado, creación y edición mediante la API Django.
const fichaInicial = {
  nombre_ficha: "", descripcion: "", tipo_preparacion: "", rendimiento: "1",
  id_unidad_rendimiento: "", costo_total: "0", precio_sugerido: "0",
  margen_objetivo: "0", imagen_url: "", estado: "activo", procedimiento: "",
};

// Acepta 120000, 120.000, 120000,50 y 120,50 (formato chileno).
function decimalApi(valor) {
  const texto = String(valor ?? "").trim().replace(/\s/g, "");
  if (!texto) return "";
  const normalizado = texto.includes(",")
    ? texto.replace(/\./g, "").replace(",", ".")
    : /^\d{1,3}(\.\d{3})+$/.test(texto) ? texto.replace(/\./g, "") : texto;
  return /^\d+(\.\d+)?$/.test(normalizado) ? normalizado : null;
}

// Administración de ingredientes vinculados a una ficha técnica existente.
function IngredientesFicha({ fichaId, csrfToken, unidades, onResumen }) {
  const [insumos, setInsumos] = useState([]);
  const [recetas, setRecetas] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");
  const [aviso, setAviso] = useState("");
  const [guardando, setGuardando] = useState(false);
  const vacio = { id_insumo: "", cantidad: "", id_unidad: "", costo_unitario: "", costo_total: "", observacion: "" };
  const [dato, setDato] = useState(vacio);
  const [editandoId, setEditandoId] = useState(null);
  const endpoint = `/api/fichas-tecnicas/${fichaId}/recetas/`;
  const costoIngredientes = recetas.reduce((s, r) => s + Number(r.costo_total || 0), 0);
  useEffect(() => { onResumen?.(costoIngredientes, !cargando && !error); }, [costoIngredientes, cargando, error, onResumen]);
  const recargar = async (signal) => {
    const r = await fetch(endpoint, { credentials: "same-origin", signal });
    if (!r.ok) throw new Error(`No se pudieron consultar los ingredientes (HTTP ${r.status}).`);
    const json = await r.json();
    setRecetas(normalizarLista(json).items);
  };
  useEffect(() => {
    const controller = new AbortController();
    async function iniciar() {
      try {
        const [r] = await Promise.all([
          fetch("/api/insumos/", { credentials: "same-origin", signal: controller.signal }),
          recargar(controller.signal),
        ]);
        if (!r.ok) throw new Error(`No se pudieron cargar los insumos (HTTP ${r.status}).`);
        setInsumos(normalizarLista(await r.json()).items);
      } catch (e) { if (e.name !== "AbortError") setError(e.message); }
      finally { if (!controller.signal.aborted) setCargando(false); }
    }
    iniciar();
    return () => controller.abort();
  }, [fichaId]);
  const seleccionarInsumo = id => {
    const insumo = insumos.find(x => String(x.id_insumo) === id);
    setDato(prev => ({ ...prev, id_insumo: id,
      id_unidad: insumo ? String(insumo.id_unidad ?? "") : "",
      costo_unitario: insumo ? String(insumo.costo_unitario ?? "") : "",
      costo_total: "",
    }));
  };
  const numero = x => decimalApi(x);
  const calcular = () => {
    const cantidad = numero(dato.cantidad), costo = numero(dato.costo_unitario);
    if (!cantidad || !costo) return;
    const total = Number(cantidad) * Number(costo);
    if (!Number.isFinite(total)) return;
    setDato(prev => ({ ...prev, costo_total: total.toFixed(2) }));
  };
  const guardar = async e => {
    e.preventDefault(); setError(""); setAviso("");
    const cantidad = numero(dato.cantidad), costo = numero(dato.costo_unitario), total = numero(dato.costo_total);
    if (!dato.id_insumo || !dato.id_unidad || !cantidad || Number(cantidad) <= 0 ||
      costo === null || costo === "" || total === null || total === "" ||
      Number(costo) < 0 || Number(total) < 0 ||
      [cantidad, costo, total].some(x => x.split(".")[1]?.length > 2)) {
      setError("Complete insumo, unidad, cantidad y costos válidos (máximo 2 decimales)."); return;
    }
    const payload = { id_insumo: Number(dato.id_insumo), id_unidad: Number(dato.id_unidad),
      cantidad, costo_unitario: costo, costo_total: total, observacion: dato.observacion };
    setGuardando(true);
    try {
      const url = editandoId === null ? endpoint : `${endpoint}${editandoId}/`;
      const r = await fetch(url, { method: editandoId === null ? "POST" : "PATCH",
        credentials: "same-origin", headers: { "Content-Type": "application/json", "X-CSRFToken": csrfToken },
        body: JSON.stringify(payload) });
      const respuesta = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(Object.entries(respuesta).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(", ") : v}`).join(" · ") || `HTTP ${r.status}`);
      await recargar(); setDato(vacio); setEditandoId(null);
      setAviso("Ingrediente guardado correctamente.");
    } catch (e) { setError(e.message || "No se pudo guardar el ingrediente."); }
    finally { setGuardando(false); }
  };
  const editar = r => { setDato({ id_insumo: String(r.id_insumo ?? ""), cantidad: String(r.cantidad ?? ""),
    id_unidad: String(r.id_unidad ?? ""), costo_unitario: String(r.costo_unitario ?? ""),
    costo_total: String(r.costo_total ?? ""), observacion: r.observacion ?? "" });
    setEditandoId(r.id_receta); setError(""); setAviso(""); };
  const eliminar = async r => {
    if (!window.confirm("¿Eliminar este ingrediente de la receta?")) return;
    setError(""); setAviso("");
    try {
      const res = await fetch(`${endpoint}${r.id_receta}/`, { method: "DELETE",
        credentials: "same-origin", headers: { "X-CSRFToken": csrfToken } });
      if (!res.ok) throw new Error(`No se pudo eliminar (HTTP ${res.status}).`);
      await recargar(); setAviso("Ingrediente eliminado.");
      if (editandoId === r.id_receta) { setDato(vacio); setEditandoId(null); }
    } catch (e) { setError(e.message); }
  };
  const moneda = n => new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(Number(n || 0));
  const nombreUnidad = id => unidades.find(u => String(u.id_unidad) === String(id))?.nombre_unidad || `#${id}`;
  return <section className="w02-card" style={{ padding: 20, marginBottom: 16 }}>
    <h2>Ingredientes de la receta</h2>
    <p className="w02-note">Ingredientes asociados a esta ficha técnica. Los costos se registran en pesos chilenos (CLP).</p>
    {cargando ? <p>Cargando ingredientes…</p> : <>
      <div className="w02-table-scroll" style={{ overflowX: "auto", marginTop: 16 }}>
        <table className="w05-table" style={{ minWidth: 720, width: "100%" }}>
          <thead><tr><th>Insumo</th><th>Cantidad</th><th>Unidad</th><th>Costo unitario</th><th>Costo total</th><th>Acciones</th></tr></thead>
          <tbody>{recetas.map(r => <tr key={r.id_receta}>
            <td>{r.nombre_insumo || insumos.find(i => i.id_insumo === r.id_insumo)?.nombre_insumo || `#${r.id_insumo}`}</td>
            <td>{r.cantidad}</td><td>{r.nombre_unidad || nombreUnidad(r.id_unidad)}</td>
            <td>{moneda(r.costo_unitario)}</td><td>{moneda(r.costo_total)}</td>
            <td><button type="button" className="w04-secondary" onClick={() => editar(r)}>Editar</button>{" "}
              <button type="button" className="w04-secondary" onClick={() => eliminar(r)}>Quitar</button></td>
          </tr>)}{recetas.length === 0 && <tr><td colSpan="6">Esta ficha aún no tiene ingredientes registrados.</td></tr>}</tbody>
        </table>
      </div>
      <p className="w02-note">Total registrado de ingredientes: <strong>{moneda(costoIngredientes)}</strong>. No modifica automáticamente el costo total de la ficha.</p>
      <form onSubmit={guardar} style={{ marginTop: 20 }}>
        <h3>{editandoId === null ? "Agregar ingrediente" : `Editar ingrediente #${editandoId}`}</h3>
        <div className="w04-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16, marginTop: 12 }}>
          <label className="w04-field"><span>Insumo *</span><select required value={dato.id_insumo} onChange={e => seleccionarInsumo(e.target.value)}>
            <option value="">Seleccione un insumo</option>{insumos.map(i => <option key={i.id_insumo} value={i.id_insumo}>{i.nombre_insumo}</option>)}</select></label>
          <label className="w04-field"><span>Cantidad *</span><input required inputMode="decimal" value={dato.cantidad} onChange={e => setDato(p => ({ ...p, cantidad: e.target.value }))} placeholder="Ej.: 2,50" /></label>
          <label className="w04-field"><span>Unidad *</span><select required value={dato.id_unidad} onChange={e => setDato(p => ({ ...p, id_unidad: e.target.value }))}>
            <option value="">Seleccione una unidad</option>{unidades.map(u => <option key={u.id_unidad} value={u.id_unidad}>{u.nombre_unidad}</option>)}</select></label>
          <label className="w04-field"><span>Costo unitario (CLP) *</span><input required inputMode="decimal" value={dato.costo_unitario} onChange={e => setDato(p => ({ ...p, costo_unitario: e.target.value }))} /></label>
          <label className="w04-field"><span>Costo total (CLP) *</span><input required inputMode="decimal" value={dato.costo_total} onChange={e => setDato(p => ({ ...p, costo_total: e.target.value }))} /></label>
        </div>
        <p className="w02-note">El costo unitario se propone desde el catálogo. Verifica que corresponda a la unidad seleccionada; no se realizan conversiones automáticas.</p>
        <button type="button" className="w04-secondary" onClick={calcular}>Calcular cantidad × costo unitario</button>
        <label className="w04-field" style={{ display: "block", marginTop: 16 }}><span>Observaciones</span>
          <textarea rows={2} value={dato.observacion} onChange={e => setDato(p => ({ ...p, observacion: e.target.value }))} /></label>
        {error && <div className="w02-message w02-error" role="alert">{error}</div>}
        {aviso && <div className="w04-success" role="status">{aviso}</div>}
        <div className="w04-actions"><button type="button" className="w04-secondary" onClick={() => { setDato(vacio); setEditandoId(null); setError(""); }}>Limpiar</button>
          <button type="submit" className="w03-primary" disabled={guardando || !insumos.length || !unidades.length}>{guardando ? "Guardando…" : editandoId === null ? "Agregar ingrediente" : "Guardar ingrediente"}</button></div>
      </form>
    </>}
  </section>;
}

const formatearCostoW09 = valor => new Intl.NumberFormat("es-CL", {
  style: "currency", currency: "CLP", maximumFractionDigits: 0,
}).format(Number(valor || 0));

function FichaTecnicaFormulario({ inicial, csrfToken, onCancelar, onGuardado }) {
  const editando = Boolean(inicial);
  const [form, setForm] = useState(() => ({
    ...fichaInicial,
    ...(inicial ? Object.fromEntries(Object.keys(fichaInicial).map(k => [k, inicial[k] ?? ""])) : {}),
  }));
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState("");
  const [errores, setErrores] = useState({});
  const [unidades, setUnidades] = useState([]);
  const [cargandoUnidades, setCargandoUnidades] = useState(true);
  const [errorUnidades, setErrorUnidades] = useState("");
  const [resumenIngredientes, setResumenIngredientes] = useState({ costo: 0, listo: false });
  const [cargandoDetalle, setCargandoDetalle] = useState(editando);
  const actualizarResumen = useCallback((costo, listo) => {
    setResumenIngredientes(prev => prev.costo === costo && prev.listo === listo ? prev : { costo, listo });
  }, []);
  useEffect(() => {
    if (!editando) return;
    const controller = new AbortController();
    fetch(`/api/fichas-tecnicas/${inicial.id_ficha_tecnica}/`, {
      credentials: "same-origin", signal: controller.signal,
    }).then(async r => {
      if (!r.ok) throw new Error(`No se pudo cargar la ficha (HTTP ${r.status}).`);
      return r.json();
    }).then(detalle => {
      if (!controller.signal.aborted) setForm(prev => ({
        ...prev, ...Object.fromEntries(Object.keys(fichaInicial).map(k => [k, detalle[k] ?? prev[k] ?? ""])),
      }));
    }).catch(e => {
      if (e.name !== "AbortError") setError(e.message);
    }).finally(() => { if (!controller.signal.aborted) setCargandoDetalle(false); });
    return () => controller.abort();
  }, [inicial?.id_ficha_tecnica]);
  useEffect(() => {
    const controller = new AbortController();
    async function cargarUnidades() {
      try {
        const respuesta = await fetch("/api/unidades/", {
          credentials: "same-origin", signal: controller.signal,
        });
        if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status}`);
        const datos = normalizarLista(await respuesta.json());
        if (!controller.signal.aborted) setUnidades(datos.items);
      } catch (e) {
        if (!controller.signal.aborted && e.name !== "AbortError")
          setErrorUnidades("No se pudo cargar el catálogo de unidades desde Django.");
      } finally {
        if (!controller.signal.aborted) setCargandoUnidades(false);
      }
    }
    cargarUnidades();
    return () => controller.abort();
  }, []);
  const cambiar = e => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    setErrores(prev => ({ ...prev, [name]: "" }));
  };
  const guardar = async e => {
    e.preventDefault();
    const fallos = {};
    if (!form.nombre_ficha.trim()) fallos.nombre_ficha = "Ingrese el nombre de la ficha.";
    const camposNumericos = { rendimiento: 3, costo_total: 2, precio_sugerido: 2, margen_objetivo: 2 };
    const valores = {};
    for (const [campo, decimales] of Object.entries(camposNumericos)) {
      const valor = decimalApi(form[campo]);
      if (valor === null || valor === "" || valor.split(".")[1]?.length > decimales)
        fallos[campo] = `Ingrese un número válido (máximo ${decimales} decimales).`;
      else if ((campo === "rendimiento" && Number(valor) <= 0) || (campo !== "rendimiento" && Number(valor) < 0))
        fallos[campo] = campo === "rendimiento" ? "Debe ser mayor que cero." : "No puede ser negativo.";
      else if (campo === "margen_objetivo" && Number(valor) > 999.99)
        fallos[campo] = "El margen supera el máximo permitido.";
      valores[campo] = valor;
    }
    if (form.id_unidad_rendimiento && !unidades.some(
      u => String(u.id_unidad) === String(form.id_unidad_rendimiento)
    )) fallos.id_unidad_rendimiento = "Seleccione una unidad disponible en el catálogo.";
    if (errorUnidades || cargandoUnidades)
      fallos.id_unidad_rendimiento = "Espere a que se carguen las unidades antes de guardar.";
    setErrores(fallos);
    if (Object.keys(fallos).length) return;
    const datos = {
      nombre_ficha: form.nombre_ficha.trim(),
      descripcion: form.descripcion.trim(), tipo_preparacion: form.tipo_preparacion.trim(),
      rendimiento: valores.rendimiento, costo_total: valores.costo_total,
      precio_sugerido: valores.precio_sugerido, margen_objetivo: valores.margen_objetivo,
      id_unidad_rendimiento: form.id_unidad_rendimiento === "" ? null : Number(form.id_unidad_rendimiento),
      imagen_url: form.imagen_url.trim(), estado: form.estado,
      procedimiento: form.procedimiento,
    };
    setGuardando(true); setError("");
    try {
      const res = await fetch(editando ? `/api/fichas-tecnicas/${inicial.id_ficha_tecnica}/` : "/api/fichas-tecnicas/", {
        method: editando ? "PATCH" : "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json", "X-CSRFToken": csrfToken },
        body: JSON.stringify(datos),
      });
      const respuesta = await res.json().catch(() => ({}));
      if (!res.ok) {
        const detalle = respuesta.detail || `No se pudo guardar (HTTP ${res.status}).`;
        const nuevosErrores = Object.fromEntries(Object.entries(respuesta)
          .filter(([k]) => k !== "detail" && k !== "non_field_errors")
          .map(([k, v]) => [k, Array.isArray(v) ? v.join(" ") : String(v)]));
        setErrores(nuevosErrores);
        setError(Array.isArray(respuesta.non_field_errors) ? respuesta.non_field_errors.join(" ") : detalle);
        return;
      }
      await onGuardado(respuesta, !editando);
    } catch {
      setError("No se pudo conectar con Django. Verifica que el servidor esté activo.");
    } finally { setGuardando(false); }
  };
  const campo = (nombre, titulo, requerido = false, tipo = "text", ayuda = "") => <label className="w04-field" key={nombre}>
    <span>{titulo} {requerido && <b className="w04-required">*</b>}</span>
    <input name={nombre} type={tipo} value={form[nombre]} onChange={cambiar} required={requerido}
      maxLength={nombre === "nombre_ficha" ? 150 : nombre === "tipo_preparacion" ? 80 : undefined}
      aria-invalid={Boolean(errores[nombre])} />
    {ayuda && <small className="w02-note">{ayuda}</small>}
    {errores[nombre] && <small className="w04-error">{errores[nombre]}</small>}
  </label>;
  return <>
    <div className="w03-heading w05-heading"><div className="w02-intro">
      <div className="w02-breadcrumb">Inicio / Fichas técnicas / {editando ? `Ficha #${inicial.id_ficha_tecnica}` : "Nueva"}</div>
      <h1>{editando ? "W09 - Detalle / Edición Ficha Técnica" : "Nueva ficha técnica"}</h1>
      <p>{editando ? "Ingredientes, cantidades, costos y preparación de la ficha técnica." : "W08 · Registro de preparaciones, rendimiento y valores."}</p>
    </div></div>
    {cargandoDetalle && <p role="status">Cargando detalle actualizado de la ficha…</p>}
    <form onSubmit={guardar}>
      <section className="w02-card" style={{ padding: 20, marginBottom: 16 }}>
        <h2>Información de la ficha</h2>
        <div className="w04-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 16, marginTop: 16 }}>
          {campo("nombre_ficha", "Nombre de la preparación", true)}
          {campo("tipo_preparacion", "Tipo de preparación")}
          {campo("rendimiento", "Rendimiento", true)}
          <label className="w04-field">
            <span>Unidad de rendimiento (opcional)</span>
            <select name="id_unidad_rendimiento" value={String(form.id_unidad_rendimiento ?? "")}
              onChange={cambiar} disabled={cargandoUnidades || Boolean(errorUnidades)}
              aria-invalid={Boolean(errores.id_unidad_rendimiento)}>
              <option value="">{cargandoUnidades ? "Cargando unidades…" : "Sin unidad asignada"}</option>
              {unidades.map(u => <option key={u.id_unidad} value={String(u.id_unidad)}>
                {u.nombre_unidad}
              </option>)}
              {form.id_unidad_rendimiento && !unidades.some(u => String(u.id_unidad) === String(form.id_unidad_rendimiento)) &&
                <option value={String(form.id_unidad_rendimiento)}>Unidad actual #{form.id_unidad_rendimiento} (no disponible)</option>}
            </select>
            {errorUnidades && <small className="w04-error">{errorUnidades}</small>}
            {errores.id_unidad_rendimiento && <small className="w04-error">{errores.id_unidad_rendimiento}</small>}
          </label>
          <label className="w04-field"><span>Estado</span><select name="estado" value={form.estado} onChange={cambiar}><option value="activo">Activo</option><option value="inactivo">Inactivo</option></select></label>
          {campo("imagen_url", "URL de imagen (opcional)", false, "url")}
        </div>
        <label className="w04-field" style={{ display: "block", marginTop: 16 }}><span>Descripción</span><textarea name="descripcion" rows={3} value={form.descripcion} onChange={cambiar} /></label>
      </section>
    </form>
      {editando && <IngredientesFicha fichaId={inicial.id_ficha_tecnica} csrfToken={csrfToken} unidades={unidades} onResumen={actualizarResumen} />}
    <form onSubmit={guardar}>
      {editando && <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 350px), 1fr))", gap: 16, marginBottom: 16 }}>
        <section className="w02-card" style={{ padding: 20 }}>
          <h2>Preparación</h2>
          <label className="w04-field" style={{ display: "block", marginTop: 16 }}>
            <span>Procedimiento</span>
            <textarea name="procedimiento" rows={9} value={form.procedimiento || ""} onChange={cambiar}
              placeholder="Describe los pasos de preparación de la receta…" />
          </label>
        </section>
        <section className="w02-card" style={{ padding: 20 }}>
          <h2>Resumen de costos</h2>
          <div style={{ marginTop: 16, padding: 16, background: "#faf6f2", border: "1px solid #eadfd5", borderRadius: 8 }}>
            <small>Costo total de ingredientes</small>
            <strong style={{ display: "block", fontSize: 24, color: "#81350f" }}>
              {resumenIngredientes.listo ? formatearCostoW09(resumenIngredientes.costo) : "Consultando…"}
            </strong>
          </div>
          <div className="w02-line" style={{ marginTop: 18 }}><span>Rendimiento base</span><strong>{form.rendimiento || "—"} {unidades.find(u => String(u.id_unidad) === String(form.id_unidad_rendimiento))?.nombre_unidad || ""}</strong></div>
          <div className="w02-line"><span>Costo por unidad de rendimiento</span>
            <strong>{resumenIngredientes.listo && Number(decimalApi(form.rendimiento)) > 0
              ? formatearCostoW09(resumenIngredientes.costo / Number(decimalApi(form.rendimiento))) : "—"}</strong>
          </div>
          <p className="w02-note">Calculado desde las recetas guardadas. No modifica automáticamente el costo total de la ficha.</p>
        </section>
      </div>}
      <section className="w02-card" style={{ padding: 20, marginBottom: 16 }}>
        <h2>Costos y precios</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 16, marginTop: 16 }}>
          {campo("costo_total", "Costo total (CLP)", true, "text", "Ejemplo: 57000 o 57.000")}
          {campo("precio_sugerido", "Precio sugerido (CLP)", true, "text", "Ejemplo: 85000 o 85.000")}
          {campo("margen_objetivo", "Margen objetivo (%)", true, "text", "Ejemplo: 30 o 30,50")}
        </div>
      </section>
      {error && <div className="w02-message w02-error" role="alert">{error}</div>}
      <div className="w04-actions"><button type="button" className="w04-secondary" onClick={onCancelar}>Cancelar</button>
        <button type="submit" className="w03-primary" disabled={guardando || cargandoDetalle}>{guardando ? "Guardando…" : editando ? "Guardar ficha técnica" : "Crear ficha"}</button></div>
    </form>
    {!editando && <section className="w02-card" style={{ padding: 20, marginTop: 16 }}><h2>Ingredientes de la receta</h2>
          <p>Guarda primero la ficha técnica. Después podrás agregar sus ingredientes.</p></section>}
  </>;
}

function FichasTecnicasVista({ csrfToken }) {
  const [fichas, setFichas] = useState([]);
  const [total, setTotal] = useState(0);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");
  const [aviso, setAviso] = useState("");
  const [edicion, setEdicion] = useState(undefined);
  const [busqueda, setBusqueda] = useState("");
  const [tipo, setTipo] = useState("todos");
  const [estado, setEstado] = useState("todos");
  const cargar = async (signal) => {
    const respuesta = await fetch("/api/fichas-tecnicas/", { credentials: "same-origin", signal });
    if (!respuesta.ok) throw new Error(`No se pudieron consultar las fichas (HTTP ${respuesta.status}).`);
    const datos = normalizarLista(await respuesta.json());
    setFichas(datos.items); setTotal(datos.total);
  };
  useEffect(() => {
    const controller = new AbortController();
    cargar(controller.signal).catch(e => { if (e.name !== "AbortError") setError(e.message); })
      .finally(() => { if (!controller.signal.aborted) setCargando(false); });
    return () => controller.abort();
  }, []);
  const tipos = useMemo(() => [...new Set(fichas.map(f => f.tipo_preparacion).filter(Boolean))].sort(), [fichas]);
  const estados = useMemo(() => [...new Set(fichas.map(f => f.estado).filter(Boolean))].sort(), [fichas]);
  const filtradas = useMemo(() => fichas.filter(f => {
    const texto = [f.nombre_ficha, f.descripcion, f.tipo_preparacion].filter(Boolean).join(" ").toLocaleLowerCase("es");
    return texto.includes(busqueda.trim().toLocaleLowerCase("es")) &&
      (tipo === "todos" || f.tipo_preparacion === tipo) &&
      (estado === "todos" || f.estado === estado);
  }), [fichas, busqueda, tipo, estado]);
  const dinero = valor => valor === null || valor === undefined || valor === "" ? "—"
    : new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(Number(valor));
  const etiqueta = valor => String(valor || "—").replaceAll("_", " ");
  const guardado = async (respuesta, eraNueva) => {
    await cargar(); setError("");
    if (eraNueva && respuesta?.id_ficha_tecnica) {
      setEdicion(respuesta);
      setAviso("Ficha creada. Ahora puedes agregar ingredientes.");
    } else {
      setEdicion(prev => prev ? { ...prev, ...respuesta } : undefined);
      setAviso("Ficha técnica guardada correctamente.");
    }
  };
  if (edicion !== undefined) return <FichaTecnicaFormulario key={edicion?.id_ficha_tecnica ?? "nueva"}
    inicial={edicion} csrfToken={csrfToken} onCancelar={() => setEdicion(undefined)} onGuardado={guardado} />;
  return <>
    <div className="w03-heading w05-heading">
      <div className="w02-intro"><div className="w02-breadcrumb">Inicio / Fichas técnicas</div>
        <h1>W08 - Fichas técnicas</h1><p>Consulta de preparaciones, costos y precios registrados.</p></div>
      <button type="button" className="w03-primary" onClick={() => { setAviso(""); setEdicion(null); }}>+ Nueva ficha</button>
    </div>
    {error && <div className="w02-message w02-error" role="alert">{error}</div>}
    {aviso && <div className="w04-success" role="status">{aviso}</div>}
    <section className="w02-card w05-filtros" aria-label="Filtros de fichas técnicas">
      <label><span>Buscar ficha</span><input value={busqueda} onChange={e => setBusqueda(e.target.value)} placeholder="Nombre, descripción o preparación…" /></label>
      <label><span>Tipo de preparación</span><select value={tipo} onChange={e => setTipo(e.target.value)}><option value="todos">Todos los tipos</option>{tipos.map(t => <option key={t} value={t}>{etiqueta(t)}</option>)}</select></label>
      <label><span>Estado</span><select value={estado} onChange={e => setEstado(e.target.value)}><option value="todos">Todos los estados</option>{estados.map(e => <option key={e} value={e}>{etiqueta(e)}</option>)}</select></label>
    </section>
    <section className="w02-card w05-listado">
      <div className="w05-listado-cabecera"><h2>Lista de fichas técnicas ({filtradas.length})</h2><span>Datos reales · API Django</span></div>
      <div className="w02-table-scroll w05-table-scroll" style={{ width: "100%", maxWidth: "100%", overflowX: "auto" }}><table className="w05-table" style={{ minWidth: 1130, width: "100%", tableLayout: "fixed" }}><colgroup><col style={{ width: 65 }} /><col style={{ width: 230 }} /><col style={{ width: 155 }} /><col style={{ width: 110 }} /><col style={{ width: 120 }} /><col style={{ width: 125 }} /><col style={{ width: 130 }} /><col style={{ width: 95 }} /><col style={{ width: 100 }} /></colgroup>
        <thead><tr><th>ID</th><th>Ficha / Descripción</th><th>Tipo</th><th>Rendimiento</th><th>Costo total</th><th>Precio sugerido</th><th>Margen objetivo</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody>
          {filtradas.map(f => <tr key={f.id_ficha_tecnica}>
            <td><strong>#{f.id_ficha_tecnica}</strong></td>
            <td style={{ overflowWrap: "anywhere", whiteSpace: "normal" }}><strong>{f.nombre_ficha || "Sin nombre"}</strong><small className="w05-evento" style={{ display: "block", overflowWrap: "anywhere", whiteSpace: "normal" }}>{f.descripcion || "Sin descripción"}</small></td>
            <td style={{ overflowWrap: "anywhere", whiteSpace: "normal" }}>{etiqueta(f.tipo_preparacion)}</td><td>{f.rendimiento ?? "—"}</td>
            <td>{dinero(f.costo_total)}</td><td>{dinero(f.precio_sugerido)}</td>
            <td>{f.margen_objetivo == null ? "—" : `${f.margen_objetivo}%`}</td>
            <td><span className={`w03-status ${String(f.estado).toLowerCase() === "activo" ? "on" : "off"}`}>{etiqueta(f.estado)}</span></td>
            <td><button type="button" className="w04-secondary" onClick={() => { setAviso(""); setEdicion(f); }}>Abrir Detalle</button></td>
          </tr>)}
          {cargando && <tr><td colSpan="9">Cargando fichas técnicas…</td></tr>}
          {!cargando && !error && filtradas.length === 0 && <tr><td colSpan="9">No se encontraron fichas técnicas.</td></tr>}
        </tbody>
      </table></div>
      {total > fichas.length && <p className="w02-note">Mostrando {fichas.length} de {total} fichas. Los filtros abarcan solo los registros recibidos.</p>}
      <p className="w02-note">Selecciona «Abrir W09» para editar la ficha, su procedimiento y sus ingredientes.</p>
    </section>
  </>;
}

// W10: Cotizador. Los conceptos se calculan en el navegador; la API actual
// almacena los totales de la cotización, no el desglose individual.
const dineroW10 = valor => new Intl.NumberFormat("es-CL", {
  style: "currency", currency: "CLP", maximumFractionDigits: 0,
}).format(Number(valor || 0));

function CotizadorVista({ pedidos, csrfToken, sesion }) {
  const [cotizaciones, setCotizaciones] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");
  const [aviso, setAviso] = useState("");
  const [guardando, setGuardando] = useState(false);
  const [pedidoId, setPedidoId] = useState("");
  const [conceptos, setConceptos] = useState([{ id: 1, nombre: "", cantidad: "1", costo: "0" }]);
  const [personal, setPersonal] = useState("0");
  const [transporte, setTransporte] = useState("0");
  const [otros, setOtros] = useState("0");
  const [margen, setMargen] = useState("30");
  const [observacion, setObservacion] = useState("");
  const [errores, setErrores] = useState({});
  const [modo, setModo] = useState("lista");

  const cargar = useCallback(async (signal) => {
    const res = await fetch("/api/cotizaciones/", { credentials: "same-origin", signal });
    if (!res.ok) throw new Error(`No se pudieron consultar las cotizaciones (HTTP ${res.status}).`);
    const datos = normalizarLista(await res.json());
    setCotizaciones(datos.items);
  }, []);
  useEffect(() => {
    const controller = new AbortController();
    cargar(controller.signal).catch(e => {
      if (e.name !== "AbortError") setError(e.message || "No se pudo consultar la API.");
    }).finally(() => { if (!controller.signal.aborted) setCargando(false); });
    return () => controller.abort();
  }, [cargar]);

  const numero = v => {
    const n = decimalApi(v);
    return n === null || n === "" ? NaN : Number(n);
  };
  const lineas = conceptos.map(c => ({ ...c, subtotal: numero(c.cantidad) * numero(c.costo) }));
  const costoInsumos = lineas.reduce((s, c) => s + (Number.isFinite(c.subtotal) ? c.subtotal : 0), 0);
  const costoPersonal = numero(personal), costoTransporte = numero(transporte), otrosCostos = numero(otros);
  const porcentaje = numero(margen);
  const costoTotal = costoInsumos + (Number.isFinite(costoPersonal) ? costoPersonal : 0)
    + (Number.isFinite(costoTransporte) ? costoTransporte : 0)
    + (Number.isFinite(otrosCostos) ? otrosCostos : 0);
  // Margen objetivo calculado sobre el precio de venta (no recargo sobre costo).
  const precioSugerido = Number.isFinite(porcentaje) && porcentaje >= 0 && porcentaje < 100
    ? costoTotal / (1 - porcentaje / 100) : NaN;
  const cambiarConcepto = (id, campo, valor) => setConceptos(prev =>
    prev.map(c => c.id === id ? { ...c, [campo]: valor } : c));
  const nuevo = () => { setModo("formulario"); setError(""); setAviso(""); setErrores({}); };
  const volver = () => { setModo("lista"); setError(""); setErrores({}); };

  const guardar = async e => {
    e.preventDefault(); setError(""); setErrores({});
    const err = {};
    if (!pedidoId) err.pedido = "Seleccione un pedido.";
    if (!conceptos.length || conceptos.some(c => !c.nombre.trim() || !Number.isFinite(numero(c.cantidad)) || numero(c.cantidad) <= 0 || !Number.isFinite(numero(c.costo)) || numero(c.costo) < 0))
      err.conceptos = "Complete cada concepto, cantidad mayor que cero y costo no negativo.";
    if ([costoPersonal, costoTransporte, otrosCostos].some(n => !Number.isFinite(n) || n < 0))
      err.costos = "Ingrese costos válidos, sin valores negativos.";
    if (!Number.isFinite(porcentaje) || porcentaje < 0 || porcentaje >= 100)
      err.margen = "El margen debe ser igual o mayor que 0 y menor que 100%.";
    if (Object.keys(err).length) { setErrores(err); return; }
    const payload = {
      id_pedido: Number(pedidoId),
      costo_insumos: costoInsumos.toFixed(2),
      costo_personal: costoPersonal.toFixed(2),
      costo_transporte: costoTransporte.toFixed(2),
      otros_costos: otrosCostos.toFixed(2),
      costo_total: costoTotal.toFixed(2),
      margen_objetivo: porcentaje.toFixed(2),
      precio_sugerido: precioSugerido.toFixed(2),
      estado: "vigente",
      observacion,
    };
    // No se inventa el identificador del usuario: Django debe asignarlo
    // desde request.user o exponerlo de manera explícita en la sesión.
    if (sesion?.id_usuario != null) payload.id_usuario = Number(sesion.id_usuario);
    setGuardando(true);
    try {
      const res = await fetch("/api/cotizaciones/", {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json", "X-CSRFToken": csrfToken },
        body: JSON.stringify(payload),
      });
      const respuesta = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(`No se pudo guardar (HTTP ${res.status}). ${Object.entries(respuesta).map(([k,v]) => `${k}: ${Array.isArray(v) ? v.join(", ") : typeof v === "object" ? JSON.stringify(v) : v}`).join(" · ")}`);
        return;
      }
      await cargar();
      setAviso("Cotización guardada correctamente. El desglose de conceptos no se almacena en la API actual.");
      setModo("lista");
    } catch (e) { setError(e.message || "No fue posible contactar con Django."); }
    finally { setGuardando(false); }
  };

  const campoCosto = (titulo, valor, asignar) => <label className="w04-field">
    <span>{titulo} (CLP)</span>
    <input inputMode="decimal" value={valor} onChange={e => asignar(e.target.value)} placeholder="0" />
  </label>;
  return <div className="w10-cotizador">
    <div className="w03-heading w05-heading">
      <div className="w02-intro"><div className="w02-breadcrumb">Inicio / Cotizador</div>
        <h1>W10 - Cotizador</h1><p>Estimación de costos y precio sugerido para pedidos.</p></div>
      <button type="button" className={modo === "lista" ? "w03-primary" : "w04-secondary"} onClick={modo === "lista" ? nuevo : volver}>
        {modo === "lista" ? "+ Nueva cotización" : "← Volver al listado"}</button>
    </div>
    {aviso && <div className="w04-success" role="status">{aviso}</div>}
    {error && <div className="w02-message w02-error" role="alert">{error}</div>}
    {modo === "lista" ? <section className="w02-card w05-listado">
      <div className="w05-listado-cabecera"><h2>Cotizaciones registradas ({cotizaciones.length})</h2><span>Datos consultados desde Django</span></div>
      <div className="w02-table-scroll"><table className="w05-table" style={{ width: "100%", minWidth: 760 }}>
        <thead><tr><th>ID</th><th>Pedido</th><th>Fecha</th><th>Costo total</th><th>Margen</th><th>Precio sugerido</th><th>Estado</th></tr></thead>
        <tbody>{cotizaciones.map(c => <tr key={c.id_cotizacion}>
          <td>#{c.id_cotizacion}</td><td>#{c.id_pedido}</td><td>{fechaLegible(c.fecha_cotizacion)}</td>
          <td>{dineroW10(c.costo_total)}</td><td>{c.margen_objetivo}%</td>
          <td>{dineroW10(c.precio_sugerido)}</td><td>{c.estado || "—"}</td>
        </tr>)}
        {cargando && <tr><td colSpan="7">Cargando cotizaciones…</td></tr>}
        {!cargando && !error && !cotizaciones.length && <tr><td colSpan="7">No hay cotizaciones registradas.</td></tr>}
        </tbody></table></div>
      <p className="w02-note">La consulta muestra los registros devueltos por la API. No se incluye paginación adicional.</p>
    </section> : <form onSubmit={guardar}>
      <section className="w02-card w04-section"><h2>Pedido asociado</h2>
        <div className="w04-grid"><label className="w04-field"><span>Pedido *</span>
          <select value={pedidoId} onChange={e => setPedidoId(e.target.value)} required>
            <option value="">Seleccione un pedido</option>
            {pedidos.map(p => <option key={p.id_pedido} value={p.id_pedido}>{p.numero_pedido || `Pedido #${p.id_pedido}`} {p.nombre_cliente ? `· ${p.nombre_cliente}` : ""}</option>)}
          </select>{errores.pedido && <small className="w04-error">{errores.pedido}</small>}
        </label></div>
        {!pedidos.length && <p className="w02-note">No hay pedidos cargados. Comprueba el listado W05 antes de guardar.</p>}
      </section>
      <section className="w02-card w04-section"><h2>Conceptos e insumos</h2>
        <p className="w02-note">El desglose se usa para calcular el total, pero no se guarda individualmente con el esquema actual.</p>
        <div className="w02-table-scroll"><table className="w05-table" style={{ minWidth: 700, width: "100%" }}>
          <thead><tr><th>Concepto</th><th>Cantidad</th><th>Costo unitario (CLP)</th><th>Subtotal</th><th>Acción</th></tr></thead>
          <tbody>{lineas.map(c => <tr key={c.id}>
            <td><input aria-label="Nombre del concepto" value={c.nombre} onChange={e => cambiarConcepto(c.id, "nombre", e.target.value)} placeholder="Ej. Servicio de alimentación" /></td>
            <td><input aria-label="Cantidad" inputMode="decimal" value={c.cantidad} onChange={e => cambiarConcepto(c.id, "cantidad", e.target.value)} style={{ width: 95 }} /></td>
            <td><input aria-label="Costo unitario" inputMode="decimal" value={c.costo} onChange={e => cambiarConcepto(c.id, "costo", e.target.value)} style={{ width: 140 }} /></td>
            <td>{Number.isFinite(c.subtotal) ? dineroW10(c.subtotal) : "—"}</td>
            <td><button type="button" className="w04-secondary" disabled={conceptos.length === 1} onClick={() => setConceptos(prev => prev.filter(x => x.id !== c.id))}>Quitar</button></td>
          </tr>)}</tbody></table></div>
        {errores.conceptos && <small className="w04-error">{errores.conceptos}</small>}
        <div className="w04-actions"><button type="button" className="w04-secondary" onClick={() => setConceptos(prev => [...prev, { id: Math.max(0, ...prev.map(c => c.id)) + 1, nombre: "", cantidad: "1", costo: "0" }])}>+ Agregar concepto</button></div>
        <div className="w02-line"><span>Total insumos</span><strong>{dineroW10(costoInsumos)}</strong></div>
      </section>
      <section className="w02-card w04-section"><h2>Otros costos y margen</h2>
        <div className="w04-grid">{campoCosto("Personal", personal, setPersonal)}
          {campoCosto("Transporte", transporte, setTransporte)}{campoCosto("Otros costos", otros, setOtros)}
          <label className="w04-field"><span>Margen objetivo (%) *</span><input inputMode="decimal" value={margen} onChange={e => setMargen(e.target.value)} /></label>
        </div>
        {errores.costos && <small className="w04-error">{errores.costos}</small>}
        {errores.margen && <small className="w04-error">{errores.margen}</small>}
        <p className="w02-note">El precio se calcula como costo total ÷ (1 − margen / 100).</p>
        <div className="w02-line"><span>Costo total</span><strong>{dineroW10(costoTotal)}</strong></div>
        <div className="w02-line"><span>Precio sugerido</span><strong>{Number.isFinite(precioSugerido) ? dineroW10(precioSugerido) : "Margen inválido"}</strong></div>
        <label className="w04-field" style={{ display: "block", marginTop: 16 }}><span>Observación</span>
          <textarea rows={3} value={observacion} onChange={e => setObservacion(e.target.value)} placeholder="Comentarios sobre la cotización" /></label>
      </section>
      <div className="w04-actions"><button type="button" className="w04-secondary" onClick={volver}>Cancelar</button>
        <button type="submit" className="w03-primary" disabled={guardando || !pedidos.length}>{guardando ? "Guardando…" : "Guardar cotización"}</button></div>
      <p className="w02-note">El guardado depende de que el endpoint POST /api/cotizaciones/ acepte estos campos y asigne el usuario autenticado. Si no lo hace, se mostrará el error devuelto por Django.</p>
    </form>}
  </div>;
}


// W11: consulta de inventario y movimientos reales desde Django.
function InventarioVista({ csrfToken }) {
  const [inventario, setInventario] = useState([]);
  const [movimientos, setMovimientos] = useState([]);
  const [insumos, setInsumos] = useState([]);
  const [totalInventario, setTotalInventario] = useState(0);
  const [totalMovimientos, setTotalMovimientos] = useState(0);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");
  const [busqueda, setBusqueda] = useState("");
  const [nivel, setNivel] = useState("todos");
  const [pestana, setPestana] = useState("existencias");
  const [actualizacion, setActualizacion] = useState(0);
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [guardandoMovimiento, setGuardandoMovimiento] = useState(false);
  const [mensajeMovimiento, setMensajeMovimiento] = useState("");
  const [errorMovimiento, setErrorMovimiento] = useState("");
  const [formMovimiento, setFormMovimiento] = useState({
    id_inventario: "", tipo_movimiento: "entrada", cantidad: "",
    costo_unitario: "0", observacion: ""
  });
  const cambiarMovimiento = (campo, valor) => setFormMovimiento(prev => ({ ...prev, [campo]: valor }));
  const registrarMovimiento = async (e) => {
    e.preventDefault();
    if (guardandoMovimiento) return;
    setErrorMovimiento(""); setMensajeMovimiento("");
    const registro = inventario.find(r => String(r.id_inventario) === formMovimiento.id_inventario);
    if (!registro) { setErrorMovimiento("Selecciona un insumo del inventario."); return; }
    // El backend recibe decimales con punto; se permite coma decimal al usuario.
    const decimal = texto => String(texto).trim().replace(",", ".");
    const cantidad = decimal(formMovimiento.cantidad);
    const costo = decimal(formMovimiento.costo_unitario);
    if (!/^\d+(\.\d{1,3})?$/.test(cantidad) || Number(cantidad) <= 0) {
      setErrorMovimiento("La cantidad debe ser mayor a cero y tener hasta 3 decimales."); return;
    }
    if (!/^\d+(\.\d{1,2})?$/.test(costo)) {
      setErrorMovimiento("El costo debe ser mayor o igual a cero y tener hasta 2 decimales."); return;
    }
    if (formMovimiento.tipo_movimiento === "salida" && Number(cantidad) > Number(registro.stock_actual)) {
      setErrorMovimiento(`Stock insuficiente. Disponible: ${registro.stock_actual}.`); return;
    }
    try {
      setGuardandoMovimiento(true);
      const respuesta = await fetch("/api/movimientos-inventario/registrar/", {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json", "X-CSRFToken": csrfToken || decodeURIComponent(document.cookie.split("; ").find(v => v.startsWith("csrftoken="))?.split("=")[1] || "") },
        body: JSON.stringify({
          id_insumo: registro.id_insumo,
          id_bodega: registro.id_bodega,
          tipo_movimiento: formMovimiento.tipo_movimiento,
          cantidad, costo_unitario: costo,
          observacion: formMovimiento.observacion.trim()
        })
      });
      const datos = await respuesta.json().catch(() => ({}));
      if (!respuesta.ok) {
        const detalle = datos.error || datos.detail || Object.entries(datos).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(", ") : v}`).join(" · ");
        throw new Error(detalle || `No se pudo guardar (HTTP ${respuesta.status}).`);
      }
      setMensajeMovimiento(`Movimiento #${datos.id_movimiento} registrado. Stock: ${datos.stock_anterior} → ${datos.stock_actual}.`);
      setMostrarFormulario(false);
      setFormMovimiento({ id_inventario: "", tipo_movimiento: "entrada", cantidad: "", costo_unitario: "0", observacion: "" });
      setActualizacion(n => n + 1);
    } catch (err) {
      setErrorMovimiento(err.message || "No se pudo conectar con Django.");
    } finally { setGuardandoMovimiento(false); }
  };

  useEffect(() => {
    const controller = new AbortController();
    async function cargar() {
      setCargando(true); setError("");
      try {
        const [ri, rm, rs] = await Promise.all([
          fetch("/api/inventario/", { credentials: "same-origin", signal: controller.signal }),
          fetch("/api/movimientos-inventario/", { credentials: "same-origin", signal: controller.signal }),
          fetch("/api/insumos/", { credentials: "same-origin", signal: controller.signal }),
        ]);
        if (!ri.ok || !rm.ok) throw new Error(`No se pudo consultar inventario o movimientos (HTTP ${!ri.ok ? ri.status : rm.status}).`);
        const [di, dm] = await Promise.all([ri.json(), rm.json()]);
        const ni = normalizarLista(di), nm = normalizarLista(dm);
        if (!controller.signal.aborted) {
          setInventario(ni.items); setTotalInventario(ni.total);
          setMovimientos(nm.items); setTotalMovimientos(nm.total);
        }
        // El catálogo es complementario: la consulta de stock sigue disponible si falla.
        if (rs.ok) {
          const ns = normalizarLista(await rs.json());
          if (!controller.signal.aborted) setInsumos(ns.items);
        }
      } catch (e) {
        if (e.name !== "AbortError" && !controller.signal.aborted)
          setError(e.message || "No fue posible conectar con Django.");
      } finally { if (!controller.signal.aborted) setCargando(false); }
    }
    cargar();
    return () => controller.abort();
  }, [actualizacion]);

  const mapaInsumos = useMemo(() => new Map(insumos.map(i => [String(i.id_insumo), i])), [insumos]);
  const nombreInsumo = r => r.nombre_insumo || mapaInsumos.get(String(r.id_insumo))?.nombre_insumo || `Insumo #${r.id_insumo ?? "—"}`;
  const nivelStock = r => {
    const actual = Number(r.stock_actual), minimo = Number(r.stock_minimo);
    if (!Number.isFinite(actual) || !Number.isFinite(minimo)) return "sin datos";
    if (actual < minimo) return "crítico";
    if (actual === minimo) return "mínimo";
    return "normal";
  };
  const filtrados = useMemo(() => inventario.filter(r => {
    const texto = [r.id_inventario, r.id_insumo, nombreInsumo(r), r.ubicacion, r.estado, r.id_bodega]
      .filter(v => v != null).join(" ").toLocaleLowerCase("es");
    return texto.includes(busqueda.trim().toLocaleLowerCase("es")) &&
      (nivel === "todos" || nivelStock(r) === nivel);
  }), [inventario, busqueda, nivel, mapaInsumos]);
  const formatoCantidad = v => v == null || v === "" ? "—" :
    new Intl.NumberFormat("es-CL", { maximumFractionDigits: 3 }).format(Number(v));
  const fechaHora = v => {
    if (!v) return "—";
    const d = new Date(v);
    return Number.isNaN(d.getTime()) ? String(v) : new Intl.DateTimeFormat("es-CL", {
      dateStyle: "short", timeStyle: "short"
    }).format(d);
  };
  const criticos = inventario.filter(r => nivelStock(r) === "crítico").length;
  const minimos = inventario.filter(r => nivelStock(r) === "mínimo").length;
  const movimientosHoy = movimientos.filter(r => {
    if (!r.fecha_movimiento) return false;
    return new Date(r.fecha_movimiento).toDateString() === new Date().toDateString();
  }).length;
  const tarjetas = [
    ["Registros de inventario", totalInventario],
    ["Stock crítico", criticos],
    ["En stock mínimo", minimos],
    ["Movimientos de hoy", movimientosHoy],
  ];
  return <div className="w11-inventario">
    <div className="w03-heading w05-heading">
      <div className="w02-intro"><div className="w02-breadcrumb">Inicio / Inventario</div>
        <h1>W11 - Inventario</h1><p>Existencias y trazabilidad de movimientos registrados en Django.</p></div>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        <button type="button" className="w03-primary" onClick={() => {
          setMostrarFormulario(v => !v); setErrorMovimiento(""); setMensajeMovimiento("");
        }}>{mostrarFormulario ? "Cerrar formulario" : "+ Registrar movimiento"}</button>
        <button type="button" className="w04-secondary" disabled={cargando}
          onClick={() => setActualizacion(n => n + 1)}>↻ Actualizar</button>
      </div>
    </div>
    {mensajeMovimiento && <div className="w02-message" role="status" style={{ background: "#e8f7eb", color: "#176336", padding: 14, borderRadius: 8, marginBottom: 14 }}>{mensajeMovimiento}</div>}
    {errorMovimiento && <div className="w02-message w02-error" role="alert">{errorMovimiento}</div>}
    {mostrarFormulario && <form className="w02-card w04-section" onSubmit={registrarMovimiento} style={{ marginBottom: 18 }}>
      <h2>Registrar movimiento de inventario</h2>
      <p className="w02-note">Selecciona una existencia. La bodega se obtiene automáticamente del registro elegido.</p>
      <div className="w04-grid">
        <label className="w04-field"><span>Insumo y bodega *</span>
          <select required value={formMovimiento.id_inventario} onChange={e => cambiarMovimiento("id_inventario", e.target.value)}>
            <option value="">Selecciona un insumo</option>
            {inventario.map(r => <option key={r.id_inventario} value={String(r.id_inventario)}>
              {nombreInsumo(r)} — Bodega {r.nombre_bodega || r.id_bodega} — Disponible: {formatoCantidad(r.stock_actual)}
            </option>)}
          </select>
        </label>
        <label className="w04-field"><span>Tipo de movimiento *</span>
          <select value={formMovimiento.tipo_movimiento} onChange={e => cambiarMovimiento("tipo_movimiento", e.target.value)}>
            <option value="entrada">Entrada (+)</option><option value="salida">Salida (−)</option>
          </select>
        </label>
        <label className="w04-field"><span>Cantidad *</span>
          <input required inputMode="decimal" placeholder="Ej. 5 o 2,5" value={formMovimiento.cantidad}
            onChange={e => cambiarMovimiento("cantidad", e.target.value)} />
        </label>
        <label className="w04-field"><span>Costo unitario (CLP) *</span>
          <input required inputMode="decimal" value={formMovimiento.costo_unitario}
            onChange={e => cambiarMovimiento("costo_unitario", e.target.value)} />
        </label>
      </div>
      <label className="w04-field" style={{ display: "block", marginTop: 14 }}><span>Observación (opcional)</span>
        <textarea rows={3} maxLength={1000} value={formMovimiento.observacion}
          onChange={e => cambiarMovimiento("observacion", e.target.value)} placeholder="Motivo de la entrada o salida" />
      </label>
      <div className="w04-actions">
        <button type="button" className="w04-secondary" disabled={guardandoMovimiento} onClick={() => setMostrarFormulario(false)}>Cancelar</button>
        <button type="submit" className="w03-primary" disabled={guardandoMovimiento || cargando || !inventario.length}>
          {guardandoMovimiento ? "Registrando…" : "Confirmar movimiento"}
        </button>
      </div>
    </form>}
    {error && <div className="w02-message w02-error" role="alert">{error}</div>}
    <div className="w02-metrics" style={{ marginBottom: 20 }}>
      {tarjetas.map(([titulo, valor]) => <div className="w02-card w02-metric" key={titulo}>
        <div><span>{titulo}</span><strong>{cargando ? "…" : error ? "—" : valor}</strong>
          <small>Datos de la API</small></div></div>)}
    </div>
    <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
      <button type="button" className={pestana === "existencias" ? "w03-primary" : "w04-secondary"}
        onClick={() => setPestana("existencias")}>Existencias</button>
      <button type="button" className={pestana === "movimientos" ? "w03-primary" : "w04-secondary"}
        onClick={() => setPestana("movimientos")}>Historial de movimientos</button>
    </div>
    {pestana === "existencias" ? <>
      <section className="w02-card w05-filtros" aria-label="Filtros de inventario">
        <label><span>Buscar</span><input value={busqueda} onChange={e => setBusqueda(e.target.value)}
          placeholder="Insumo, ID, bodega o ubicación…" /></label>
        <label><span>Nivel de stock</span><select value={nivel} onChange={e => setNivel(e.target.value)}>
          <option value="todos">Todos</option><option value="normal">Normal</option>
          <option value="mínimo">Mínimo</option><option value="crítico">Crítico</option>
          <option value="sin datos">Sin datos</option></select></label>
      </section>
      <section className="w02-card w05-listado">
        <div className="w05-listado-cabecera"><h2>Existencias ({filtrados.length})</h2><span>Consulta en tiempo real · Django</span></div>
        <div className="w02-table-scroll"><table className="w05-table" style={{ width: "100%", minWidth: 900 }}>
          <thead><tr><th>ID</th><th>Insumo</th><th>Bodega</th><th>Ubicación</th>
            <th>Stock actual</th><th>Stock mínimo</th><th>Nivel</th><th>Estado</th></tr></thead>
          <tbody>{filtrados.map(r => <tr key={r.id_inventario}>
            <td>#{r.id_inventario}</td><td><strong>{nombreInsumo(r)}</strong></td>
            <td>{r.nombre_bodega || r.id_bodega || "—"}</td><td>{r.ubicacion || "—"}</td>
            <td>{formatoCantidad(r.stock_actual)}</td><td>{formatoCantidad(r.stock_minimo)}</td>
            <td><strong>{nivelStock(r)}</strong></td><td>{r.estado || "—"}</td>
          </tr>)}
          {cargando && <tr><td colSpan="8">Cargando inventario…</td></tr>}
          {!cargando && !error && filtrados.length === 0 && <tr><td colSpan="8">No se encontraron existencias.</td></tr>}
          </tbody></table></div>
        {totalInventario > inventario.length && <p className="w02-note">Se muestran {inventario.length} de {totalInventario} registros. Los filtros e indicadores de stock se calculan sobre la página recibida.</p>}
      </section>
    </> : <section className="w02-card w05-listado">
      <div className="w05-listado-cabecera"><h2>Movimientos ({movimientos.length})</h2><span>Historial registrado · Django</span></div>
      <div className="w02-table-scroll"><table className="w05-table" style={{ width: "100%", minWidth: 760 }}>
        <thead><tr><th>ID</th><th>Fecha</th><th>Tipo</th><th>Insumo</th><th>Bodega</th><th>Cantidad</th></tr></thead>
        <tbody>{[...movimientos].sort((a, b) => new Date(b.fecha_movimiento || 0) - new Date(a.fecha_movimiento || 0))
          .map(m => <tr key={m.id_movimiento}>
            <td>#{m.id_movimiento}</td><td>{fechaHora(m.fecha_movimiento)}</td>
            <td>{m.tipo_movimiento || "—"}</td><td>{nombreInsumo(m)}</td>
            <td>{m.nombre_bodega || m.id_bodega || "—"}</td><td>{formatoCantidad(m.cantidad)}</td>
          </tr>)}
          {cargando && <tr><td colSpan="6">Cargando movimientos…</td></tr>}
          {!cargando && !error && movimientos.length === 0 && <tr><td colSpan="6">No hay movimientos registrados.</td></tr>}
        </tbody></table></div>
      {totalMovimientos > movimientos.length && <p className="w02-note">Se muestran {movimientos.length} de {totalMovimientos} movimientos. El indicador «Movimientos de hoy» considera solo los registros recibidos.</p>}
      <p className="w02-note">Las entradas y salidas se registran mediante Django; el stock y el historial se actualizan juntos.</p>
    </section>}
  </div>;
}


// W12: ventas, facturas y pagos desde Django REST API.
function VentasFacturacionVista() {
  const [ventas, setVentas] = useState([]);
  const [facturas, setFacturas] = useState([]);
  const [pagos, setPagos] = useState([]);
  const [busqueda, setBusqueda] = useState("");
  const [estado, setEstado] = useState("");
  const [fecha, setFecha] = useState("");
  const [detalle, setDetalle] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");

  const cargar = useCallback(async () => {
    setCargando(true);
    setError("");
    try {
      const endpoints = ["ventas", "facturas", "pagos"];
      const respuestas = await Promise.all(endpoints.map(ruta => fetch(`/api/${ruta}/`, { credentials: "same-origin" })));
      for (let i = 0; i < respuestas.length; i++) {
        if (!respuestas[i].ok) throw new Error(`No se pudo consultar ${endpoints[i]} (HTTP ${respuestas[i].status}).`);
      }
      const datos = await Promise.all(respuestas.map(r => r.json()));
      const listas = datos.map(d => normalizarLista(d).items);
      setVentas(listas[0]); setFacturas(listas[1]); setPagos(listas[2]);
    } catch (e) { setError(e.message || "No se pudo cargar la información."); }
    finally { setCargando(false); }
  }, []);
  useEffect(() => { cargar(); }, [cargar]);

  const dinero = n => new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(Number(n) || 0);
  const registros = useMemo(() => ventas.map(v => {
    const facturasVenta = facturas.filter(f => String(f.id_venta) === String(v.id_venta));
    const ids = new Set(facturasVenta.map(f => String(f.id_factura)));
    const pagosVenta = pagos.filter(p => ids.has(String(p.id_factura)) && !["pendiente", "rechazado", "anulado", "cancelado"].includes(String(p.estado || "").toLowerCase()));
    const total = Number(v.total) || 0;
    const pagado = pagosVenta.reduce((s, p) => s + (Number(p.monto) || 0), 0);
    const saldo = Math.max(0, total - pagado);
    return { ...v, total, pagado, saldo, facturasVenta, pagosVenta, estadoPago: saldo === 0 ? "Pagado" : pagado > 0 ? "Pago parcial" : "Pendiente" };
  }), [ventas, facturas, pagos]);
  const totales = useMemo(() => registros.reduce((a, v) => ({ ventas: a.ventas + v.total, pagos: a.pagos + v.pagado, saldo: a.saldo + v.saldo }), { ventas: 0, pagos: 0, saldo: 0 }), [registros]);
  const filtrados = registros.filter(v => {
    const q = busqueda.trim().toLowerCase();
    return (!q || [`VEN-${v.id_venta}`, `PED-${v.id_pedido}`, v.observacion || ""].some(x => String(x).toLowerCase().includes(q)))
      && (!estado || v.estadoPago === estado)
      && (!fecha || String(v.fecha_venta || "").slice(0, 10) === fecha);
  });
  const campo = { padding: "12px", border: "1px solid #d9dfe5", borderRadius: 6, background: "white", width: "100%", minWidth: 0 };
  return <div className="w12-vista">
    <div className="w03-heading"><div className="w02-intro"><div className="w02-breadcrumb">Inicio / Ventas / Facturación</div><h1>W12 - Ventas / Facturación</h1><p>Registro de ventas, pagos, estados y datos de facturación.</p></div>
      <button className="w03-primary" type="button" onClick={cargar} disabled={cargando}>↻ Actualizar ventas</button></div>
    {error && <div className="w02-card" role="alert" style={{ padding: 18, color: "#b91c1c", marginBottom: 16 }}>{error}</div>}
    <div className="w12-indicadores" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: 16, marginBottom: 16 }}>
      {[["Ventas registradas", totales.ventas], ["Pagos recibidos", totales.pagos], ["Saldo pendiente", totales.saldo]].map(([nombre, monto]) => <div className="w02-card" key={nombre} style={{ padding: 18 }}><span style={{ color: "#64748b" }}>{nombre}</span><strong style={{ display: "block", fontSize: 25, marginTop: 8, color: nombre === "Saldo pendiente" ? "#d69a00" : "inherit" }}>{dinero(monto)}</strong></div>)}
    </div>
    <section className="w02-card" style={{ padding: 16, marginBottom: 16 }} aria-label="Filtros de ventas"><div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 14 }}>
      <input aria-label="Buscar venta o pedido" style={campo} placeholder="Buscar por venta, pedido u observación..." value={busqueda} onChange={e => setBusqueda(e.target.value)} />
      <select aria-label="Filtrar por estado" style={campo} value={estado} onChange={e => setEstado(e.target.value)}><option value="">Todos los estados</option><option>Pagado</option><option>Pago parcial</option><option>Pendiente</option></select>
      <input aria-label="Filtrar por fecha" type="date" style={campo} value={fecha} onChange={e => setFecha(e.target.value)} />
    </div></section>
    <section className="w02-card w02-section"><div className="w03-section-title"><h2>Registro de ventas ({filtrados.length})</h2><span>Seguimiento de pagos y facturación</span></div>
      <div className="w02-table-scroll"><table><thead><tr>{["Venta", "Pedido", "Fecha", "Total", "Pagado", "Saldo", "Estado", "Facturación", "Acciones"].map(t => <th key={t}>{t}</th>)}</tr></thead><tbody>
        {filtrados.map(v => <tr key={v.id_venta}><td><strong>VEN-{String(v.id_venta).padStart(3, "0")}</strong></td><td>PED-{String(v.id_pedido).padStart(3, "0")}</td><td>{fechaLegible(v.fecha_venta)}</td><td><strong>{dinero(v.total)}</strong></td><td>{dinero(v.pagado)}</td><td>{dinero(v.saldo)}</td><td>{v.estadoPago}</td><td>{v.facturasVenta.map(f => f.numero_factura || `Factura #${f.id_factura}`).join(", ") || "Sin factura"}</td><td><button type="button" className="w03-action" onClick={() => setDetalle(v)}>Consultar</button></td></tr>)}
        {cargando && <tr><td colSpan="9">Cargando ventas…</td></tr>}
        {!cargando && !error && filtrados.length === 0 && <tr><td colSpan="9">No se encontraron ventas.</td></tr>}
      </tbody></table></div>
      <p className="w02-note">Información obtenida desde Django REST API. La facturación registrada es interna; no corresponde a emisión tributaria ante el SII.</p>
    </section>
    {detalle && <section className="w02-card w02-section" style={{ marginTop: 16 }}><div className="w03-section-title"><h2>Detalle de venta VEN-{String(detalle.id_venta).padStart(3, "0")}</h2><button className="w03-action" type="button" onClick={() => setDetalle(null)}>Cerrar</button></div>
      <p><strong>Pedido:</strong> PED-{detalle.id_pedido} · <strong>Total:</strong> {dinero(detalle.total)} · <strong>Pagado:</strong> {dinero(detalle.pagado)} · <strong>Saldo:</strong> {dinero(detalle.saldo)}</p>
      <h3>Facturas asociadas</h3>{detalle.facturasVenta.length ? detalle.facturasVenta.map(f => <p key={f.id_factura}>{f.numero_factura || `Factura #${f.id_factura}`} · {f.estado} · {dinero(f.monto_total)}</p>) : <p>No existen facturas asociadas.</p>}
      <h3>Pagos asociados</h3>{detalle.pagosVenta.length ? detalle.pagosVenta.map(p => <p key={p.id_pago}>Pago #{p.id_pago} · {dinero(p.monto)} · {p.metodo_pago || "Sin método"}</p>) : <p>No existen pagos recibidos.</p>}
    </section>}
  </div>;
}


// Eventos: consulta de datos existentes. El backend actual solo admite GET.
function EventosVista({ csrfToken }) {
  const [eventos, setEventos] = useState([]);
  const [nuevo, setNuevo] = useState(false);
  const [eventoEdicion, setEventoEdicion] = useState(null);
  const [clientesEvento, setClientesEvento] = useState([]);
  const [guardandoEvento, setGuardandoEvento] = useState(false);
  const [errorFormulario, setErrorFormulario] = useState("");
  const [erroresFormulario, setErroresFormulario] = useState({});
  const [exitoEvento, setExitoEvento] = useState("");
  const [formEvento, setFormEvento] = useState({ id_cliente:"", nombre_evento:"", fecha_evento:"", hora_evento:"", direccion:"", cantidad_personas:"", estado:"planificado", observaciones:"" });
  const cambiarEvento = e => { const {name,value} = e.target; setFormEvento(prev => ({...prev,[name]:value})); setErroresFormulario(prev => ({...prev,[name]:""})); };
  const abrirNuevo = async () => {
    setErrorFormulario(""); setErroresFormulario({}); setExitoEvento("");
    setEventoEdicion(null); setFormEvento({ id_cliente:"", nombre_evento:"", fecha_evento:"", hora_evento:"", direccion:"", cantidad_personas:"", estado:"planificado", observaciones:"" });
    try {
      const r = await fetch("/api/clientes/", { credentials:"same-origin" });
      if (!r.ok) throw new Error("No se pudo cargar la lista de clientes.");
      const d = await r.json();
      const lista = Array.isArray(d) ? d : (d.results || d.clientes || []);
      if (!Array.isArray(lista)) throw new Error("Formato de clientes inesperado.");
      setClientesEvento(lista); setNuevo(true); setDetalle(null);
    } catch(e) { setError(e.message); }
  };
  const abrirEdicion = async evento => {
    setErrorFormulario(""); setErroresFormulario({}); setExitoEvento("");
    try {
      const [rClientes, rEvento] = await Promise.all([
        fetch("/api/clientes/", { credentials:"same-origin" }),
        fetch(`/api/eventos/${evento.id_evento}/`, { credentials:"same-origin" })
      ]);
      if (!rClientes.ok || !rEvento.ok) throw new Error("No se pudieron cargar los datos para editar.");
      const [datosClientes, datosEvento] = await Promise.all([rClientes.json(), rEvento.json()]);
      const lista = Array.isArray(datosClientes) ? datosClientes : (datosClientes.results || datosClientes.clientes || []);
      if (!Array.isArray(lista)) throw new Error("Formato de clientes inesperado.");
      setClientesEvento(lista);
      setFormEvento({
        id_cliente: String(datosEvento.id_cliente ?? ""),
        nombre_evento: datosEvento.nombre_evento ?? "",
        fecha_evento: String(datosEvento.fecha_evento ?? "").slice(0,10),
        hora_evento: String(datosEvento.hora_evento ?? "").slice(0,5),
        direccion: datosEvento.direccion ?? "",
        cantidad_personas: datosEvento.cantidad_personas ?? "",
        estado: datosEvento.estado ?? "planificado",
        observaciones: datosEvento.observaciones ?? ""
      });
      setEventoEdicion(datosEvento.id_evento); setNuevo(true); setDetalle(null);
    } catch(e) { setError(e.message); }
  };
  const guardarEvento = async e => {
    e.preventDefault(); setErrorFormulario(""); setErroresFormulario({});
    if (!formEvento.id_cliente || !formEvento.nombre_evento.trim() || !formEvento.fecha_evento || !formEvento.direccion.trim()) {
      setErrorFormulario("Complete cliente, nombre, fecha y dirección."); return;
    }
    setGuardandoEvento(true);
    try {
      const r = await fetch(eventoEdicion ? `/api/eventos/${eventoEdicion}/` : "/api/eventos/", { method:eventoEdicion ? "PATCH" : "POST", credentials:"same-origin", headers:{"Content-Type":"application/json","X-CSRFToken":csrfToken}, body:JSON.stringify({...formEvento, cantidad_personas: formEvento.cantidad_personas === "" ? null : Number(formEvento.cantidad_personas)}) });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) { setErroresFormulario(d.errors || {}); throw new Error(d.detail || `Error HTTP ${r.status}`); }
      setNuevo(false); setEventoEdicion(null); setFormEvento({ id_cliente:"", nombre_evento:"", fecha_evento:"", hora_evento:"", direccion:"", cantidad_personas:"", estado:"planificado", observaciones:"" });
      setBusqueda(""); setEstado("todos"); setExitoEvento(`Evento ${d.nombre_evento} ${eventoEdicion ? "actualizado" : "registrado"} correctamente.`);
      await cargar();
    } catch(e) { setErrorFormulario(e.message); }
    finally { setGuardandoEvento(false); }
  };

  const [eliminandoEvento, setEliminandoEvento] = useState(null);
  const eliminarEvento = async evento => {
    if (!window.confirm(`¿Eliminar el evento "${evento.nombre_evento}"? Esta acción no se puede deshacer.`)) return;
    setExitoEvento(""); setError(""); setEliminandoEvento(evento.id_evento);
    try {
      const r = await fetch(`/api/eventos/${evento.id_evento}/`, {
        method: "DELETE", credentials: "same-origin", headers: { "X-CSRFToken": csrfToken }
      });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.detail || `Error HTTP ${r.status}`);
      if (detalle?.id_evento === evento.id_evento) setDetalle(null);
      setExitoEvento(`Evento "${evento.nombre_evento}" eliminado correctamente.`);
      await cargar();
    } catch(e) { setError(e.message || "No se pudo eliminar el evento."); }
    finally { setEliminandoEvento(null); }
  };

  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");
  const [busqueda, setBusqueda] = useState("");
  const [estado, setEstado] = useState("todos");
  const [detalle, setDetalle] = useState(null);
  const [cargandoDetalle, setCargandoDetalle] = useState(false);
  const [errorDetalle, setErrorDetalle] = useState("");

  const cargar = async (signal) => {
    setCargando(true);
    setError("");
    try {
      const respuesta = await fetch("/api/eventos/", { credentials: "same-origin", signal });
      if (!respuesta.ok) throw new Error(`No se pudieron cargar los eventos (HTTP ${respuesta.status}).`);
      const datos = await respuesta.json();
      if (!Array.isArray(datos.eventos)) throw new Error("La API de eventos devolvió un formato inesperado.");
      setEventos(datos.eventos);
    } catch (e) {
      if (e.name !== "AbortError") setError(e.message || "No se pudo conectar con Django.");
    } finally {
      if (!signal?.aborted) setCargando(false);
    }
  };

  useEffect(() => {
    const controller = new AbortController();
    cargar(controller.signal);
    return () => controller.abort();
  }, []);

  const estados = useMemo(() => [...new Set(eventos.map(e => e.estado).filter(Boolean))].sort(), [eventos]);
  const filtrados = useMemo(() => eventos.filter(e => {
    const texto = [e.nombre_evento, e.nombre_cliente, e.direccion, e.id_evento]
      .filter(v => v !== null && v !== undefined).join(" ").toLocaleLowerCase("es");
    return texto.includes(busqueda.trim().toLocaleLowerCase("es")) &&
      (estado === "todos" || e.estado === estado);
  }), [eventos, busqueda, estado]);

  const consultar = async (evento) => {
    setDetalle(null);
    setErrorDetalle("");
    setCargandoDetalle(true);
    try {
      const respuesta = await fetch(`/api/eventos/${evento.id_evento}/`, { credentials: "same-origin" });
      if (!respuesta.ok) throw new Error(`No se pudo consultar el evento (HTTP ${respuesta.status}).`);
      setDetalle(await respuesta.json());
    } catch (e) {
      setErrorDetalle(e.message || "No se pudo cargar el detalle.");
    } finally {
      setCargandoDetalle(false);
    }
  };

  return <>
    <div className="w03-heading">
      <div className="w02-intro">
        <div className="w02-breadcrumb">Inicio / Eventos</div>
        <h1>Eventos</h1>
        <p>Listado, consulta, registro, edición y eliminación de eventos en PostgreSQL.</p>
      </div>
      <button type="button" className="w03-primary" onClick={abrirNuevo}>+ Nuevo evento</button>
    </div>
    {exitoEvento && <div className="w04-success" role="status">{exitoEvento}</div>}
    {nuevo && <section className="w02-card w04-section"><h2>{eventoEdicion ? `Editar evento #${eventoEdicion}` : "Nuevo evento"}</h2>
      <form onSubmit={guardarEvento} className="w05-formulario">
        <div className="w04-grid">
          <label className="w04-field"><span>Cliente *</span><select name="id_cliente" value={formEvento.id_cliente} onChange={cambiarEvento} required><option value="">Seleccione un cliente</option>{clientesEvento.map(c => <option key={c.id_cliente} value={c.id_cliente}>{c.nombre} {c.tipo_cliente === "empresa" ? "" : (c.apellido || "")}</option>)}</select>{erroresFormulario.id_cliente && <small className="w04-error">{erroresFormulario.id_cliente}</small>}</label>
          {[["nombre_evento","Nombre del evento","text",true],["fecha_evento","Fecha del evento","date",true],["hora_evento","Hora","time",false],["direccion","Dirección","text",true],["cantidad_personas","Cantidad de personas","number",false]].map(([name,label,type,required]) => <label key={name} className="w04-field"><span>{label}{required ? " *" : ""}</span><input name={name} type={type} required={required} min={type === "number" ? 1 : undefined} maxLength={type === "text" ? 150 : undefined} value={formEvento[name]} onChange={cambiarEvento}/>{erroresFormulario[name] && <small className="w04-error">{erroresFormulario[name]}</small>}</label>)}
          <label className="w04-field"><span>Estado</span><select name="estado" value={formEvento.estado} onChange={cambiarEvento}><option value="planificado">Planificado</option><option value="confirmado">Confirmado</option><option value="cancelado">Cancelado</option><option value="finalizado">Finalizado</option></select></label>
          <label className="w04-field w04-full"><span>Observaciones</span><textarea name="observaciones" rows="3" value={formEvento.observaciones} onChange={cambiarEvento}/></label>
        </div>
        {errorFormulario && <div className="w02-message w02-error" role="alert">{errorFormulario}</div>}
        <div className="w04-actions"><button type="button" className="w04-secondary" onClick={() => { setNuevo(false); setEventoEdicion(null); }}>Cancelar</button><button type="submit" className="w03-primary" disabled={guardandoEvento}>{guardandoEvento ? "Guardando…" : eventoEdicion ? "Guardar cambios" : "Guardar evento"}</button></div>
      </form>
    </section>}
    {error && <div className="w02-message w02-error" role="alert">{error}</div>}
    <section className="w02-card w03-filters" aria-label="Filtros de eventos">
      <label><span>Buscar eventos</span><input value={busqueda} onChange={e => setBusqueda(e.target.value)} placeholder="Evento, cliente, dirección o ID…" /></label>
      <label><span>Estado</span><select value={estado} onChange={e => setEstado(e.target.value)}>
        <option value="todos">Todos los estados</option>
        {estados.map(v => <option key={v} value={v}>{v}</option>)}
      </select></label>
      <button type="button" className="w04-secondary" onClick={() => { setDetalle(null); cargar(); }}>Actualizar</button>
    </section>
    <section className="w02-card w02-section">
      <div className="w03-section-title"><h2>Lista de eventos ({filtrados.length})</h2><span>Datos reales · PostgreSQL</span></div>
      <div className="w02-table-scroll"><table>
        <thead><tr><th>Evento</th><th>Cliente</th><th>Fecha / hora</th><th>Personas</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody>
          {filtrados.map(e => <tr key={e.id_evento}>
            <td><strong>{e.nombre_evento || `Evento #${e.id_evento}`}</strong><small style={{display:"block"}}>{e.direccion || "Sin dirección"}</small></td>
            <td>{e.nombre_cliente || "—"}</td>
            <td>{fechaLegible(e.fecha_evento)} {e.hora_evento ? `· ${String(e.hora_evento).slice(0, 5)}` : ""}</td>
            <td>{e.cantidad_personas ?? "—"}</td>
            <td>{e.estado || "—"}</td>
            <td><div className="w04-table-actions"><button type="button" className="w03-action" onClick={() => consultar(e)}>Consultar</button><button type="button" className="w03-action" onClick={() => abrirEdicion(e)}>Editar</button><button type="button" className="w03-action" disabled={eliminandoEvento !== null} onClick={() => eliminarEvento(e)}>{eliminandoEvento === e.id_evento ? "Eliminando…" : "Eliminar"}</button></div></td>
          </tr>)}
          {cargando && <tr><td colSpan="6">Cargando eventos…</td></tr>}
          {!cargando && !error && filtrados.length === 0 && <tr><td colSpan="6">No se encontraron eventos.</td></tr>}
        </tbody>
      </table></div>
      <p className="w02-note">Los eventos registrados se pueden seleccionar posteriormente desde Pedidos. La eliminación requiere confirmación y no se permite si el evento está asociado a pedidos.</p>
    </section>
    {cargandoDetalle && <p role="status">Cargando detalle del evento…</p>}
    {errorDetalle && <div className="w02-message w02-error" role="alert">{errorDetalle}</div>}
    {detalle && <section className="w02-card w02-section" aria-label="Detalle del evento">
      <div className="w03-section-title"><h2>Detalle de {detalle.nombre_evento || `Evento #${detalle.id_evento}`}</h2>
        <button type="button" className="w04-secondary" onClick={() => setDetalle(null)}>Cerrar</button></div>
      <dl>{[
        ["ID", detalle.id_evento], ["Cliente", detalle.nombre_cliente], ["Nombre de fantasía", detalle.nombre_fantasia],
        ["Fecha", fechaLegible(detalle.fecha_evento)], ["Hora", detalle.hora_evento ? String(detalle.hora_evento).slice(0, 5) : null],
        ["Dirección", detalle.direccion], ["Cantidad de personas", detalle.cantidad_personas],
        ["Estado", detalle.estado], ["Observaciones", detalle.observaciones]
      ].map(([nombre, valor]) => <div key={nombre} style={{marginBottom:"0.5rem"}}><dt><strong>{nombre}</strong></dt><dd>{valor === null || valor === undefined || valor === "" ? "—" : valor}</dd></div>)}</dl>
    </section>}
  </>;
}

function App() {
  const [vista, setVista] = useState("Dashboard");
  const [sesion, setSesion] = useState(null);
  const [csrfToken, setCsrfToken] = useState("");
  const [usuario, setUsuario] = useState("");
  const [clave, setClave] = useState("");
  const [loginError, setLoginError] = useState("");
  const [mostrarClave, setMostrarClave] = useState(false);
  const [iniciando, setIniciando] = useState(false);
  const leerCsrf = () => decodeURIComponent(document.cookie.split("; ").find(v => v.startsWith("csrftoken="))?.split("=")[1] || "");
  useEffect(() => {
    fetch("/api/auth/session/", { credentials: "same-origin" })
      .then(r => r.json()).then(data => { setSesion(data); setCsrfToken(leerCsrf()); })
      .catch(() => setSesion({ authenticated: false, can_write: false }));
  }, []);
  const iniciarSesion = async (e) => {
    e.preventDefault(); setLoginError(""); setIniciando(true);
    try {
      const r = await fetch("/api/auth/login/", { method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json", "X-CSRFToken": csrfToken },
        body: JSON.stringify({ username: usuario, password: clave }) });
      const data = await r.json();
      if (!r.ok) { setLoginError(data.detail || "Acceso denegado"); return; }
      if (!data.can_write) { setLoginError("La cuenta no tiene permiso administrativo."); return; }
      setSesion(data); setCsrfToken(leerCsrf()); setClave("");
    } catch { setLoginError("No fue posible contactar con Django."); }
    finally { setIniciando(false); }
  };
  const cerrarSesion = async () => {
    await fetch("/api/auth/logout/", { method: "POST", credentials: "same-origin", headers: { "X-CSRFToken": csrfToken } });
    setSesion({ authenticated: false, can_write: false });
  };

  const [modoFormulario, setModoFormulario] = useState("nuevo");
  const [clienteEdicion, setClienteEdicion] = useState(null);
  const [clientes, setClientes] = useState(null);
  const [filasClientes, setFilasClientes] = useState([]);
  const [busqueda, setBusqueda] = useState("");
  const [filtroEstado, setFiltroEstado] = useState("todos");
  const [clienteSeleccionado, setClienteSeleccionado] = useState(null);
  const [pedidos, setPedidos] = useState(null);
  const [filasPedidos, setFilasPedidos] = useState([]);
  const [todosPedidos, setTodosPedidos] = useState([]);
  const [pedidoEdicion, setPedidoEdicion] = useState(null);
  const [pedidoDetalle, setPedidoDetalle] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");
  const [aviso, setAviso] = useState("");

  const cargarDatos = async () => {
    const respuestas = await Promise.all([fetch("/api/clientes/"), fetch("/api/pedidos/")]);
    if (respuestas.some(r => !r.ok)) throw new Error("API no disponible");
    const [c, p] = await Promise.all(respuestas.map(r => r.json()));
    const clientesNormalizados = normalizarLista(c), pedidosNormalizados = normalizarLista(p);
    setClientes(clientesNormalizados.total); setFilasClientes(clientesNormalizados.items);
    setPedidos(pedidosNormalizados.total); setFilasPedidos(pedidosNormalizados.items.slice(0,5)); setTodosPedidos(pedidosNormalizados.items);
    setError("");
  };
  useEffect(() => {
    if (!sesion?.can_write) return;
    const controller = new AbortController();
    async function cargar() {
      try {
        setCargando(true);
        const respuestas = await Promise.all([
          fetch("/api/clientes/", { signal: controller.signal }),
          fetch("/api/pedidos/", { signal: controller.signal }),
        ]);
        if (respuestas.some((r) => !r.ok)) throw new Error("No se pudo consultar la API.");
        const [clientesData, pedidosData] = await Promise.all(respuestas.map((r) => r.json()));
        const c = normalizarLista(clientesData);
        const p = normalizarLista(pedidosData);
        setClientes(c.total);
        setFilasClientes(c.items);
        setPedidos(p.total);
        setFilasPedidos(p.items.slice(0, 5));
        setTodosPedidos(p.items);
        setError("");
      } catch (e) {
        if (e.name !== "AbortError") setError("No fue posible obtener los datos de Django. Revisa el servidor y el proxy de Vite.");
      } finally {
        if (!controller.signal.aborted) setCargando(false);
      }
    }
    cargar();
    return () => controller.abort();
  }, [sesion?.can_write]);

  const indicador = (valor) => cargando ? "…" : valor ?? "—";
  const clientesFiltrados = useMemo(() => filasClientes.filter((c) => {
    const texto = [c.nombre, c.apellido, c.nombre_fantasia, c.rut, c.email, c.telefono]
      .filter(Boolean).join(" ").toLocaleLowerCase("es");
    return texto.includes(busqueda.trim().toLocaleLowerCase("es")) &&
      (filtroEstado === "todos" || String(c.estado || "").toLowerCase() === filtroEstado);
  }), [filasClientes, busqueda, filtroEstado]);
  const nombreCliente = (c) => c.tipo_cliente === "empresa"
    ? (c.nombre || "Sin razón social")
    : ([c.nombre, c.apellido].filter(Boolean).join(" ") || "Sin nombre");
  const iniciales = (c) => nombreCliente(c).split(" ").slice(0, 2).map(x => x[0]).join("").toUpperCase();

  if (sesion === null) return <div className="w01-loading" role="status">Comprobando sesión…</div>;
  if (!sesion.can_write) return (
    <main className="w01-page">
      <section className="w01-left" aria-label="Presentación del sistema">
        <div className="w01-brand"><span className="w01-logo" aria-hidden="true">☕</span>
          <div><strong>Banquetería Maya</strong><small>Sistema Integral de Gestión</small></div>
        </div>
        <div className="w01-hero">
          <h1>Gestión de banquetería en un solo lugar.</h1>
          <p>Administra clientes, pedidos, inventario y la operación de tus eventos desde una plataforma centralizada.</p>
        </div>
        <div className="w01-features"><span>✓ Gestión centralizada</span><span>✓ Control por roles</span><span>✓ Información segura</span></div>
      </section>
      <section className="w01-right" aria-label="Acceso al sistema">
        <div className="w01-box">
          <div className="w01-intro"><span>W01 · Acceso al sistema</span><h2>Iniciar sesión</h2>
            <p>Ingresa tus credenciales para acceder al sistema.</p></div>
          <form className="w01-card" onSubmit={iniciarSesion}>
            <label htmlFor="w01-usuario">Usuario</label>
            <div className="w01-input-wrap"><span aria-hidden="true">♙</span>
              <input id="w01-usuario" required autoComplete="username" placeholder="Nombre de usuario"
                value={usuario} onChange={e=>setUsuario(e.target.value)} /></div>
            <label htmlFor="w01-clave">Contraseña</label>
            <div className="w01-input-wrap"><span aria-hidden="true">🔒</span>
              <input id="w01-clave" required type={mostrarClave ? "text" : "password"}
                autoComplete="current-password" placeholder="Ingresa tu contraseña"
                value={clave} onChange={e=>setClave(e.target.value)} />
              <button className="w01-toggle" type="button" onClick={()=>setMostrarClave(v=>!v)}
                aria-label={mostrarClave ? "Ocultar contraseña" : "Mostrar contraseña"}
                aria-pressed={mostrarClave}>{mostrarClave ? "Ocultar" : "Mostrar"}</button></div>
            <p className="w01-help">¿Olvidaste tu contraseña? Contacta al administrador del sistema.</p>
            {loginError && <p className="w01-error" role="alert">{loginError}</p>}
            <button className="w01-submit" type="submit" disabled={iniciando}>{iniciando ? "Ingresando…" : "➜  Iniciar sesión"}</button>
            <div className="w01-note">🔐 Acceso protegido mediante autenticación Django y sesiones seguras.</div>
          </form>
          <p className="w01-footnote">Acceso exclusivo para usuarios autorizados.</p>
        </div>
      </section>
    </main>
  );
  return (
    <div className="w02-layout">
      <aside className="w02-sidebar">
        <div className="w02-brand">
          <span className="w02-brand-icon" aria-hidden="true">☕</span>
          <div><strong>Banquetería Maya</strong><small>Sistema Integral de Gestión</small></div>
        </div>
        <nav aria-label="Módulos del sistema">
          {MENU.map(([nombre, icono]) => (
            <button key={nombre} type="button"
              className={`w02-nav-item ${nombre === vista ? "active" : ""}`}
              aria-current={nombre === vista ? "page" : undefined}
              onClick={() => { if (nombre === "Dashboard" || nombre === "Clientes" || nombre === "Eventos" || nombre === "Pedidos" || nombre === "Fichas técnicas" || nombre === "Cotizador" || nombre === "Inventario" || nombre === "Ventas / Facturación") { setVista(nombre); setAviso(""); } else { setAviso(`${nombre}: módulo pendiente de integración.`); } }}>
              <span aria-hidden="true">{icono}</span>{nombre}
            </button>
          ))}
        </nav>
        <div className="w02-sidebar-footer">{vista === "Dashboard" ? "W02 · Dashboard" : vista === "FormularioCliente" ? "W04 · Formulario Cliente" : vista === "DetallePedido" ? "W06 · Detalle de pedido" : (vista === "Pedidos" || vista === "FormularioPedido") ? "W05 · Pedidos" : vista === "Eventos" ? "Eventos · Gestión de eventos" : vista === "Fichas técnicas" ? "W08 / W09 · Fichas técnicas" : vista === "Cotizador" ? "W10 · Cotizador" : vista === "Inventario" ? "W11 · Inventario" : vista === "Ventas / Facturación" ? "W12 · Ventas / Facturación" : "W03 · Clientes"}</div>
      </aside>

      <div className="w02-main">
        <header className="w02-top">
          <span className="w02-top-title">Panel administrativo</span>
          <span className="w02-user"><span className="w02-avatar">BM</span><span>{sesion.username}<small>Administrador autenticado</small></span><button type="button" className="w04-secondary" onClick={cerrarSesion}>Salir</button></span>
        </header>

        <main className="w02-content">
          {vista === "Dashboard" ? <>
          <div className="w02-intro">
            <div className="w02-breadcrumb">Inicio / Dashboard</div>
            <h1>Dashboard</h1>
            <p>Resumen general de la operación de banquetería.</p>
          </div>

          {error && <div className="w02-message w02-error" role="alert">{error}</div>}
          {aviso && <div className="w02-message" role="status">{aviso} <button type="button" onClick={() => setAviso("")}>Cerrar</button></div>}

          <section className="w02-metrics" aria-label="Indicadores generales">
            <div className="w02-card w02-metric"><div><span>Clientes registrados</span><strong>{indicador(clientes)}</strong><small>Datos reales · PostgreSQL</small></div><div className="w02-metric-icon">♙</div></div>
            <div className="w02-card w02-metric"><div><span>Pedidos registrados</span><strong>{indicador(pedidos)}</strong><small>Total de pedidos · PostgreSQL</small></div><div className="w02-metric-icon">▤</div></div>
            <div className="w02-card w02-metric"><div><span>Ventas del período</span><strong>—</strong><small>Pendiente de API de ventas</small></div><div className="w02-metric-icon">＄</div></div>
            <div className="w02-card w02-metric"><div><span>Rentabilidad</span><strong>—</strong><small>Pendiente de cálculo real</small></div><div className="w02-metric-icon">↗</div></div>
          </section>

          <div className="w02-grid-primary">
            <section className="w02-card w02-section">
              <div className="w02-section-head"><h2>Pedidos registrados</h2><span>Últimos registros recibidos de la API</span></div>
              <div className="w02-table-scroll">
                <table><thead><tr><th>Pedido</th><th>Fecha compromiso</th><th>Cliente (ID)</th><th>Estado (ID)</th></tr></thead>
                  <tbody>
                    {filasPedidos.map((p, i) => (
                      <tr key={p.id_pedido ?? i}>
                        <td><strong>{p.numero_pedido || `#${p.id_pedido ?? "—"}`}</strong></td>
                        <td>{fechaLegible(p.fecha_compromiso)}</td>
                        <td>{p.id_cliente ?? "—"}</td>
                        <td>{p.id_estado_pedido ?? "—"}</td>
                      </tr>
                    ))}
                    {!cargando && !error && filasPedidos.length === 0 && <tr><td colSpan="4">No hay pedidos para mostrar.</td></tr>}
                    {cargando && <tr><td colSpan="4">Cargando pedidos…</td></tr>}
                  </tbody>
                </table>
              </div>
              <p className="w02-note">Los nombres de clientes y estados se incorporarán cuando el backend exponga esas relaciones. Esta tabla no inventa datos.</p>
            </section>

            <section className="w02-card w02-section">
              <h2>Alertas operativas</h2>
              <div className="w02-alert"><span>▣</span><div><strong>Stock crítico</strong><p>Pendiente de integración con inventario.</p></div></div>
              <div className="w02-alert"><span>◷</span><div><strong>Pedidos próximos</strong><p>Pendiente de reglas de fechas y estados.</p></div></div>
              <div className="w02-alert"><span>＄</span><div><strong>Pagos pendientes</strong><p>Pendiente de integración con facturación.</p></div></div>
            </section>
          </div>

          <div className="w02-grid-secondary">
            <section className="w02-card w02-section">
              <h2>Ventas y costos</h2>
              <div className="w02-empty">Las métricas de ventas, costos y margen estarán disponibles al crear un endpoint de resumen financiero.</div>
              <p className="w02-note">Se retiraron las cifras ficticias del prototipo W02.</p>
            </section>
            <section className="w02-card w02-section">
              <h2>Indicadores operativos</h2>
              <div className="w02-line"><span>Clientes registrados</span><strong>{indicador(clientes)}</strong></div>
              <div className="w02-line"><span>Pedidos registrados</span><strong>{indicador(pedidos)}</strong></div>
              <div className="w02-line"><span>Pedidos pendientes</span><strong>—</strong></div>
              <div className="w02-line"><span>Insumos con stock crítico</span><strong>—</strong></div>
              <div className="w02-line"><span>Incidencias abiertas</span><strong>—</strong></div>
            </section>
          </div>
          </> : vista === "FormularioCliente" ? (
            <ClienteFormulario key={`${modoFormulario}-${clienteEdicion?.id_cliente ?? "nuevo"}`}
              inicial={clienteEdicion} modo={modoFormulario}
              onCancelar={() => setVista("Clientes")}
              csrfToken={csrfToken}
              onGuardado={async () => { await cargarDatos(); setVista("Clientes"); setAviso("Cliente guardado correctamente."); }} />
          ) : vista === "FormularioPedido" ? (
            <PedidoFormulario key={pedidoEdicion?.id_pedido ?? "nuevo"} inicial={pedidoEdicion}
              clientes={filasClientes} pedidos={todosPedidos} csrfToken={csrfToken}
              onCancelar={() => setVista("Pedidos")}
              onGuardado={async () => { await cargarDatos(); setVista("Pedidos"); setAviso("Pedido guardado correctamente."); }} />
          ) : vista === "DetallePedido" && pedidoDetalle ? (
            <PedidoDetalle key={pedidoDetalle.id_pedido} pedidoInicial={pedidoDetalle}
              onVolver={() => setVista("Pedidos")}
              onEditar={p => { setPedidoEdicion(p); setVista("FormularioPedido"); }} />
          ) : vista === "Eventos" ? (
            <EventosVista csrfToken={csrfToken} />
          ) : vista === "Fichas técnicas" ? (
            <FichasTecnicasVista csrfToken={csrfToken} />
          ) : vista === "Cotizador" ? (
              <CotizadorVista pedidos={todosPedidos} csrfToken={csrfToken} sesion={sesion} />
           ) : vista === "Inventario" ? (
              <InventarioVista csrfToken={csrfToken} />
           ) : vista === "Ventas / Facturación" ? (
              <VentasFacturacionVista />
           ) : vista === "Pedidos" ? (
            <><PedidosVista registros={todosPedidos} total={pedidos} cargando={cargando} error={error}
              onNuevo={() => { setPedidoEdicion(null); setVista("FormularioPedido"); }}
              onEditar={p => { setPedidoEdicion(p); setVista("FormularioPedido"); }}
              onDetalle={p => { setPedidoDetalle(p); setVista("DetallePedido"); }} />
              {aviso && <div className="w04-success" role="status">{aviso}</div>}</>
          ) : <>
            <div className="w03-heading">
              <div className="w02-intro"><div className="w02-breadcrumb">Inicio / Clientes</div><h1>Clientes</h1><p>Listado, búsqueda y consulta de clientes registrados.</p></div>
              <button className="w03-primary" type="button" onClick={() => { setModoFormulario("nuevo"); setClienteEdicion(null); setVista("FormularioCliente"); }}>+ Nuevo cliente</button>
            </div>
            <section className="w02-card w03-filters" aria-label="Filtros de clientes">
              <label><span>Buscar clientes</span><input value={busqueda} onChange={(e) => setBusqueda(e.target.value)} placeholder="Nombre, RUT, email o teléfono…" /></label>
              <label><span>Estado</span><select value={filtroEstado} onChange={(e) => setFiltroEstado(e.target.value)}><option value="todos">Todos los estados</option><option value="activo">Activos</option><option value="inactivo">Inactivos</option></select></label>
            </section>
            <div className="w03-columns">
              <section className="w02-card w02-section">
                <div className="w03-section-title"><h2>Lista de clientes ({clientesFiltrados.length})</h2><span>Consulta y actualización protegidas</span></div>
                <div className="w02-table-scroll"><table><thead><tr><th>Cliente</th><th>RUT</th><th>Teléfono</th><th>Email</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>
                  {clientesFiltrados.map((c) => <tr key={c.id_cliente}>
                    <td><div className="w03-name"><span className="w03-initials">{iniciales(c)}</span><div><strong>{nombreCliente(c)}</strong>{c.nombre_fantasia && <small className="w04-alias">Nombre de fantasía: {c.nombre_fantasia}</small>}</div></div></td>
                    <td>{c.rut || "—"}</td><td>{c.telefono || "—"}</td><td>{c.email || "—"}</td>
                    <td><span className={`w03-status ${String(c.estado).toLowerCase() === "activo" ? "on" : "off"}`}>{c.estado || "Sin estado"}</span></td>
                    <td><div className="w04-table-actions"><button className="w03-action" type="button" onClick={() => setClienteSeleccionado(c)} aria-label={`Consultar ${nombreCliente(c)}`}>Consultar</button>
                    <button className="w03-action" type="button" onClick={() => { setModoFormulario("editar"); setClienteEdicion(c); setVista("FormularioCliente"); }} aria-label={`Abrir formulario de ${nombreCliente(c)}`}>Formulario</button></div></td>
                  </tr>)}
                  {cargando && <tr><td colSpan="6">Cargando clientes…</td></tr>}
                  {!cargando && !error && clientesFiltrados.length === 0 && <tr><td colSpan="6">No se encontraron clientes.</td></tr>}
                </tbody></table></div>
                {clientes !== null && clientes > filasClientes.length && <p className="w02-note">La API entrega {filasClientes.length} de {clientes} clientes. Falta implementar paginación para consultar todos los registros.</p>}
              </section>
              <aside className="w02-card w02-section w03-detail"><h2>Detalle del cliente</h2>
                {clienteSeleccionado ? <><div className="w03-detail-heading"><span className="w03-initials large">{iniciales(clienteSeleccionado)}</span><div><strong>{nombreCliente(clienteSeleccionado)}</strong>{clienteSeleccionado.nombre_fantasia && <small className="w04-alias">Nombre de fantasía: {clienteSeleccionado.nombre_fantasia}</small>}<p>{clienteSeleccionado.estado || "Sin estado"}</p></div></div>
                  <dl>{[["RUT",clienteSeleccionado.rut],["Tipo de cliente",clienteSeleccionado.tipo_cliente],["Teléfono",clienteSeleccionado.telefono],["Email",clienteSeleccionado.email],["Dirección",clienteSeleccionado.direccion],["Giro",clienteSeleccionado.giro]].map(([k,v]) => <div key={k}><dt>{k}</dt><dd>{v || "—"}</dd></div>)}</dl>
                </> : <p className="w03-hint">Selecciona «Consultar» en la lista para ver el detalle de un cliente.</p>}
              </aside>
            </div>
          </>}
          <p className="w02-dev-warning">Entorno de desarrollo: las API actuales deben protegerse con autenticación y permisos antes de publicar el sistema.</p>
        </main>
      </div>
    </div>
  );
}
export default App;
